-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-11-2026 a las 15:53:05
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `fabucha`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bloqueos_cancha`
--

CREATE TABLE `bloqueos_cancha` (
  `id` int(11) NOT NULL,
  `cancha_id` int(11) NOT NULL,
  `fecha_inicio` datetime NOT NULL,
  `fecha_fin` datetime NOT NULL,
  `motivo` varchar(255) NOT NULL,
  `creado_por` int(11) NOT NULL,
  `fecha_creacion` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `canchas`
--

CREATE TABLE `canchas` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `capacidad_tribuna` int(11) NOT NULL DEFAULT 40,
  `capacidad_jugadores` int(11) NOT NULL DEFAULT 10,
  `aforo_maximo` int(11) NOT NULL DEFAULT 50,
  `activa` tinyint(1) NOT NULL DEFAULT 1,
  `creada_en` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `canchas`
--

INSERT INTO `canchas` (`id`, `nombre`, `capacidad_tribuna`, `capacidad_jugadores`, `aforo_maximo`, `activa`, `creada_en`) VALUES
(1, 'Cancha A', 40, 10, 50, 1, '2026-11-15 20:10:44'),
(2, 'Cancha B', 30, 14, 44, 1, '2026-11-15 20:10:44'),
(3, 'Cancha C', 20, 10, 30, 1, '2026-11-15 20:10:44');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cancha_deporte`
--

CREATE TABLE `cancha_deporte` (
  `id` int(11) NOT NULL,
  `cancha_id` int(11) NOT NULL,
  `deporte_id` int(11) NOT NULL,
  `precio_hora` decimal(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `cancha_deporte`
--

INSERT INTO `cancha_deporte` (`id`, `cancha_id`, `deporte_id`, `precio_hora`) VALUES
(1, 1, 1, 40.00),
(2, 1, 3, 30.00),
(3, 2, 2, 55.00),
(4, 2, 3, 35.00),
(5, 3, 4, 30.00),
(6, 3, 3, 25.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `deportes`
--

CREATE TABLE `deportes` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(150) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `deportes`
--

INSERT INTO `deportes` (`id`, `nombre`, `descripcion`, `activo`) VALUES
(1, 'Fútbol 5', 'Fútbol en cancha reducida para 5 jugadores por equipo', 1),
(2, 'Fútbol 7', 'Fútbol en cancha mediana para 7 jugadores por equipo', 1),
(3, 'Vóley', 'Vóleibol en cancha de cemento o grass', 1),
(4, 'Básquet', 'Básquetbol en cancha reglamentaria', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fotos_limpieza`
--

CREATE TABLE `fotos_limpieza` (
  `id` int(11) NOT NULL,
  `reserva_id` int(11) NOT NULL,
  `ruta` varchar(255) NOT NULL,
  `tipo` enum('antes','despues','dano') NOT NULL DEFAULT 'despues',
  `subida_por` int(11) NOT NULL,
  `fecha_subida` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horarios`
--

CREATE TABLE `horarios` (
  `id` int(11) NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `horarios`
--

INSERT INTO `horarios` (`id`, `hora_inicio`, `hora_fin`, `activo`) VALUES
(1, '08:00:00', '09:00:00', 1),
(2, '09:00:00', '10:00:00', 1),
(3, '10:00:00', '11:00:00', 1),
(4, '11:00:00', '12:00:00', 1),
(5, '12:00:00', '13:00:00', 1),
(6, '13:00:00', '14:00:00', 1),
(7, '14:00:00', '15:00:00', 1),
(8, '15:00:00', '16:00:00', 1),
(9, '16:00:00', '17:00:00', 1),
(10, '17:00:00', '18:00:00', 1),
(11, '18:00:00', '19:00:00', 1),
(12, '19:00:00', '20:00:00', 1),
(13, '20:00:00', '21:00:00', 1),
(14, '21:00:00', '22:00:00', 1),
(15, '22:00:00', '23:00:00', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_acceso`
--

CREATE TABLE `logs_acceso` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `email_intentado` varchar(150) DEFAULT NULL,
  `evento` enum('login_ok','login_fail','bloqueo','desbloqueo','logout') NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_reservas`
--

CREATE TABLE `logs_reservas` (
  `id` int(11) NOT NULL,
  `reserva_id` int(11) NOT NULL,
  `estado_anterior` varchar(30) DEFAULT NULL,
  `estado_nuevo` varchar(30) NOT NULL,
  `motivo` varchar(255) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

CREATE TABLE `pagos` (
  `id` int(11) NOT NULL,
  `reserva_id` int(11) NOT NULL,
  `tipo` enum('reserva','sobretiempo','deposito','reembolso') NOT NULL,
  `metodo` enum('efectivo','yape','plin','transferencia') NOT NULL,
  `monto` decimal(8,2) NOT NULL,
  `estado` enum('pagado','impago') NOT NULL DEFAULT 'pagado',
  `pagado_por` int(11) DEFAULT NULL,
  `registrado_por` int(11) NOT NULL,
  `comprobante` varchar(255) DEFAULT NULL,
  `fecha_pago` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `politicas_cancelacion`
--

CREATE TABLE `politicas_cancelacion` (
  `id` int(11) NOT NULL,
  `horas_anticipacion_min` int(11) NOT NULL,
  `porcentaje_reembolso_cancha` int(11) NOT NULL,
  `reembolso_deposito` tinyint(1) NOT NULL DEFAULT 1,
  `descripcion` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `politicas_cancelacion`
--

INSERT INTO `politicas_cancelacion` (`id`, `horas_anticipacion_min`, `porcentaje_reembolso_cancha`, `reembolso_deposito`, `descripcion`) VALUES
(1, 24, 96, 1, 'Más de 24 horas: reembolso del 96% de la cancha y 100% del depósito'),
(2, 5, 50, 1, 'Entre 5 y 24 horas: reembolso del 50% de la cancha y 100% del depósito'),
(3, 0, 0, 1, 'Menos de 5 horas: sin reembolso de cancha, 100% del depósito');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservas`
--

CREATE TABLE `reservas` (
  `id` int(11) NOT NULL,
  `codigo` varchar(12) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `cancha_id` int(11) NOT NULL,
  `deporte_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `horario_id` int(11) NOT NULL,
  `cantidad_personas` int(11) NOT NULL,
  `nombre_equipo` varchar(80) DEFAULT NULL,
  `estado` enum('hold','pendiente_pago','pagada_parcial','pagada_total','en_espera','en_uso','finalizada','cancelada_cliente','cancelada_local','cancelada_falta_pago','no_show') NOT NULL DEFAULT 'hold',
  `monto_cancha` decimal(8,2) NOT NULL,
  `monto_deposito` decimal(8,2) NOT NULL DEFAULT 10.00,
  `monto_total` decimal(8,2) NOT NULL,
  `monto_pagado` decimal(8,2) NOT NULL DEFAULT 0.00,
  `monto_reembolsado` decimal(8,2) NOT NULL DEFAULT 0.00,
  `multa_aplicada` decimal(8,2) NOT NULL DEFAULT 0.00,
  `deposito_devuelto` tinyint(1) NOT NULL DEFAULT 0,
  `minutos_extra` int(11) NOT NULL DEFAULT 0,
  `monto_extra` decimal(8,2) NOT NULL DEFAULT 0.00,
  `sobretiempo_pagado` tinyint(1) NOT NULL DEFAULT 0,
  `expira_en` datetime DEFAULT NULL,
  `limite_pago` datetime DEFAULT NULL,
  `hora_ingreso_real` datetime DEFAULT NULL,
  `hora_salida_real` datetime DEFAULT NULL,
  `hora_fin_extendida` datetime DEFAULT NULL,
  `verificado_por` int(11) DEFAULT NULL,
  `registrado_por` int(11) DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  `creada_en` datetime NOT NULL DEFAULT current_timestamp(),
  `actualizada_en` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `reserva_activa` tinyint(4) GENERATED ALWAYS AS (case when `estado` in ('hold','pendiente_pago','pagada_parcial','pagada_total','en_uso') then 1 else NULL end) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `reservas`
--

INSERT INTO `reservas` (`id`, `codigo`, `usuario_id`, `cancha_id`, `deporte_id`, `fecha`, `horario_id`, `cantidad_personas`, `nombre_equipo`, `estado`, `monto_cancha`, `monto_deposito`, `monto_total`, `monto_pagado`, `monto_reembolsado`, `multa_aplicada`, `deposito_devuelto`, `minutos_extra`, `monto_extra`, `sobretiempo_pagado`, `expira_en`, `limite_pago`, `hora_ingreso_real`, `hora_salida_real`, `hora_fin_extendida`, `verificado_por`, `registrado_por`, `observaciones`, `creada_en`, `actualizada_en`) VALUES
(1, 'FAB-YZBACG', 2, 1, 1, '2026-11-26', 2, 12, 'xds', 'hold', 40.00, 10.00, 50.00, 0.00, 0.00, 0.00, 0, 0, 0.00, 0, '2026-11-15 22:09:49', '2026-11-26 04:00:00', NULL, NULL, NULL, NULL, 2, NULL, '2026-11-15 22:04:49', '2026-11-15 22:04:49');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `rol` enum('cliente','trabajador','limpieza','admin') NOT NULL DEFAULT 'cliente',
  `tipo_trabajador` enum('recepcionista','cajero','supervisor') DEFAULT NULL,
  `intentos_fallidos` int(11) NOT NULL DEFAULT 0,
  `cuenta_bloqueada` tinyint(1) NOT NULL DEFAULT 0,
  `fecha_bloqueo` datetime DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `deuda_pendiente` decimal(8,2) NOT NULL DEFAULT 0.00,
  `creado_en` datetime NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `email`, `password`, `telefono`, `rol`, `tipo_trabajador`, `intentos_fallidos`, `cuenta_bloqueada`, `fecha_bloqueo`, `activo`, `deuda_pendiente`, `creado_en`, `actualizado_en`) VALUES
(1, 'Administrador Fabucha', 'admin@fabucha.com', '$2y$10$X8601ZcAxdtqV/MVJ34O2emfTQNxr8QwNccjSXPE/hrjlcyDIkm9e', NULL, 'admin', NULL, 0, 0, NULL, 1, 0.00, '2026-11-15 20:10:44', '2026-11-15 20:13:07'),
(2, 'gato', 'miguelcrz842@gmail.com', '$2y$10$X8601ZcAxdtqV/MVJ34O2emfTQNxr8QwNccjSXPE/hrjlcyDIkm9e', NULL, 'cliente', NULL, 0, 0, NULL, 1, 0.00, '2026-11-15 20:10:44', '2026-11-15 20:13:07');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `bloqueos_cancha`
--
ALTER TABLE `bloqueos_cancha`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cancha_id` (`cancha_id`),
  ADD KEY `creado_por` (`creado_por`);

--
-- Indices de la tabla `canchas`
--
ALTER TABLE `canchas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cancha_deporte`
--
ALTER TABLE `cancha_deporte`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_cancha_deporte` (`cancha_id`,`deporte_id`),
  ADD KEY `deporte_id` (`deporte_id`);

--
-- Indices de la tabla `deportes`
--
ALTER TABLE `deportes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `fotos_limpieza`
--
ALTER TABLE `fotos_limpieza`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reserva_id` (`reserva_id`),
  ADD KEY `subida_por` (`subida_por`);

--
-- Indices de la tabla `horarios`
--
ALTER TABLE `horarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_horario` (`hora_inicio`,`hora_fin`);

--
-- Indices de la tabla `logs_acceso`
--
ALTER TABLE `logs_acceso`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `idx_evento` (`evento`),
  ADD KEY `idx_fecha` (`fecha`);

--
-- Indices de la tabla `logs_reservas`
--
ALTER TABLE `logs_reservas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `idx_reserva` (`reserva_id`);

--
-- Indices de la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reserva_id` (`reserva_id`),
  ADD KEY `pagado_por` (`pagado_por`),
  ADD KEY `registrado_por` (`registrado_por`);

--
-- Indices de la tabla `politicas_cancelacion`
--
ALTER TABLE `politicas_cancelacion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo` (`codigo`),
  ADD UNIQUE KEY `uq_reserva_activa` (`cancha_id`,`fecha`,`horario_id`,`reserva_activa`),
  ADD KEY `deporte_id` (`deporte_id`),
  ADD KEY `horario_id` (`horario_id`),
  ADD KEY `verificado_por` (`verificado_por`),
  ADD KEY `registrado_por` (`registrado_por`),
  ADD KEY `idx_fecha_cancha` (`fecha`,`cancha_id`),
  ADD KEY `idx_estado` (`estado`),
  ADD KEY `idx_usuario` (`usuario_id`),
  ADD KEY `idx_codigo` (`codigo`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_rol` (`rol`),
  ADD KEY `idx_bloqueada` (`cuenta_bloqueada`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `bloqueos_cancha`
--
ALTER TABLE `bloqueos_cancha`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `canchas`
--
ALTER TABLE `canchas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `cancha_deporte`
--
ALTER TABLE `cancha_deporte`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `deportes`
--
ALTER TABLE `deportes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `fotos_limpieza`
--
ALTER TABLE `fotos_limpieza`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `horarios`
--
ALTER TABLE `horarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `logs_acceso`
--
ALTER TABLE `logs_acceso`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `logs_reservas`
--
ALTER TABLE `logs_reservas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pagos`
--
ALTER TABLE `pagos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `politicas_cancelacion`
--
ALTER TABLE `politicas_cancelacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `reservas`
--
ALTER TABLE `reservas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `bloqueos_cancha`
--
ALTER TABLE `bloqueos_cancha`
  ADD CONSTRAINT `bloqueos_cancha_ibfk_1` FOREIGN KEY (`cancha_id`) REFERENCES `canchas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bloqueos_cancha_ibfk_2` FOREIGN KEY (`creado_por`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `cancha_deporte`
--
ALTER TABLE `cancha_deporte`
  ADD CONSTRAINT `cancha_deporte_ibfk_1` FOREIGN KEY (`cancha_id`) REFERENCES `canchas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cancha_deporte_ibfk_2` FOREIGN KEY (`deporte_id`) REFERENCES `deportes` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `fotos_limpieza`
--
ALTER TABLE `fotos_limpieza`
  ADD CONSTRAINT `fotos_limpieza_ibfk_1` FOREIGN KEY (`reserva_id`) REFERENCES `reservas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fotos_limpieza_ibfk_2` FOREIGN KEY (`subida_por`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `logs_acceso`
--
ALTER TABLE `logs_acceso`
  ADD CONSTRAINT `logs_acceso_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Filtros para la tabla `logs_reservas`
--
ALTER TABLE `logs_reservas`
  ADD CONSTRAINT `logs_reservas_ibfk_1` FOREIGN KEY (`reserva_id`) REFERENCES `reservas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `logs_reservas_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Filtros para la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD CONSTRAINT `pagos_ibfk_1` FOREIGN KEY (`reserva_id`) REFERENCES `reservas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `pagos_ibfk_2` FOREIGN KEY (`pagado_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `pagos_ibfk_3` FOREIGN KEY (`registrado_por`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD CONSTRAINT `reservas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `reservas_ibfk_2` FOREIGN KEY (`cancha_id`) REFERENCES `canchas` (`id`),
  ADD CONSTRAINT `reservas_ibfk_3` FOREIGN KEY (`deporte_id`) REFERENCES `deportes` (`id`),
  ADD CONSTRAINT `reservas_ibfk_4` FOREIGN KEY (`horario_id`) REFERENCES `horarios` (`id`),
  ADD CONSTRAINT `reservas_ibfk_5` FOREIGN KEY (`verificado_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `reservas_ibfk_6` FOREIGN KEY (`registrado_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
