<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/helpers.php';
require_once __DIR__ . '/../src/repositories/ReservaRepository.php';
require_once __DIR__ . '/../src/services/DisponibilidadService.php';

header('Content-Type: application/json');

protegerPagina(['trabajador', 'admin']);

$input = json_decode(file_get_contents('php://input'), true);
$reservaId = (int)($input['reserva_id'] ?? 0);

if (!$reservaId) {
    jsonResponse(['error' => 'Falta reserva_id'], 400);
}

$reservaRepo = new ReservaRepository();
$reserva = $reservaRepo->buscarPorId($reservaId);

if (!$reserva) {
    jsonResponse(['error' => 'Reserva no encontrada'], 404);
}

// Calcular tope de sobretiempo
$dispService = new DisponibilidadService();
$tope = $dispService->calcularTopeSobretiempo($reserva['cancha_id'], $reserva['fecha'], $reserva['hora_fin'] ?? '23:00:00');

// Marcar como finalizada
$pdo = Conexion::obtener();
$pdo->prepare("UPDATE reservas SET estado = 'finalizada', hora_salida_real = NOW() WHERE id = ?")->execute([$reservaId]);

jsonResponse([
    'exito' => true,
    'mensaje' => 'Reserva finalizada.',
    'tope_sobretiempo' => $tope
]);