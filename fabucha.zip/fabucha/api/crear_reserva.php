<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/helpers.php';
require_once __DIR__ . '/../src/services/ReservaService.php';

header('Content-Type: application/json');

if (!estaLogueado()) {
    jsonResponse(['error' => 'Debes iniciar sesión'], 401);
}

$input = json_decode(file_get_contents('php://input'), true);

$canchaId = (int)($input['cancha_id'] ?? 0);
$deporteId = (int)($input['deporte_id'] ?? 0);
$fecha = $input['fecha'] ?? '';
$horarioId = (int)($input['horario_id'] ?? 0);
$cantidadPersonas = (int)($input['cantidad_personas'] ?? 0);
$nombreEquipo = $input['nombre_equipo'] ?? null;

if (!$canchaId || !$deporteId || !$fecha || !$horarioId || !$cantidadPersonas) {
    jsonResponse(['error' => 'Faltan datos obligatorios'], 400);
}

$reservaService = new ReservaService();
$resultado = $reservaService->crearHold(
    $_SESSION['usuario_id'], $canchaId, $deporteId, $fecha, $horarioId, $cantidadPersonas, $nombreEquipo
);

jsonResponse($resultado, $resultado['exito'] ? 201 : 409);