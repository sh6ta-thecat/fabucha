<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/helpers.php';
require_once __DIR__ . '/../src/services/ReporteService.php';

header('Content-Type: application/json');

protegerPagina(['admin']);

$reporteService = new ReporteService();
$metricas = $reporteService->obtenerMetricasDashboard();
$grafico = $reporteService->obtenerIngresosUltimosMeses(6);

jsonResponse([
    'exito' => true,
    'metricas' => $metricas,
    'grafico_ingresos' => $grafico
]);