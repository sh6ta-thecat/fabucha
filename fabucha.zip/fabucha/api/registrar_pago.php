<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/helpers.php';
require_once __DIR__ . '/../src/services/PagoService.php';

header('Content-Type: application/json');

protegerPagina(['trabajador', 'admin']);

$input = json_decode(file_get_contents('php://input'), true);
$reservaId = (int)($input['reserva_id'] ?? 0);
$tipo = $input['tipo'] ?? 'reserva'; // reserva | sobretiempo | deposito
$metodo = $input['metodo'] ?? 'efectivo';
$monto = (float)($input['monto'] ?? 0);

if (!$reservaId || $monto <= 0) {
    jsonResponse(['error' => 'Datos inválidos'], 400);
}

$pagoService = new PagoService();
$resultado = $pagoService->registrarPago($reservaId, $tipo, $metodo, $monto, $_SESSION['usuario_id']);

jsonResponse($resultado, $resultado['exito'] ? 200 : 400);