<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/helpers.php';
require_once __DIR__ . '/../src/repositories/ReservaRepository.php';

header('Content-Type: application/json');

if (!estaLogueado()) {
    jsonResponse(['error' => 'Debes iniciar sesión'], 401);
}

$input = json_decode(file_get_contents('php://input'), true);
$reservaId = (int)($input['reserva_id'] ?? 0);

if (!$reservaId) {
    jsonResponse(['error' => 'Falta reserva_id'], 400);
}

$reservaRepo = new ReservaRepository();
$reserva = $reservaRepo->buscarPorId($reservaId);

if (!$reserva || $reserva['usuario_id'] != $_SESSION['usuario_id']) {
    jsonResponse(['error' => 'Reserva no encontrada o no te pertenece'], 404);
}

// Cambiar de hold a pendiente_pago (simulando confirmación)
$reservaRepo->actualizarEstado($reservaId, 'pendiente_pago', 'Confirmada por el cliente');

jsonResponse(['exito' => true, 'mensaje' => 'Reserva confirmada. Realiza el pago.']);