<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/helpers.php';
require_once __DIR__ . '/../src/repositories/ReservaRepository.php';

header('Content-Type: application/json');

protegerPagina(['trabajador', 'admin']);

$input = json_decode(file_get_contents('php://input'), true);
$reservaId = (int)($input['reserva_id'] ?? 0);

if (!$reservaId) {
    jsonResponse(['error' => 'Falta reserva_id'], 400);
}

$reservaRepo = new ReservaRepository();
$reservaRepo->actualizarEstado($reservaId, 'en_uso', 'Marcada en uso por trabajador');

// Guardar hora de ingreso real y quién verificó
$pdo = Conexion::obtener();
$pdo->prepare("UPDATE reservas SET hora_ingreso_real = NOW(), verificado_por = ? WHERE id = ?")
    ->execute([$_SESSION['usuario_id'], $reservaId]);

jsonResponse(['exito' => true, 'mensaje' => 'Reserva marcada como en uso.']);