<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/helpers.php';
require_once __DIR__ . '/../src/services/DisponibilidadService.php';

header('Content-Type: application/json');

$canchaId = isset($_GET['cancha']) ? (int)$_GET['cancha'] : 0;
$fecha = $_GET['fecha'] ?? date('Y-m-d');

if (!$canchaId) {
    jsonResponse(['error' => 'Falta el parámetro cancha'], 400);
}

$dispService = new DisponibilidadService();
$horarios = $dispService->obtenerHorariosLibres($canchaId, $fecha);

jsonResponse(['exito' => true, 'horarios' => $horarios]);