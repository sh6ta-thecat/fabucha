<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/helpers.php';
require_once __DIR__ . '/../src/services/CorreoService.php';

// Solo accesible desde CLI o con token secreto
$token = $_GET['token'] ?? '';
$tokenValido = defined('CRON_TOKEN') && hash_equals(CRON_TOKEN, $token);
$esCLI = (php_sapi_name() === 'cli');

if (!$tokenValido && !$esCLI) {
    http_response_code(403);
    exit('Acceso denegado');
}

$pdo = Conexion::obtener();
$correo = new CorreoService();

// 1. Enviar recordatorio a reservas que son MAÑANA
$manana = date('Y-m-d', strtotime('+1 day'));
$stmt = $pdo->prepare("
    SELECT r.*, u.email, u.nombre, c.nombre as cancha_nombre, h.hora_inicio
    FROM reservas r
    JOIN usuarios u ON r.usuario_id = u.id
    JOIN canchas c ON r.cancha_id = c.id
    JOIN horarios h ON r.horario_id = h.id
    WHERE r.fecha = ? AND r.estado IN ('pagada_total', 'pagada_parcial')
");
$stmt->execute([$manana]);
$reservas = $stmt->fetchAll();

$enviados = 0;
foreach ($reservas as $r) {
    $ok = $correo->enviarConfirmacionReserva(
        $r['email'], $r['nombre'], $r['codigo'], $r['cancha_nombre'], $r['fecha'], $r['hora_inicio'], $r['monto_total']
    );
    if ($ok) $enviados++;
}

// 2. Cancelar reservas vencidas (hold expirado o pago fuera de plazo)
$pdo->exec("UPDATE reservas SET estado = 'cancelada_falta_pago' WHERE estado = 'hold' AND expira_en < NOW()");
$pdo->exec("UPDATE reservas SET estado = 'cancelada_falta_pago' WHERE estado = 'pendiente_pago' AND limite_pago < NOW()");

if ($esCLI) {
    echo "Notificaciones enviadas: $enviados\n";
} else {
    jsonResponse(['exito' => true, 'correos_enviados' => $enviados]);
}