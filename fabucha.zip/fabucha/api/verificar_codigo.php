<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/helpers.php';
require_once __DIR__ . '/../src/repositories/ReservaRepository.php';

header('Content-Type: application/json');

protegerPagina(['trabajador', 'admin']);

$input = json_decode(file_get_contents('php://input'), true);
$codigo = strtoupper(trim($input['codigo'] ?? ''));

if (empty($codigo)) {
    jsonResponse(['error' => 'Falta el código'], 400);
}

$reservaRepo = new ReservaRepository();
$reserva = $reservaRepo->buscarPorCodigo($codigo);

if (!$reserva) {
    jsonResponse(['error' => 'Reserva no encontrada'], 404);
}

jsonResponse(['exito' => true, 'reserva' => $reserva]);