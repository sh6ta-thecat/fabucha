<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/helpers.php';
require_once __DIR__ . '/../src/repositories/FotoRepository.php';

header('Content-Type: application/json');

protegerPagina(['limpieza', 'admin', 'trabajador']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_FILES['foto'])) {
    jsonResponse(['error' => 'No se recibió ninguna foto'], 400);
}

$reservaId = (int)($_POST['reserva_id'] ?? 0);
$tipo = $_POST['tipo'] ?? 'despues';

if (!$reservaId) {
    jsonResponse(['error' => 'Falta reserva_id'], 400);
}

// Validar tipo de archivo y tamaño
$permitidos = ['image/jpeg', 'image/png', 'image/webp'];
if (!in_array($_FILES['foto']['type'], $permitidos)) {
    jsonResponse(['error' => 'Formato no permitido. Solo JPG, PNG o WEBP.'], 400);
}
if ($_FILES['foto']['size'] > 2 * 1024 * 1024) {
    jsonResponse(['error' => 'La imagen supera los 2 MB.'], 400);
}

// Guardar archivo
$dir = __DIR__ . '/../uploads/limpieza/';
if (!is_dir($dir)) mkdir($dir, 0777, true);
$ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
$filename = 'reserva_' . $reservaId . '_' . $tipo . '_' . time() . '.' . $ext;

if (!move_uploaded_file($_FILES['foto']['tmp_name'], $dir . $filename)) {
    jsonResponse(['error' => 'Error al guardar la imagen'], 500);
}

// Registrar en BD
$fotoRepo = new FotoRepository();
$fotoRepo->registrar([
    'reserva_id' => $reservaId,
    'ruta' => 'uploads/limpieza/' . $filename,
    'tipo' => $tipo,
    'subida_por' => $_SESSION['usuario_id']
]);

jsonResponse(['exito' => true, 'mensaje' => 'Foto subida correctamente.']);