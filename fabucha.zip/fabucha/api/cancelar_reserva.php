<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/helpers.php';
require_once __DIR__ . '/../src/services/ReservaService.php';
require_once __DIR__ . '/../src/repositories/ReservaRepository.php';

header('Content-Type: application/json');

if (!estaLogueado()) {
    jsonResponse(['error' => 'Debes iniciar sesión'], 401);
}

$input = json_decode(file_get_contents('php://input'), true);
$reservaId = (int)($input['reserva_id'] ?? 0);

if (!$reservaId) {
    jsonResponse(['error' => 'Falta reserva_id'], 400);
}

$reservaRepo = new ReservaRepository();
$reserva = $reservaRepo->buscarPorId($reservaId);

if (!$reserva) {
    jsonResponse(['error' => 'Reserva no encontrada'], 404);
}

// Permitir al dueño o a un admin
if ($reserva['usuario_id'] != $_SESSION['usuario_id'] && rolActual() !== 'admin') {
    jsonResponse(['error' => 'No tienes permiso para cancelar esta reserva'], 403);
}

$motivo = (rolActual() === 'admin') ? 'local' : 'cliente';
$reservaService = new ReservaService();
$resultado = $reservaService->cancelarReserva($reservaId, $motivo);

jsonResponse($resultado, $resultado['exito'] ? 200 : 400);