<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/repositories/UsuarioRepository.php';

protegerPagina(['admin']);
$usuarioRepo = new UsuarioRepository();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['desbloquear_id'])) {
    $usuarioRepo->desbloquearCuenta((int)$_POST['desbloquear_id']);
    $_SESSION['mensaje_exito'] = 'Usuario desbloqueado.';
    header('Location: admin_usuarios.php');
    exit;
}

$pdo = Conexion::obtener();
$usuarios = $pdo->query("SELECT * FROM usuarios ORDER BY creado_en DESC")->fetchAll();

$titulo = 'Gestión de Usuarios - Admin';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar_admin.php';
?>
<main class="container py-4">
    <h2 class="fw-bold text-white mb-4">Usuarios</h2>
    <?php if (isset($_SESSION['mensaje_exito'])): ?>
        <div class="alert alert-success bg-success bg-opacity-25 text-success border-0 small"><?= e($_SESSION['mensaje_exito']) ?></div>
        <?php unset($_SESSION['mensaje_exito']); ?>
    <?php endif; ?>
    <div class="card bg-dark border-secondary text-white">
        <div class="table-responsive">
            <table class="table table-dark table-hover mb-0">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Email</th>
                        <th>Rol</th>
                        <th>Estado</th>
                        <th>Deuda</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($usuarios as $u): ?>
                        <tr>
                            <td><?= e($u['nombre']) ?></td>
                            <td><?= e($u['email']) ?></td>
                            <td><span class="badge bg-secondary"><?= strtoupper($u['rol']) ?></span></td>
                            <td>
                                <?php if ($u['cuenta_bloqueada']): ?>
                                    <span class="badge bg-danger">Bloqueado</span>
                                <?php else: ?>
                                    <span class="badge bg-success">Activo</span>
                                <?php endif; ?>
                            </td>
                            <td>S/ <?= number_format($u['deuda_pendiente'], 2) ?></td>
                            <td>
                                <?php if ($u['cuenta_bloqueada']): ?>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="desbloquear_id" value="<?= $u['id'] ?>">
                                        <button class="btn btn-sm btn-outline-success">Desbloquear</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
<?php require_once __DIR__ . '/partials/footer.php'; ?>