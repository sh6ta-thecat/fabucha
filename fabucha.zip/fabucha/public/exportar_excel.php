<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/repositories/PagoRepository.php';
require_once __DIR__ . '/../vendor/autoload.php';

protegerPagina(['admin']);
$pagoRepo = new PagoRepository();
$desde = $_GET['desde'] ?? date('Y-m-01');
$hasta = $_GET['hasta'] ?? date('Y-m-d');
$total = $pagoRepo->obtenerIngresosPorRango($desde, $hasta);

$spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setCellValue('A1', 'Reporte de Ingresos - Fabucha');
$sheet->setCellValue('A3', 'Desde');
$sheet->setCellValue('B3', $desde);
$sheet->setCellValue('A4', 'Hasta');
$sheet->setCellValue('B4', $hasta);
$sheet->setCellValue('A5', 'Total Ingresos');
$sheet->setCellValue('B5', $total);

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="reporte_fabucha.xlsx"');
$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
$writer->save('php://output');
exit;