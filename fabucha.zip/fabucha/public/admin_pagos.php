<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/services/PagoService.php';
require_once __DIR__ . '/../src/repositories/ReservaRepository.php';

protegerPagina(['admin']);
$pagoService = new PagoService();
$reservaRepo = new ReservaRepository();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pagoService->registrarPago(
        (int)$_POST['reserva_id'],
        'reserva',
        $_POST['metodo'],
        (float)$_POST['monto'],
        $_SESSION['usuario_id'],
        null,
        null
    );
    $_SESSION['mensaje_exito'] = 'Pago registrado.';
    header('Location: admin_pagos.php');
    exit;
}

// Reservas que deben dinero
$pdo = Conexion::obtener();
$pendientes = $pdo->query("SELECT id, codigo, monto_total, monto_pagado FROM reservas WHERE estado IN ('pendiente_pago', 'pagada_parcial') LIMIT 50")->fetchAll();
$pagosRecientes = $pdo->query("SELECT p.*, r.codigo as reserva_codigo FROM pagos p JOIN reservas r ON p.reserva_id = r.id ORDER BY p.fecha_pago DESC LIMIT 20")->fetchAll();

$titulo = 'Pagos - Admin';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar_admin.php';
?>
<main class="container py-4">
    <h2 class="fw-bold text-white mb-4">Gestión de Pagos</h2>
    <div class="row">
        <div class="col-md-5 mb-4">
            <div class="card bg-dark border-secondary text-white">
                <div class="card-header border-secondary">Registrar Pago</div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Reserva (Pendiente)</label>
                            <select name="reserva_id" class="form-select bg-dark text-white border-secondary" required>
                                <?php foreach ($pendientes as $p): ?>
                                    <option value="<?= $p['id'] ?>"><?= e($p['codigo']) ?> (Saldo: S/ <?= number_format($p['monto_total'] - $p['monto_pagado'], 2) ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="row">
                            <div class="col-6 mb-3">
                                <label class="form-label">Monto</label>
                                <input type="number" step="0.01" name="monto" class="form-control bg-dark text-white border-secondary" required>
                            </div>
                            <div class="col-6 mb-3">
                                <label class="form-label">Método</label>
                                <select name="metodo" class="form-select bg-dark text-white border-secondary">
                                    <option value="efectivo">Efectivo</option>
                                    <option value="yape">Yape</option>
                                    <option value="plin">Plin</option>
                                    <option value="transferencia">Transferencia</option>
                                </select>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-fb-primary w-100">Registrar Pago</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-7">
            <div class="card bg-dark border-secondary text-white">
                <div class="card-header border-secondary">Pagos Recientes</div>
                <div class="table-responsive">
                    <table class="table table-dark table-hover mb-0">
                        <thead><tr><th>Reserva</th><th>Tipo</th><th>Monto</th><th>Método</th><th>Fecha</th></tr></thead>
                        <tbody>
                            <?php foreach ($pagosRecientes as $p): ?>
                                <tr>
                                    <td><?= e($p['reserva_codigo']) ?></td>
                                    <td><span class="badge bg-secondary"><?= $p['tipo'] ?></span></td>
                                    <td>S/ <?= number_format($p['monto'], 2) ?></td>
                                    <td><?= strtoupper($p['metodo']) ?></td>
                                    <td class="small"><?= date('d/m H:i', strtotime($p['fecha_pago'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php require_once __DIR__ . '/partials/footer.php'; ?>