<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/conexion.php';
require_once __DIR__ . '/../src/helpers.php';

$titulo = 'Fabucha - Encuentra tu cancha en segundos';
require_once __DIR__ . '/partials/header.php';

$pdo = Conexion::obtener();

// Obtener canchas para las tarjetas
$canchas = $pdo->query(
    "SELECT c.id, c.nombre, c.aforo_maximo, c.capacidad_tribuna,
            MIN(cd.precio_hora) as precio_min,
            GROUP_CONCAT(DISTINCT d.nombre SEPARATOR ' / ') AS deportes
     FROM canchas c
     LEFT JOIN cancha_deporte cd ON cd.cancha_id = c.id
     LEFT JOIN deportes d ON d.id = cd.deporte_id AND d.activo = 1
     WHERE c.activa = 1
     GROUP BY c.id
     ORDER BY c.nombre LIMIT 3"
)->fetchAll();
?>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg fb-navbar fixed-top">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <i class="bi bi-circle-fill" style="font-size: 0.8rem; color: var(--fb-green);"></i> 
            Fabucha<span>.</span>
        </a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
            <i class="bi bi-list text-white fs-2"></i>
        </button>
        <div class="collapse navbar-collapse" id="navMain">
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0 gap-3">
                <li class="nav-item"><a class="nav-link" href="#">Deportes</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Canchas</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Zonas</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Cómo funciona</a></li>
            </ul>
            <div class="d-flex gap-2 mt-3 mt-lg-0">
                <?php if (estaLogueado()): ?>
                    <?php if (rolActual() === 'admin'): ?>
                        <a href="panel_admin.php" class="btn btn-fb-outline">Panel de administración</a>
                    <?php elseif (rolActual() === 'trabajador'): ?>
                        <a href="panel_trabajador.php" class="btn btn-fb-outline">Panel del trabajador</a>
                    <?php elseif (rolActual() === 'limpieza'): ?>
                        <a href="panel_limpieza.php" class="btn btn-fb-outline">Panel de limpieza</a>
                    <?php else: ?>
                        <a href="mis_reservas.php" class="btn btn-fb-outline">Mis reservas</a>
                    <?php endif; ?>
                    <a href="logout.php" class="btn btn-fb-primary">Salir</a>
                <?php else: ?>
                    <a href="login.php" class="btn btn-fb-outline"><i class="bi bi-person"></i> Iniciar sesión</a>
                    <a href="registro.php" class="btn btn-fb-primary">Registrarme</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<!-- HERO -->
<section class="fb-hero pt-5 mt-5">
    <div class="container">
        <h1>Encuentra tu cancha<br>en <span>segundos</span></h1>
        <p>Canchas disponibles en Fabucha. Reserva en línea cuando quieras, sin necesidad de llamar.</p>
        
        <!-- Buscador -->
        <form action="reservar.php" method="GET" class="fb-search-bar mt-4">
            <div class="fb-search-item">
                <label>Lugar</label>
                <input type="text" placeholder="Fabucha - Chincha" value="Fabucha" readonly>
            </div>
            <div class="fb-search-item">
                <label>Deporte</label>
                <select name="deporte">
                    <option value="">Todos los deportes</option>
                    <option value="1">Fútbol 5</option>
                    <option value="2">Fútbol 7</option>
                    <option value="3">Vóley</option>
                    <option value="4">Básquet</option>
                </select>
            </div>
            <div class="fb-search-item">
                <label>Fecha</label>
                <input type="date" name="fecha" min="<?= date('Y-m-d') ?>" value="<?= date('Y-m-d') ?>">
            </div>
            <div class="fb-search-item">
                <label>Hora</label>
                <select name="hora">
                    <option value="">Cualquier horario</option>
                    <?php for ($h = 8; $h <= 22; $h++): ?>
                        <option value="<?= sprintf('%02d:00', $h) ?>"><?= sprintf('%02d:00', $h) ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-fb-primary px-4 py-3">
                <i class="bi bi-search"></i> Buscar
            </button>
        </form>
    </div>
</section>

<!-- DEPORTES -->
<section class="fb-section pt-0">
    <div class="container">
        <h2 class="fb-section-title">¿Qué deporte quieres practicar hoy?</h2>
        <p class="fb-section-subtitle">Canchas para todos los deportes, en un solo lugar.</p>
        
        <div class="row g-3">
            <?php 
            $deportes = [
                ['icon' => 'bi-dribbble', 'name' => 'Fútbol 5', 'id' => 1],
                ['icon' => 'bi-dribbble', 'name' => 'Fútbol 7', 'id' => 2],
                ['icon' => 'bi-circle', 'name' => 'Vóley', 'id' => 3],
                ['icon' => 'bi-circle-fill', 'name' => 'Básquet', 'id' => 4]
            ];
            foreach ($deportes as $d): ?>
                <div class="col-6 col-md-3">
                    <a href="reservar.php?deporte=<?= $d['id'] ?>" class="text-decoration-none text-white">
                        <div class="fb-sport-card">
                            <i class="bi <?= $d['icon'] ?>"></i>
                            <span><?= $d['name'] ?></span>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="text-center mt-4">
            <button class="btn btn-fb-outline btn-sm">Ver más deportes <i class="bi bi-chevron-down ms-1"></i></button>
        </div>
    </div>
</section>

<!-- CANCHAS CERCANAS -->
<section class="fb-section bg-dark bg-opacity-25">
    <div class="container">
        <div class="d-flex justify-content-between align-items-end mb-4">
            <div>
                <h2 class="fb-section-title mb-1">Canchas cerca de ti</h2>
                <p class="fb-section-subtitle mb-0">Reserva en segundos. En algunas canchas no necesitas realizar un pago por adelantado.</p>
            </div>
        </div>

        <div class="row g-4">
            <?php if (empty($canchas)): ?>
                <div class="col-12 text-white-50">No hay canchas disponibles en este momento.</div>
            <?php else: ?>
                <?php foreach ($canchas as $i => $c): ?>
                    <div class="col-md-4">
                        <div class="fb-court-card">
                            <!-- Placeholder de imagen, usa una URL real si tienes -->
                            <div class="fb-court-img" style="background-image: url('https://images.unsplash.com/photo-1575361204480-aadea25e6e68?q=80&w=800&auto=format&fit=crop');">
                                <span class="fb-court-badge"><?= e($c['deportes'] ?? 'Sin deporte asignado') ?></span>
                            </div>
                            <div class="fb-court-body">
                                <h4 class="fb-court-title"><?= e($c['nombre']) ?></h4>
                                <p class="fb-court-loc"><i class="bi bi-geo-alt me-1"></i> Fabucha - Chincha</p>
                                
                                <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top border-secondary border-opacity-25">
                                    <div class="fb-court-price">
                                        <?= soles((float)($c['precio_min'] ?? 0)) ?>
                                        <span>/hora</span>
                                    </div>
                                    <a href="reservar.php?cancha=<?= $c['id'] ?>" class="btn btn-fb-primary btn-sm">Reservar</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <div class="text-center mt-5">
            <a href="reservar.php" class="btn btn-fb-outline">Ver todas las canchas <i class="bi bi-arrow-right ms-1"></i></a>
        </div>
    </div>
</section>

<!-- CÓMO FUNCIONA -->
<section class="fb-section">
    <div class="container">
        <h2 class="fb-section-title">Reservar nunca fue tan fácil</h2>
        <p class="fb-section-subtitle">Tres pasos y ya estás listo para jugar.</p>
        
        <div class="fb-steps">
            <div class="fb-step">
                <div class="fb-step-num">1</div>
                <h5>Encuentra tu cancha</h5>
                <p>Filtra por deporte, fecha y hora. Encuentra la cancha ideal en segundos.</p>
            </div>
            <div class="fb-step">
                <div class="fb-step-num">2</div>
                <h5>Elige el horario</h5>
                <p>La disponibilidad se actualiza en tiempo real. Confirma al instante.</p>
            </div>
            <div class="fb-step">
                <div class="fb-step-num">3</div>
                <h5>¡A jugar!</h5>
                <p>Recibe la confirmación por correo electrónico con tu código único. Paga en línea o al llegar.</p>
            </div>
        </div>
    </div>
</section>

<!-- TESTIMONIOS -->
<section class="fb-section bg-dark bg-opacity-25">
    <div class="container">
        <h2 class="fb-section-title">Lo que dicen los jugadores</h2>
        <p class="fb-section-subtitle">Miles de reservas exitosas.</p>
        
        <div class="row g-4">
            <div class="col-md-4">
                <div class="fb-testimonial">
                    <div class="fb-stars"><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i></div>
                    <p>"Reservar es muy rápido. Antes tenía que llamar y esperar; ahora puedo hacerlo todo desde mi celular en un minuto."</p>
                    <div class="fb-user">
                        <div class="fb-user-avatar">JP</div>
                        <div class="fb-user-info">
                            <h6>Juan P.</h6>
                            <span>Jugador de Fútbol 5</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="fb-testimonial">
                    <div class="fb-stars"><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i></div>
                    <p>"El calendario de disponibilidad en tiempo real es lo mejor. Ya no hay excusas para no jugar con los amigos."</p>
                    <div class="fb-user">
                        <div class="fb-user-avatar">MR</div>
                        <div class="fb-user-info">
                            <h6>María R.</h6>
                            <span>Organizadora de Vóley</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="fb-testimonial">
                    <div class="fb-stars"><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-half"></i></div>
                    <p>"El código de confirmación es muy útil. Llegas, lo muestras y listo. Sin trámites ni esperas."</p>
                    <div class="fb-user">
                        <div class="fb-user-avatar">LF</div>
                        <div class="fb-user-info">
                            <h6>Luis F.</h6>
                            <span>Jugador de Básquet</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<!-- FOOTER -->
<footer class="fb-footer">
    <div class="container">
        <div class="row g-4 mb-5">
            <div class="col-lg-4">
                <a class="navbar-brand mb-3 d-block" href="index.php" style="font-size: 1.5rem;">
                    <i class="bi bi-circle-fill" style="font-size: 0.8rem; color: var(--fb-green);"></i> 
                    Fabucha<span style="color:var(--fb-green)">.</span>
                </a>
                <p class="text-white-50 small">La plataforma ideal para reservar tu cancha deportiva. Juega cuando quieras y sin complicaciones.</p>
            </div>
            <div class="col-6 col-lg-2 offset-lg-1">
                <h6>Jugadores</h6>
                <a href="reservar.php">Buscar canchas</a>
                <a href="registro.php">Registrarme</a>
                <a href="login.php">Iniciar sesión</a>
            </div>
            <div class="col-6 col-lg-2">
                <h6>Deportes</h6>
                <a href="reservar.php?deporte=1">Fútbol 5</a>
                <a href="reservar.php?deporte=2">Fútbol 7</a>
                <a href="reservar.php?deporte=3">Vóley</a>
                <a href="reservar.php?deporte=4">Básquet</a>
            </div>
            <div class="col-6 col-lg-2">
                <h6>Fabucha</h6>
                <a href="#">Sobre nosotros</a>
                <a href="#">Contacto</a>
                <a href="#">Política de privacidad</a>
            </div>
        </div>
        <div class="border-top border-secondary border-opacity-25 pt-4 d-flex flex-column flex-md-row justify-content-between align-items-center">
            <p class="text-white-50 small mb-0">&copy; <?= date('Y') ?> Fabucha. Todos los deportes los derechos reservados.</p>
            <div class="d-flex gap-3 mt-3 mt-md-0">
                <a href="#" class="text-white-50"><i class="bi bi-facebook"></i></a>
                <a href="#" class="text-white-50"><i class="bi bi-instagram"></i></a>
                <a href="#" class="text-white-50"><i class="bi bi-whatsapp"></i></a>
            </div>
        </div>
    </div>
</footer>

<?php require_once __DIR__ . '/partials/footer.php'; ?>