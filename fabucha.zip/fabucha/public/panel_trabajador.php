<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/repositories/ReservaRepository.php';
require_once __DIR__ . '/../src/repositories/UsuarioRepository.php';
require_once __DIR__ . '/../src/repositories/FotoRepository.php';
require_once __DIR__ . '/../src/services/PagoService.php';

protegerPagina(['trabajador', 'admin']);
$reservaRepo = new ReservaRepository();
$pagoService = new PagoService();
$mensaje = '';

// PROCESAR ACCIONES (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? '';
    $reservaId = (int)($_POST['reserva_id'] ?? 0);

    if ($accion === 'en_uso') {
        $reservaRepo->actualizarEstado($reservaId, 'en_uso', 'Marcada en uso por trabajador');
        // Guardar hora de ingreso
        $pdo = Conexion::obtener();
        $pdo->prepare("UPDATE reservas SET hora_ingreso_real = NOW(), verificado_por = ? WHERE id = ?")->execute([$_SESSION['usuario_id'], $reservaId]);
        $mensaje = 'Reserva marcada como EN USO.';
    } elseif ($accion === 'finalizar') {
        // Aquí se podría calcular sobretiempo antes de finalizar, pero simplificamos para el flujo básico
        $pdo = Conexion::obtener();
        $pdo->prepare("UPDATE reservas SET estado = 'finalizada', hora_salida_real = NOW() WHERE id = ?")->execute([$reservaId]);
        $mensaje = 'Reserva FINALIZADA.';
    } elseif ($accion === 'no_show') {
        $pdo = Conexion::obtener();
        $pdo->prepare("UPDATE reservas SET estado = 'no_show' WHERE id = ?")->execute([$reservaId]);
        $mensaje = 'Reserva marcada como NO SHOW (se retiene depósito).';
    }
    $_SESSION['mensaje_exito'] = $mensaje;
    header('Location: panel_trabajador.php');
    exit;
}

$fechaHoy = date('Y-m-d');
$reservas = $reservaRepo->obtenerReservasDelDia($fechaHoy);
$titulo = 'Panel Trabajador - Fabucha';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar_trabajador.php';
?>

<main class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold text-white mb-1">Reservas de Hoy</h2>
            <p class="text-muted small mb-0"><?= fechaLegible($fechaHoy) ?></p>
        </div>
        <a href="verificar.php" class="btn btn-primary" style="background-color: #3b82f6; border: none;">
            <i class="bi bi-upc-scan"></i> Verificar Código
        </a>
    </div>

    <?php if (isset($_SESSION['mensaje_exito'])): ?>
        <div class="alert alert-success bg-success bg-opacity-25 text-success border-0 small">
            <i class="bi bi-check-circle me-1"></i> <?= htmlspecialchars($_SESSION['mensaje_exito']) ?>
        </div>
        <?php unset($_SESSION['mensaje_exito']); ?>
    <?php endif; ?>

    <div class="card bg-dark border-secondary text-white">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Hora</th>
                            <th>Cancha</th>
                            <th>Cliente</th>
                            <th>Estado</th>
                            <th class="text-end">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($reservas)): ?>
                            <tr><td colspan="6" class="text-center text-muted py-4">No hay reservas para hoy.</td></tr>
                        <?php else: ?>
                            <?php foreach ($reservas as $r): ?>
                                <tr class="align-middle">
                                    <td><span class="badge bg-secondary"><?= e($r['codigo']) ?></span></td>
                                    <td><?= substr($r['hora_inicio'], 0, 5) ?> - <?= substr($r['hora_fin'], 0, 5) ?></td>
                                    <td><?= e($r['cancha_nombre']) ?></td>
                                    <td><?= e($r['cliente_nombre']) ?></td>
                                    <td>
                                        <?php 
                                        $badge = 'secondary';
                                        if ($r['estado'] === 'pagada_total') $badge = 'success';
                                        if ($r['estado'] === 'pagada_parcial') $badge = 'warning';
                                        if ($r['estado'] === 'en_uso') $badge = 'primary';
                                        if ($r['estado'] === 'finalizada') $badge = 'info';
                                        ?>
                                        <span class="badge bg-<?= $badge ?>"><?= strtoupper($r['estado']) ?></span>
                                    </td>
                                    <td class="text-end">
                                        <?php if ($r['estado'] === 'pagada_total'): ?>
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="reserva_id" value="<?= $r['id'] ?>">
                                                <input type="hidden" name="accion" value="en_uso">
                                                <button class="btn btn-sm btn-primary">Marcar En Uso</button>
                                            </form>
                                        <?php elseif ($r['estado'] === 'en_uso'): ?>
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="reserva_id" value="<?= $r['id'] ?>">
                                                <input type="hidden" name="accion" value="finalizar">
                                                <button class="btn btn-sm btn-info text-white">Finalizar</button>
                                            </form>
                                        <?php else: ?>
                                            <button class="btn btn-sm btn-secondary" disabled>Sin acciones</button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<?php require_once __DIR__ . '/partials/footer.php'; ?>