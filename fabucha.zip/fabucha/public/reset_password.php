<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/helpers.php';
$titulo = 'Nueva Contraseña - Fabucha';
require_once __DIR__ . '/partials/header.php';

// Validar que venga un token en la URL
$token = $_GET['token'] ?? '';
if (empty($token)) {
    $_SESSION['error_login'] = 'Enlace inválido. Solicita uno nuevo.';
    header('Location: login.php');
    exit;
}
?>

<div class="container d-flex justify-content-center align-items-center min-vh-100 py-5">
    <div class="card border-0 shadow-lg" style="max-width: 440px; width: 100%; background-color: var(--fb-card); border: 1px solid var(--fb-border) !important; border-radius: 16px;">
        <div class="card-body p-4 p-md-5">
            
            <div class="text-center mb-5">
                <a href="index.php" class="text-decoration-none">
                    <h2 class="fw-bold mb-1" style="color: var(--fb-text); letter-spacing: -0.5px;">
                        <i class="bi bi-circle-fill" style="font-size: 0.8rem; color: var(--fb-green);"></i> 
                        Fabucha<span style="color: var(--fb-green);">.</span>
                    </h2>
                </a>
                <div class="mt-4 mb-2">
                    <i class="bi bi-shield-check text-success" style="font-size: 2.5rem;"></i>
                </div>
                <h4 class="text-white fw-bold mb-1">Nueva contraseña</h4>
                <p class="small" style="color: var(--fb-text-muted);">Ingresa y confirma tu nueva contraseña.</p>
            </div>

            <?php if (isset($_SESSION['error_reset'])): ?>
                <div class="alert alert-danger py-2 small border-0" style="background-color: rgba(220, 38, 38, 0.1); color: #fca5a5;">
                    <i class="bi bi-exclamation-triangle me-1"></i> <?= htmlspecialchars($_SESSION['error_reset']) ?>
                </div>
                <?php unset($_SESSION['error_reset']); ?>
            <?php endif; ?>

            <form id="formReset" action="../src/procesar_reset.php" method="POST" novalidate>
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
                <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">

                <div class="mb-3">
                    <label for="password" class="form-label small fw-bold" style="color: var(--fb-text-muted);">Nueva contraseña</label>
                    <div class="input-group input-group-lg">
                        <input type="password" class="form-control bg-dark text-white border-secondary" id="password" name="password"
                               placeholder="Mínimo 8 caracteres" required minlength="8"
                               pattern="(?=.*[A-Z])(?=.*[0-9]).{8,}" autocomplete="new-password" style="font-size: 0.95rem; border-right: none;">
                        <button class="btn btn-outline-secondary border-secondary" type="button" id="togglePassword" style="border-left: none;">
                            <i class="bi bi-eye text-white-50"></i>
                        </button>
                    </div>
                    <div class="invalid-feedback">
                        Mínimo 8 caracteres, una mayúscula y un número.
                    </div>
                    <div class="form-text small mt-1" style="color: var(--fb-text-muted);">
                        <i class="bi bi-info-circle"></i> Debe tener al menos 8 caracteres, una mayúscula y un número.
                    </div>
                </div>

                <div class="mb-4">
                    <label for="password_confirm" class="form-label small fw-bold" style="color: var(--fb-text-muted);">Confirmar contraseña</label>
                    <input type="password" class="form-control form-control-lg bg-dark text-white border-secondary" id="password_confirm" name="password_confirm"
                           placeholder="Repite tu contraseña" required autocomplete="new-password" style="font-size: 0.95rem;">
                    <div class="invalid-feedback">Las contraseñas no coinciden.</div>
                </div>

                <button type="submit" class="btn btn-fb-primary w-100 py-3 fw-bold fs-6">
                    <i class="bi bi-check-circle me-2"></i> Cambiar contraseña
                </button>
            </form>

            <div class="text-center mt-4 pt-3 border-top border-secondary border-opacity-25">
                <p class="small mb-0" style="color: var(--fb-text-muted);">
                    <a href="login.php" class="text-decoration-none fw-bold" style="color: var(--fb-green);">
                        <i class="bi bi-arrow-left me-1"></i> Volver al inicio de sesión
                    </a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/partials/footer.php'; ?>