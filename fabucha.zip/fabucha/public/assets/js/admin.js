// Aquí se inicializarán los gráficos del panel administrativo con Chart.js.
