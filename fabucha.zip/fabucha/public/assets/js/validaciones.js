// Validación de formularios con Bootstrap
document.addEventListener('DOMContentLoaded', () => {

    // Mostrar/ocultar contraseña
    document.querySelectorAll('#togglePassword').forEach(btn => {
        btn.addEventListener('click', () => {
            const input = btn.parentElement.querySelector('input');
            const icon = btn.querySelector('i');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('bi-eye', 'bi-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('bi-eye-slash', 'bi-eye');
            }
        });
    });

    // Validación genérica de formularios
    const forms = document.querySelectorAll('form[novalidate]');
    forms.forEach(form => {
        form.addEventListener('submit', event => {
            // Validar confirmación de contraseña
            const pass = form.querySelector('#password');
            const passConfirm = form.querySelector('#password_confirm');
            if (pass && passConfirm) {
                if (pass.value !== passConfirm.value) {
                    passConfirm.setCustomValidity('No coinciden');
                } else {
                    passConfirm.setCustomValidity('');
                }
            }

            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // Limpiar validez al escribir
    document.querySelectorAll('input').forEach(input => {
        input.addEventListener('input', () => {
            input.setCustomValidity('');
        });
    });
});