// Consulta de disponibilidad desde el calendario.
async function cargarDisponibilidad(cancha, fecha) {
    const url = `/fabucha/api/disponibilidad.php?cancha=${encodeURIComponent(cancha)}&fecha=${encodeURIComponent(fecha)}`;
    const respuesta = await fetch(url, { headers: { Accept: 'application/json' } });
    if (!respuesta.ok) throw new Error('No se pudo consultar la disponibilidad.');
    return respuesta.json();
}
