// Lógica del formulario de reserva.
document.addEventListener('DOMContentLoaded', () => {
    const formulario = document.querySelector('[data-form-reserva]');
    if (!formulario) return;

    formulario.addEventListener('submit', (evento) => {
        // TODO: validar cancha, fecha y horario antes de enviar.
    });
});
