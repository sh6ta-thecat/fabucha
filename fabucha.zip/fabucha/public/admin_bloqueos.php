<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/repositories/BloqueoRepository.php';
require_once __DIR__ . '/../src/repositories/CanchaRepository.php';

protegerPagina(['admin']);
$bloqueoRepo = new BloqueoRepository();
$canchaRepo = new CanchaRepository();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bloqueoRepo->crear([
        'cancha_id' => (int)$_POST['cancha_id'],
        'fecha_inicio' => $_POST['fecha_inicio'],
        'fecha_fin' => $_POST['fecha_fin'],
        'motivo' => $_POST['motivo'],
        'creado_por' => $_SESSION['usuario_id']
    ]);
    $_SESSION['mensaje_exito'] = 'Bloqueo registrado.';
    header('Location: admin_bloqueos.php');
    exit;
}

$canchas = $canchaRepo->obtenerTodasConDeportes();
$titulo = 'Bloqueos - Admin';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar_admin.php';
?>
<main class="container py-4">
    <h2 class="fw-bold text-white mb-4">Bloqueos de Cancha</h2>
    
    <?php if (isset($_SESSION['mensaje_exito'])): ?>
        <div class="alert alert-success bg-success bg-opacity-25 text-success border-0 small"><?= e($_SESSION['mensaje_exito']) ?></div>
        <?php unset($_SESSION['mensaje_exito']); ?>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-5 mb-4">
            <div class="card bg-dark border-secondary text-white">
                <div class="card-header border-secondary">Registrar Bloqueo</div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Cancha</label>
                            <select name="cancha_id" class="form-select bg-dark text-white border-secondary" required>
                                <?php foreach ($canchas as $c): ?>
                                    <option value="<?= $c['id'] ?>"><?= e($c['nombre']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="row">
                            <div class="col-6 mb-3">
                                <label class="form-label">Desde</label>
                                <input type="datetime-local" name="fecha_inicio" class="form-control bg-dark text-white border-secondary" required>
                            </div>
                            <div class="col-6 mb-3">
                                <label class="form-label">Hasta</label>
                                <input type="datetime-local" name="fecha_fin" class="form-control bg-dark text-white border-secondary" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Motivo</label>
                            <input type="text" name="motivo" class="form-control bg-dark text-white border-secondary" required placeholder="Ej. Mantenimiento de grass">
                        </div>
                        <button type="submit" class="btn btn-fb-primary w-100">Registrar Bloqueo</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
<?php require_once __DIR__ . '/partials/footer.php'; ?>