<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/repositories/HorarioRepository.php';

protegerPagina(['admin']);
$horarioRepo = new HorarioRepository();
$horarios = $horarioRepo->obtenerTodos();

$titulo = 'Gestión de Horarios - Admin';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar_admin.php';
?>

<main class="container py-4">
    <h2 class="fw-bold text-white mb-4">Horarios</h2>
    <div class="card bg-dark border-secondary text-white">
        <div class="table-responsive">
            <table class="table table-dark table-hover mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Hora Inicio</th>
                        <th>Hora Fin</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($horarios as $h): ?>
                        <tr>
                            <td><?= $h['id'] ?></td>
                            <td><?= substr($h['hora_inicio'], 0, 5) ?></td>
                            <td><?= substr($h['hora_fin'], 0, 5) ?></td>
                            <td><span class="badge bg-<?= $h['activo'] ? 'success' : 'danger' ?>"><?= $h['activo'] ? 'Activo' : 'Inactivo' ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
<?php require_once __DIR__ . '/partials/footer.php'; ?>