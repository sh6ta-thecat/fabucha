<?php
// Asegurarse de que los helpers y la sesión estén cargados
if (!function_exists('e')) {
    require_once __DIR__ . '/../../src/helpers.php';
}
?>
<nav class="navbar navbar-expand-lg fb-navbar fixed-top">
    <div class="container">
        <!-- Logo -->
        <a class="navbar-brand" href="index.php">
            <i class="bi bi-circle-fill" style="font-size: 0.8rem; color: var(--fb-green);"></i> 
            Fabucha<span style="color: var(--fb-green);">.</span>
        </a>

        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCliente">
            <i class="bi bi-list text-white fs-2"></i>
        </button>

        <div class="collapse navbar-collapse" id="navbarCliente">
            <!-- Enlaces centrales -->
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0 gap-3">
                <li class="nav-item">
                    <a class="nav-link" href="index.php"><i class="bi bi-house-door me-1"></i> Inicio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="reservar.php"><i class="bi bi-calendar-plus me-1"></i> Reservar</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="mis_reservas.php"><i class="bi bi-clock-history me-1"></i> Mis Reservas</a>
                </li>
            </ul>

            <!-- Menú de usuario -->
            <div class="d-flex align-items-center gap-3 mt-3 mt-lg-0">
                <?php if (isset($_SESSION['deuda_pendiente']) && $_SESSION['deuda_pendiente'] > 0): ?>
                    <span class="badge bg-danger rounded-pill" title="Tienes una deuda pendiente">
                        <i class="bi bi-exclamation-triangle"></i> Deuda
                    </span>
                <?php endif; ?>

                <div class="dropdown">
                    <button class="btn btn-fb-outline dropdown-toggle d-flex align-items-center gap-2" type="button" data-bs-toggle="dropdown">
                        <div class="bg-secondary rounded-circle d-flex align-items-center justify-content-center" style="width: 28px; height: 28px; font-size: 12px; font-weight: bold;">
                            <?= strtoupper(substr($_SESSION['nombre'] ?? 'U', 0, 1)) ?>
                        </div>
                        <span class="d-none d-md-inline"><?= e(explode(' ', $_SESSION['nombre'] ?? 'Usuario')[0]) ?></span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-dark shadow">
                        <li><h6 class="dropdown-header"><?= e($_SESSION['email'] ?? '') ?></h6></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="perfil.php"><i class="bi bi-person me-2"></i> Mi Perfil</a></li>
                        <li><a class="dropdown-item" href="mis_reservas.php"><i class="bi bi-ticket-perforated me-2"></i> Mis Reservas</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i> Cerrar Sesión</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>

<!-- Margen superior para compensar el navbar fixed -->
<div style="height: 76px;"></div>