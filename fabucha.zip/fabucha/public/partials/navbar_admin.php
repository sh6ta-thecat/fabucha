<?php
if (!function_exists('e')) {
    require_once __DIR__ . '/../../src/helpers.php';
}
?>
<nav class="navbar navbar-expand-lg fb-navbar fixed-top" style="border-bottom: 2px solid #a855f7;">
    <div class="container-fluid px-4">
        <!-- Logo -->
        <a class="navbar-brand" href="panel_admin.php">
            <i class="bi bi-circle-fill" style="font-size: 0.8rem; color: #a855f7;"></i> 
            Fabucha<span style="color: #a855f7;">.</span>
            <small class="text-muted fs-6 ms-2 fw-normal">| Admin</small>
        </a>

        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarAdmin">
            <i class="bi bi-list text-white fs-2"></i>
        </button>

        <div class="collapse navbar-collapse" id="navbarAdmin">
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0 gap-2">
                <li class="nav-item">
                    <a class="nav-link" href="panel_admin.php">
                        <i class="bi bi-speedometer2 me-1"></i> Dashboard
                    </a>
                </li>
                
                <!-- Dropdown Gestión -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-sliders me-1"></i> Gestión
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark shadow">
                        <li><a class="dropdown-item" href="admin_canchas.php"><i class="bi bi-square me-2"></i> Canchas</a></li>
                        <li><a class="dropdown-item" href="admin_horarios.php"><i class="bi bi-clock me-2"></i> Horarios</a></li>
                        <li><a class="dropdown-item" href="admin_bloqueos.php"><i class="bi bi-calendar-x me-2"></i> Bloqueos</a></li>
                    </ul>
                </li>

                <!-- Dropdown Reservas y Pagos -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-journal-text me-1"></i> Reservas
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark shadow">
                        <li><a class="dropdown-item" href="admin_reservas.php"><i class="bi bi-list-ul me-2"></i> Todas las Reservas</a></li>
                        <li><a class="dropdown-item" href="admin_pagos.php"><i class="bi bi-cash-coin me-2"></i> Pagos y Reembolsos</a></li>
                    </ul>
                </li>

                <!-- Dropdown Usuarios -->
                <li class="nav-item">
                    <a class="nav-link" href="admin_usuarios.php">
                        <i class="bi bi-people me-1"></i> Usuarios
                    </a>
                </li>

                <!-- Dropdown Reportes -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-bar-chart me-1"></i> Reportes
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark shadow">
                        <li><a class="dropdown-item" href="admin_reportes.php"><i class="bi bi-graph-up me-2"></i> Métricas</a></li>
                        <li><a class="dropdown-item" href="exportar_excel.php"><i class="bi bi-file-earmark-excel me-2"></i> Exportar a Excel</a></li>
                        <li><a class="dropdown-item" href="exportar_pdf.php"><i class="bi bi-file-earmark-pdf me-2"></i> Exportar a PDF</a></li>
                    </ul>
                </li>
            </ul>

            <!-- Info de usuario y logout -->
            <div class="d-flex align-items-center gap-3 mt-3 mt-lg-0">
                <div class="dropdown">
                    <button class="btn btn-fb-outline dropdown-toggle d-flex align-items-center gap-2" type="button" data-bs-toggle="dropdown">
                        <div class="bg-secondary rounded-circle d-flex align-items-center justify-content-center" style="width: 28px; height: 28px; font-size: 12px; font-weight: bold;">
                            <?= strtoupper(substr($_SESSION['nombre'] ?? 'A', 0, 1)) ?>
                        </div>
                        <span class="d-none d-md-inline">Admin</span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-dark shadow">
                        <li><h6 class="dropdown-header"><?= e($_SESSION['email'] ?? '') ?></h6></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="index.php" target="_blank"><i class="bi bi-box-arrow-up-right me-2"></i> Ver Sitio Público</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i> Cerrar Sesión</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>

<div style="height: 76px;"></div>