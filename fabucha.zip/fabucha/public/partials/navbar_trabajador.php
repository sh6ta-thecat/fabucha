<?php
if (!function_exists('e')) {
    require_once __DIR__ . '/../../src/helpers.php';
}
?>
<nav class="navbar navbar-expand-lg fb-navbar fixed-top" style="border-bottom: 2px solid #3b82f6;">
    <div class="container-fluid px-4">
        <!-- Logo -->
        <a class="navbar-brand" href="panel_trabajador.php">
            <i class="bi bi-circle-fill" style="font-size: 0.8rem; color: #3b82f6;"></i> 
            Fabucha<span style="color: #3b82f6;">.</span>
            <small class="text-muted fs-6 ms-2 fw-normal">| Panel Trabajador</small>
        </a>

        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTrabajador">
            <i class="bi bi-list text-white fs-2"></i>
        </button>

        <div class="collapse navbar-collapse" id="navbarTrabajador">
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0 gap-3">
                <li class="nav-item">
                    <a class="nav-link text-white fw-bold" href="verificar.php">
                        <i class="bi bi-upc-scan me-1"></i> Verificar Código
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="panel_trabajador.php">
                        <i class="bi bi-calendar-day me-1"></i> Reservas de Hoy
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="reserva_presencial.php">
                        <i class="bi bi-plus-circle me-1"></i> Reserva Presencial
                    </a>
                </li>
            </ul>

            <!-- Info de usuario y logout -->
            <div class="d-flex align-items-center gap-3 mt-3 mt-lg-0">
                <div class="text-end d-none d-md-block">
                    <div class="text-white small fw-bold"><?= e($_SESSION['nombre'] ?? 'Trabajador') ?></div>
                    <div class="text-muted" style="font-size: 0.7rem; text-transform: uppercase;">
                        <?= e($_SESSION['tipo_trabajador'] ?? 'Recepcionista') ?>
                    </div>
                </div>
                <a href="logout.php" class="btn btn-outline-danger btn-sm">
                    <i class="bi bi-power"></i> Salir
                </a>
            </div>
        </div>
    </div>
</nav>

<div style="height: 76px;"></div>