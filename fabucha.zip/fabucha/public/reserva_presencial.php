<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/repositories/CanchaRepository.php';
require_once __DIR__ . '/../src/repositories/HorarioRepository.php';
require_once __DIR__ . '/../src/repositories/DeporteRepository.php';
require_once __DIR__ . '/../src/repositories/UsuarioRepository.php';
require_once __DIR__ . '/../src/services/ReservaService.php';
require_once __DIR__ . '/../src/services/PagoService.php';
require_once __DIR__ . '/../src/services/DisponibilidadService.php';

protegerPagina(['trabajador', 'admin']);
$canchaRepo = new CanchaRepository();
$horarioRepo = new HorarioRepository();
$deporteRepo = new DeporteRepository();
$usuarioRepo = new UsuarioRepository();
$reservaService = new ReservaService();
$pagoService = new PagoService();
$dispService = new DisponibilidadService();

$canchas = $canchaRepo->obtenerTodasConDeportes();
$horarios = $horarioRepo->obtenerTodos();
$mensaje = '';

// PROCESAR RESERVA PRESENCIAL
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $emailCliente = trim($_POST['email_cliente'] ?? '');
    $nombreCliente = trim($_POST['nombre_cliente'] ?? '');
    $canchaId = (int)$_POST['cancha_id'];
    $deporteId = (int)$_POST['deporte_id'];
    $fecha = $_POST['fecha'];
    $horarioId = (int)$_POST['horario_id'];
    $cantidadPersonas = (int)$_POST['cantidad_personas'];
    $metodoPago = $_POST['metodo_pago'];

    // 1. Buscar o crear cliente rápido
    $usuario = $usuarioRepo->buscarPorEmail($emailCliente);
    if (!$usuario) {
        // Crear un cliente con contraseña temporal (no podrá loguearse hasta cambiarla, pero la reserva queda registrada)
        $tempPass = password_hash(bin2hex(random_bytes(8)), PASSWORD_BCRYPT);
        $userId = $usuarioRepo->crear([
            'nombre' => $nombreCliente,
            'email' => $emailCliente,
            'password' => $tempPass,
            'telefono' => null,
            'rol' => 'cliente'
        ]);
        $usuarioId = $userId;
    } else {
        $usuarioId = $usuario['id'];
    }

    // 2. Crear el hold (con confirmación inmediata)
    $hold = $reservaService->crearHold($usuarioId, $canchaId, $deporteId, $fecha, $horarioId, $cantidadPersonas, 'Presencial');
    
    if ($hold['exito']) {
        // 3. Registrar pago en efectivo por el 100%
        $pagoService->registrarPago($hold['reserva_id'], 'reserva', $metodoPago, $hold['monto_total'], $_SESSION['usuario_id'], $usuarioId);
        
        // 4. El estado de la reserva se actualiza a pagada_total automáticamente en registrarPago
        $_SESSION['mensaje_exito'] = "Reserva presencial creada. Código: {$hold['codigo']}";
        header('Location: panel_trabajador.php');
        exit;
    } else {
        $mensaje = $hold['mensaje'];
    }
}

$titulo = 'Reserva Presencial - Fabucha';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar_trabajador.php';
?>

<main class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h2 class="fw-bold text-white mb-4"><i class="bi bi-plus-circle me-2"></i> Nueva Reserva Presencial</h2>
            <p class="text-muted mb-4">Crea una reserva para un cliente que llegó al local sin reservar por la web. El pago se registra en el momento.</p>

            <?php if ($mensaje): ?>
                <div class="alert alert-danger bg-danger bg-opacity-25 text-danger border-0"><?= e($mensaje) ?></div>
            <?php endif; ?>

            <div class="card bg-dark border-secondary text-white">
                <div class="card-body p-4">
                    <form method="POST">
                        <h6 class="text-muted mb-3">Datos del Cliente</h6>
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label class="form-label">Correo del cliente</label>
                                <input type="email" name="email_cliente" class="form-control bg-dark text-white border-secondary" required placeholder="cliente@correo.com">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Nombre del cliente</label>
                                <input type="text" name="nombre_cliente" class="form-control bg-dark text-white border-secondary" required placeholder="Ej. Juan Pérez">
                            </div>
                        </div>

                        <h6 class="text-muted mb-3">Detalles de la Reserva</h6>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Cancha</label>
                                <select name="cancha_id" class="form-select bg-dark text-white border-secondary" required>
                                    <?php foreach ($canchas as $c): ?>
                                        <option value="<?= $c['id'] ?>"><?= e($c['nombre']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Deporte</label>
                                <select name="deporte_id" class="form-select bg-dark text-white border-secondary" required>
                                    <?php foreach ($deporteRepo->obtenerTodos() as $d): ?>
                                        <option value="<?= $d['id'] ?>"><?= e($d['nombre']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Fecha</label>
                                <input type="date" name="fecha" class="form-control bg-dark text-white border-secondary" value="<?= date('Y-m-d') ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Horario</label>
                                <select name="horario_id" class="form-select bg-dark text-white border-secondary" required>
                                    <?php foreach ($horarios as $h): ?>
                                        <option value="<?= $h['id'] ?>"><?= substr($h['hora_inicio'], 0, 5) ?> - <?= substr($h['hora_fin'], 0, 5) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label class="form-label">Cantidad de personas</label>
                                <input type="number" name="cantidad_personas" class="form-control bg-dark text-white border-secondary" min="1" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Método de pago</label>
                                <select name="metodo_pago" class="form-select bg-dark text-white border-secondary" required>
                                    <option value="efectivo">Efectivo</option>
                                    <option value="yape">Yape</option>
                                    <option value="plin">Plin</option>
                                    <option value="transferencia">Transferencia</option>
                                </select>
                            </div>
                        </div>

                        <div class="alert alert-info bg-info bg-opacity-10 text-info border-0 small mb-4">
                            <i class="bi bi-info-circle me-1"></i>
                            El sistema cobrará el 100% de la reserva (cancha + depósito) y la marcará como pagada. Asegúrate de haber recibido el dinero antes de confirmar.
                        </div>

                        <button type="submit" class="btn btn-primary w-100 py-3" style="background-color: #3b82f6; border: none;">
                            <i class="bi bi-check-circle me-2"></i> Crear Reserva y Registrar Pago
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<?php require_once __DIR__ . '/partials/footer.php'; ?>