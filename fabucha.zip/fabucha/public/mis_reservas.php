<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/repositories/ReservaRepository.php';

protegerPagina(['cliente', 'admin']);
$reservaRepo = new ReservaRepository();
$reservas = $reservaRepo->obtenerReservasUsuario($_SESSION['usuario_id']);

// Separar activas y pasadas
$activas = [];
$pasadas = [];
foreach ($reservas as $r) {
    if (in_array($r['estado'], ['hold', 'pendiente_pago', 'pagada_parcial', 'pagada_total', 'en_uso'])) {
        $activas[] = $r;
    } else {
        $pasadas[] = $r;
    }
}

$titulo = 'Mis Reservas - Fabucha';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar_cliente.php';
?>

<main class="container py-4">
    <h2 class="fw-bold text-white mb-4"><i class="bi bi-clock-history me-2"></i> Mis Reservas</h2>

    <?php if (isset($_SESSION['mensaje_exito'])): ?>
        <div class="alert alert-success bg-success bg-opacity-25 text-success border-0 small"><?= e($_SESSION['mensaje_exito']) ?></div>
        <?php unset($_SESSION['mensaje_exito']); ?>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger bg-danger bg-opacity-25 text-danger border-0 small"><?= e($_SESSION['error']) ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <!-- Reservas Activas -->
    <h5 class="text-white-50 mb-3">Reservas Activas</h5>
    <?php if (empty($activas)): ?>
        <p class="text small mb-5">No tienes reservas activas. <a href="reservar.php" class="text-success">¡Reserva ahora!</a></p>
    <?php else: ?>
        <div class="row g-4 mb-5">
            <?php foreach ($activas as $r): ?>
                <div class="col-md-6">
                    <div class="card bg-dark border-secondary text-white h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between mb-3">
                                <span class="badge bg-secondary" style="font-family: monospace; font-size: 1rem;"><?= e($r['codigo']) ?></span>
                                <?php
                                $badge = 'secondary';
                                if ($r['estado'] === 'pagada_total') $badge = 'success';
                                if ($r['estado'] === 'pagada_parcial') $badge = 'warning';
                                if ($r['estado'] === 'pendiente_pago') $badge = 'info';
                                if ($r['estado'] === 'en_uso') $badge = 'primary';
                                ?>
                                <span class="badge bg-<?= $badge ?>"><?= strtoupper($r['estado']) ?></span>
                            </div>
                            <h5 class="fw-bold"><?= e($r['cancha_nombre']) ?></h5>
                            <p class="small text mb-2"><i class="bi bi-trophy me-1"></i> <?= e($r['deporte_nombre']) ?></p>
                            <p class="small text mb-2"><i class="bi bi-calendar me-1"></i> <?= fechaLegible($r['fecha']) ?></p>
                            <p class="small text mb-3"><i class="bi bi-clock me-1"></i> <?= substr($r['hora_inicio'], 0, 5) ?> - <?= substr($r['hora_fin'], 0, 5) ?></p>
                            
                            <div class="d-flex justify-content-between align-items-center border-top border-secondary pt-3">
                                <div>
                                    <span class="fw-bold">S/ <?= number_format($r['monto_total'], 2) ?></span>
                                    <small class="text d-block">Pagado: S/ <?= number_format($r['monto_pagado'], 2) ?></small>
                                </div>
                                <div>
                                    <?php if ($r['estado'] === 'pendiente_pago'): ?>
                                        <a href="cancelar_reserva.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('¿Cancelar esta reserva?')">Cancelar</a>
                                    <?php elseif ($r['estado'] === 'pagada_parcial' || $r['estado'] === 'pagada_total'): ?>
                                        <a href="cancelar_reserva.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-warning">Cancelar</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- Historial -->
    <h5 class="text-white-50 mb-3">Historial</h5>
    <?php if (empty($pasadas)): ?>
        <p class="text small">No tienes reservas en tu historial.</p>
    <?php else: ?>
        <div class="card bg-dark border-secondary text-white">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Cancha</th>
                            <th>Fecha</th>
                            <th>Monto</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pasadas as $r): ?>
                            <tr>
                                <td style="font-family: monospace;"><?= e($r['codigo']) ?></td>
                                <td><?= e($r['cancha_nombre']) ?></td>
                                <td><?= date('d/m/Y', strtotime($r['fecha'])) ?></td>
                                <td>S/ <?= number_format($r['monto_total'], 2) ?></td>
                                <td><span class="badge bg-secondary"><?= strtoupper($r['estado']) ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</main>

<?php require_once __DIR__ . '/partials/footer.php'; ?>