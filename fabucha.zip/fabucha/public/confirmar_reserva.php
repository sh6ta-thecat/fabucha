<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/services/ReservaService.php';
require_once __DIR__ . '/../src/repositories/CanchaRepository.php';
require_once __DIR__ . '/../src/repositories/DeporteRepository.php';
require_once __DIR__ . '/../src/services/DisponibilidadService.php';

if (!estaLogueado()) {
    $_SESSION['error_login'] = 'Debes iniciar sesión para reservar.';
    header('Location: login.php');
    exit;
}

$canchaRepo = new CanchaRepository();
$deporteRepo = new DeporteRepository();
$dispService = new DisponibilidadService();
$reservaService = new ReservaService();

$canchaId = isset($_GET['cancha']) ? (int)$_GET['cancha'] : 0;
// Si la fecha viene por POST (al cambiar en el selector), la usamos. Si no, por GET, si no, hoy.
$fecha = $_POST['fecha'] ?? $_GET['fecha'] ?? date('Y-m-d'); 

$cancha = $canchaRepo->buscarPorId($canchaId);
if (!$cancha) {
    header('Location: reservar.php');
    exit;
}

// Cargar horarios disponibles para esa fecha y cancha
$horariosDisponibles = $dispService->obtenerHorariosLibres($canchaId, $fecha);
$deportesCancha = $canchaRepo->obtenerDeportesDeCancha($canchaId);

$holdCreado = null;
$mensajeError = '';

// PROCESAR RESERVA (solo si el botón "Reservar" fue presionado)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirmar_reserva_final'])) {
    $cantidadPersonas = (int)$_POST['cantidad_personas'];
    $nombreEquipo = trim($_POST['nombre_equipo'] ?? '');
    $deporteId = (int)$_POST['deporte_id'];
    $horarioId = (int)$_POST['horario_id'];

    if ($cantidadPersonas > $cancha['aforo_maximo']) {
        $mensajeError = "La cancha admite máximo {$cancha['aforo_maximo']} personas.";
    } else {
        $resultado = $reservaService->crearHold(
            $_SESSION['usuario_id'], $canchaId, $deporteId, $fecha, $horarioId, $cantidadPersonas, $nombreEquipo ?: null
        );
        if ($resultado['exito']) {
            $holdCreado = $resultado;
        } else {
            $mensajeError = $resultado['mensaje'];
        }
    }
}

$titulo = 'Confirmar Reserva - Fabucha';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar_cliente.php';
?>

<main class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php if ($holdCreado): ?>
                <!-- Pantalla de Hold Creado -->
                <div class="card bg-dark border-success text-white">
                    <div class="card-header border-success bg-success bg-opacity-25">
                        <h5 class="mb-0 text-success"><i class="bi bi-check-circle me-2"></i> Reserva Temporal Creada</h5>
                    </div>
                    <div class="card-body text-center py-5">
                        <p class="text-muted mb-2">Tu código de reserva es:</p>
                        <h1 class="fw-bold mb-4" style="font-family: monospace; letter-spacing: 3px; color: var(--fb-green);">
                            <?= e($holdCreado['codigo']) ?>
                        </h1>
                        <p class="small text-muted">Tienes <strong><?= HOLD_MINUTOS ?> minutos</strong> para completar el pago.</p>
                        <p class="small text-muted">Expira a las <strong><?= date('H:i', strtotime($holdCreado['expira_en'])) ?></strong></p>
                        <div class="alert alert-warning bg-warning bg-opacity-10 text-warning border-0 small mt-4">
                            <i class="bi bi-info-circle me-1"></i> El pago se registra manualmente por el administrador.
                        </div>
                        <a href="mis_reservas.php" class="btn btn-fb-primary mt-3">Ver mis reservas</a>
                    </div>
                </div>
            <?php else: ?>
                <!-- Formulario de Reserva -->
                <div class="card bg-dark border-secondary text-white">
                    <div class="card-header border-secondary">
                        <h5 class="mb-0">Confirmar Reserva</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($mensajeError): ?>
                            <div class="alert alert-danger bg-danger bg-opacity-25 text-danger border-0 small"><?= e($mensajeError) ?></div>
                        <?php endif; ?>

                        <form method="POST" id="formReserva">
                            <!-- Este hidden nos dice si estamos cambiando la fecha o confirmando la reserva -->
                            <input type="hidden" name="cancha" value="<?= $canchaId ?>">
                            <input type="hidden" name="confirmar_reserva_final" id="inputConfirmarFinal" value="0">

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Cancha</label>
                                    <input type="text" class="form-control bg-dark text-white border-secondary" value="<?= e($cancha['nombre']) ?>" readonly>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Fecha</label>
                                    <!-- El selector de fecha visible y estándar -->
                                    <input type="date" name="fecha" id="inputFecha" class="form-control bg-dark text-white border-secondary" 
                                           min="<?= date('Y-m-d') ?>" value="<?= e($fecha) ?>" required 
                                           onchange="cambiarFecha()">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Deporte</label>
                                <select name="deporte_id" class="form-select bg-dark text-white border-secondary" required>
                                    <?php foreach ($deportesCancha as $d): ?>
                                        <option value="<?= $d['id'] ?>"><?= e($d['nombre']) ?> (S/ <?= number_format($d['precio_hora'], 2) ?>/hora)</option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Horario disponible</label>
                                <select name="horario_id" class="form-select bg-dark text-white border-secondary" required <?= empty($horariosDisponibles) ? 'disabled' : '' ?>>
                                    <option value="">Selecciona un horario</option>
                                    <?php foreach ($horariosDisponibles as $h): ?>
                                        <option value="<?= $h['id'] ?>"><?= substr($h['hora_inicio'], 0, 5) ?> - <?= substr($h['hora_fin'], 0, 5) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if (empty($horariosDisponibles)): ?>
                                    <small class="text-warning">No hay horarios disponibles para esta fecha. Prueba otro día.</small>
                                <?php endif; ?>
                            </div>

                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <label class="form-label">Cantidad de personas</label>
                                    <input type="number" name="cantidad_personas" class="form-control bg-dark text-white border-secondary" min="1" max="<?= $cancha['aforo_maximo'] ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Nombre del equipo (opcional)</label>
                                    <input type="text" name="nombre_equipo" class="form-control bg-dark text-white border-secondary" placeholder="Ej. Los Tigres">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-fb-primary w-100 py-3 fw-bold" 
                                    <?= empty($horariosDisponibles) ? 'disabled' : '' ?> 
                                    onclick="document.getElementById('inputConfirmarFinal').value='1';">
                                <i class="bi bi-calendar-check me-2"></i> Reservar y generar código
                            </button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<script>
// Cuando cambia la fecha, recargamos la página para consultar los nuevos horarios disponibles
function cambiarFecha() {
    const fecha = document.getElementById('inputFecha').value;
    const cancha = <?= $canchaId ?>;
    window.location.href = 'confirmar_reserva.php?cancha=' + cancha + '&fecha=' + fecha;
}
</script>

<?php require_once __DIR__ . '/partials/footer.php'; ?>