<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/helpers.php';
$titulo = 'Recuperar Contraseña - Fabucha';
require_once __DIR__ . '/partials/header.php';
?>

<div class="container d-flex justify-content-center align-items-center min-vh-100 py-5">
    <div class="card border-0 shadow-lg" style="max-width: 440px; width: 100%; background-color: var(--fb-card); border: 1px solid var(--fb-border) !important; border-radius: 16px;">
        <div class="card-body p-4 p-md-5">
            
            <div class="text-center mb-5">
                <a href="index.php" class="text-decoration-none">
                    <h2 class="fw-bold mb-1" style="color: var(--fb-text); letter-spacing: -0.5px;">
                        <i class="bi bi-circle-fill" style="font-size: 0.8rem; color: var(--fb-green);"></i> 
                        Fabucha<span style="color: var(--fb-green);">.</span>
                    </h2>
                </a>
                <div class="mt-4 mb-2">
                    <i class="bi bi-shield-lock text-warning" style="font-size: 2.5rem;"></i>
                </div>
                <h4 class="text-white fw-bold mb-1">Recuperar contraseña</h4>
                <p class="small" style="color: var(--fb-text-muted);">Ingresa tu correo y te enviaremos un enlace para restablecerla.</p>
            </div>

            <?php if (isset($_SESSION['mensaje_exito'])): ?>
                <div class="alert alert-success py-2 small border-0" style="background-color: rgba(34, 197, 94, 0.1); color: #86efac;">
                    <i class="bi bi-check-circle me-1"></i> <?= htmlspecialchars($_SESSION['mensaje_exito']) ?>
                </div>
                <?php unset($_SESSION['mensaje_exito']); ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['error_recuperacion'])): ?>
                <div class="alert alert-danger py-2 small border-0" style="background-color: rgba(220, 38, 38, 0.1); color: #fca5a5;">
                    <i class="bi bi-exclamation-triangle me-1"></i> <?= htmlspecialchars($_SESSION['error_recuperacion']) ?>
                </div>
                <?php unset($_SESSION['error_recuperacion']); ?>
            <?php endif; ?>

            <form id="formRecuperar" action="../src/procesar_recuperacion.php" method="POST" novalidate>
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">

                <div class="mb-4">
                    <label for="email" class="form-label small fw-bold" style="color: var(--fb-text-muted);">Correo electrónico</label>
                    <input type="email" class="form-control form-control-lg bg-dark text-white border-secondary" id="email" name="email"
                           placeholder="tu@correo.com" required autocomplete="email" style="font-size: 0.95rem;">
                    <div class="invalid-feedback">Ingresa un correo válido.</div>
                </div>

                <button type="submit" class="btn btn-fb-primary w-100 py-3 fw-bold fs-6">
                    <i class="bi bi-envelope me-2"></i> Enviar enlace
                </button>
            </form>

            <div class="text-center mt-4 pt-3 border-top border-secondary border-opacity-25">
                <p class="small mb-0" style="color: var(--fb-text-muted);">
                    <a href="login.php" class="text-decoration-none fw-bold" style="color: var(--fb-green);">
                        <i class="bi bi-arrow-left me-1"></i> Volver al inicio de sesión
                    </a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/partials/footer.php'; ?>