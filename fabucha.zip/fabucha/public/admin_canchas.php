<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/repositories/CanchaRepository.php';

protegerPagina(['admin']);
$canchaRepo = new CanchaRepository();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $canchaRepo->crear([
        'nombre' => $_POST['nombre'],
        'capacidad_tribuna' => (int)$_POST['capacidad_tribuna'],
        'capacidad_jugadores' => (int)$_POST['capacidad_jugadores'],
        'aforo_maximo' => (int)$_POST['aforo_maximo']
    ]);
    $_SESSION['mensaje_exito'] = 'Cancha creada correctamente.';
    header('Location: admin_canchas.php');
    exit;
}

$canchas = $canchaRepo->obtenerTodasConDeportes();
$titulo = 'Gestión de Canchas - Admin';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar_admin.php';
?>

<main class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold text-white">Canchas</h2>
        <button class="btn btn-fb-primary" data-bs-toggle="modal" data-bs-target="#modalNuevaCancha">
            <i class="bi bi-plus-lg"></i> Nueva Cancha
        </button>
    </div>

    <?php if (isset($_SESSION['mensaje_exito'])): ?>
        <div class="alert alert-success bg-success bg-opacity-25 text-success border-0 small"><?= e($_SESSION['mensaje_exito']) ?></div>
        <?php unset($_SESSION['mensaje_exito']); ?>
    <?php endif; ?>

    <div class="card bg-dark border-secondary text-white">
        <div class="table-responsive">
            <table class="table table-dark table-hover mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Tribuna</th>
                        <th>Aforo</th>
                        <th>Deportes</th>
                        <th>Precio Mín.</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($canchas as $c): ?>
                        <tr>
                            <td><?= $c['id'] ?></td>
                            <td><?= e($c['nombre']) ?></td>
                            <td><?= $c['capacidad_tribuna'] ?></td>
                            <td><?= $c['aforo_maximo'] ?></td>
                            <td><?= e($c['deportes'] ?? 'N/A') ?></td>
                            <td>S/ <?= number_format($c['precio_minimo'] ?? 0, 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<!-- Modal Nueva Cancha -->
<div class="modal fade" id="modalNuevaCancha" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content bg-dark text-white border-secondary">
            <form method="POST">
                <div class="modal-header border-secondary">
                    <h5 class="modal-title">Nueva Cancha</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Nombre</label>
                        <input type="text" name="nombre" class="form-control bg-dark text-white border-secondary" required>
                    </div>
                    <div class="row">
                        <div class="col-4 mb-3">
                            <label class="form-label">Tribuna</label>
                            <input type="number" name="capacidad_tribuna" class="form-control bg-dark text-white border-secondary" value="40" required>
                        </div>
                        <div class="col-4 mb-3">
                            <label class="form-label">Jugadores</label>
                            <input type="number" name="capacidad_jugadores" class="form-control bg-dark text-white border-secondary" value="10" required>
                        </div>
                        <div class="col-4 mb-3">
                            <label class="form-label">Aforo Máx</label>
                            <input type="number" name="aforo_maximo" class="form-control bg-dark text-white border-secondary" value="50" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-fb-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/partials/footer.php'; ?>