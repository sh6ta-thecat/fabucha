<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/conexion.php';
require_once __DIR__ . '/../src/helpers.php';

$titulo = 'Reservar Cancha - Fabucha';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar_cliente.php';

$pdo = Conexion::obtener();

// Filtros desde la URL
$filtroCancha = isset($_GET['cancha']) ? (int)$_GET['cancha'] : 0;
$filtroDeporte = isset($_GET['deporte']) ? (int)$_GET['deporte'] : 0;
$fechaSeleccionada = $_GET['fecha'] ?? date('Y-m-d');

// Obtener canchas
$sql = "SELECT c.id, c.nombre, c.aforo_maximo, c.capacidad_tribuna, MIN(cd.precio_hora) as precio_min, GROUP_CONCAT(DISTINCT d.nombre SEPARATOR ' / ') AS deportes
        FROM canchas c
        LEFT JOIN cancha_deporte cd ON cd.cancha_id = c.id
        LEFT JOIN deportes d ON d.id = cd.deporte_id AND d.activo = 1
        WHERE c.activa = 1";
$params = [];
if ($filtroDeporte > 0) {
    $sql .= " AND cd.deporte_id = ?";
    $params[] = $filtroDeporte;
}
if ($filtroCancha > 0) {
    $sql .= " AND c.id = ?";
    $params[] = $filtroCancha;
}
$sql .= " GROUP BY c.id ORDER BY c.nombre";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$canchas = $stmt->fetchAll();
?>

<section class="fb-section pt-5 mt-5">
    <div class="container">
        <!-- Selector de Fecha y Filtros -->
        <form action="reservar.php" method="GET" class="fb-search-bar mb-5">
            <div class="fb-search-item">
                <label>Fecha</label>
                <input type="date" name="fecha" min="<?= date('Y-m-d') ?>" value="<?= e($fechaSeleccionada) ?>" required>
            </div>
            <div class="fb-search-item">
                <label>Deporte</label>
                <select name="deporte">
                    <option value="0">Todos</option>
                    <option value="1" <?= $filtroDeporte == 1 ? 'selected' : '' ?>>Fútbol 5</option>
                    <option value="2" <?= $filtroDeporte == 2 ? 'selected' : '' ?>>Fútbol 7</option>
                    <option value="3" <?= $filtroDeporte == 3 ? 'selected' : '' ?>>Vóley</option>
                    <option value="4" <?= $filtroDeporte == 4 ? 'selected' : '' ?>>Básquet</option>
                </select>
            </div>
            <div class="fb-search-item">
                <label>Cancha</label>
                <select name="cancha">
                    <option value="0">Todas</option>
                    <?php foreach ($canchas as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= $filtroCancha == $c['id'] ? 'selected' : '' ?>><?= e($c['nombre']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-fb-primary px-4 py-3">
                <i class="bi bi-search"></i> Buscar
            </button>
        </form>

        <h2 class="fb-section-title">Seleccioná tu cancha</h2>
        <p class="fb-section-subtitle">Elegí una cancha para ver los horarios disponibles del <strong><?= fechaLegible($fechaSeleccionada) ?></strong>.</p>

        <div class="row g-4">
            <?php if (empty($canchas)): ?>
                <div class="col-12 text-white-50"><i class="bi bi-info-circle"></i> No se encontraron canchas.</div>
            <?php else: ?>
                <?php foreach ($canchas as $c): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="fb-court-card">
                            <div class="fb-court-img" style="background-image: url('https://images.unsplash.com/photo-1575361204480-aadea25e6e68?q=80&w=800&auto=format&fit=crop');">
                                <span class="fb-court-badge"><?= e($c['deportes'] ?? 'Sin deporte') ?></span>
                            </div>
                            <div class="fb-court-body">
                                <h4 class="fb-court-title"><?= e($c['nombre']) ?></h4>
                                <p class="fb-court-loc"><i class="bi bi-people me-1"></i> Aforo: <?= $c['aforo_maximo'] ?></p>
                                <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top border-secondary border-opacity-25">
                                    <div class="fb-court-price"><?= soles((float)($c['precio_min'] ?? 0)) ?><span>/hora</span></div>
                                    <!-- IMPORTANTE: Aquí enviamos la fecha seleccionada -->
                                    <a href="confirmar_reserva.php?cancha=<?= $c['id'] ?>&fecha=<?= urlencode($fechaSeleccionada) ?>" class="btn btn-fb-primary btn-sm">Ver horarios</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/partials/footer.php'; ?>