<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/services/ReporteService.php';

protegerPagina(['admin']);
$reporteService = new ReporteService();
$metricas = $reporteService->obtenerMetricasDashboard();
$grafico = $reporteService->obtenerIngresosUltimosMeses(6);

$titulo = 'Dashboard Admin - Fabucha';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar_admin.php';
?>

<main class="container py-4">
    <h2 class="fw-bold text-white mb-4">Dashboard</h2>
    
    <div class="row g-4 mb-5">
        <div class="col-md-3">
            <div class="card bg-dark border-secondary text-white h-100">
                <div class="card-body">
                    <h6 class="text-muted">Reservas Hoy</h6>
                    <h2 class="fw-bold mb-0"><?= $metricas['reservas_hoy'] ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-dark border-secondary text-white h-100">
                <div class="card-body">
                    <h6 class="text-muted">Ingresos del Mes</h6>
                    <h2 class="fw-bold mb-0">S/ <?= number_format($metricas['ingresos_mes'], 2) ?></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-dark border-secondary text-white h-100">
                <div class="card-body">
                    <h6 class="text-muted">Cancha Top</h6>
                    <h2 class="fw-bold mb-0 fs-4"><?= e($metricas['cancha_top']) ?></h2>
                    <small class="text-success"><?= $metricas['cancha_top_count'] ?> reservas</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-dark border-secondary text-white h-100">
                <div class="card-body">
                    <h6 class="text-muted">Horario Top</h6>
                    <h2 class="fw-bold mb-0 fs-4"><?= $metricas['horario_top'] ?></h2>
                    <small class="text-success"><?= $metricas['horario_top_count'] ?> reservas</small>
                </div>
            </div>
        </div>
    </div>

    <div class="card bg-dark border-secondary text-white">
        <div class="card-body">
            <h5 class="mb-4">Ingresos de los últimos 6 meses</h5>
            <canvas id="graficoIngresos" height="80"></canvas>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('graficoIngresos').getContext('2d');
    const labels = <?= json_encode(array_column($grafico, 'mes')) ?>;
    const data = <?= json_encode(array_column($grafico, 'total')) ?>;
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Ingresos (S/)',
                data: data,
                borderColor: '#a855f7',
                backgroundColor: 'rgba(168, 85, 247, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: {
                y: { grid: { color: '#27272a' }, ticks: { color: '#a1a1aa' } },
                x: { grid: { display: false }, ticks: { color: '#a1a1aa' } }
            }
        }
    });
</script>
<?php require_once __DIR__ . '/partials/footer.php'; ?>