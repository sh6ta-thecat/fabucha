<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/repositories/PagoRepository.php';

protegerPagina(['admin']);
$pagoRepo = new PagoRepository();

$desde = $_GET['desde'] ?? date('Y-m-01');
$hasta = $_GET['hasta'] ?? date('Y-m-d');
$total = $pagoRepo->obtenerIngresosPorRango($desde, $hasta);

$titulo = 'Reportes - Admin';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar_admin.php';
?>
<main class="container py-4">
    <h2 class="fw-bold text-white mb-4">Reportes de Ingresos</h2>
    <div class="card bg-dark border-secondary text-white mb-4">
        <div class="card-body">
            <form method="GET" class="row g-2 align-items-end">
                <div class="col-md-4">
                    <label class="form-label">Desde</label>
                    <input type="date" name="desde" value="<?= $desde ?>" class="form-control bg-dark text-white border-secondary">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Hasta</label>
                    <input type="date" name="hasta" value="<?= $hasta ?>" class="form-control bg-dark text-white border-secondary">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-fb-primary w-100">Filtrar</button>
                </div>
                <div class="col-md-2">
                    <a href="exportar_pdf.php?desde=<?= $desde ?>&hasta=<?= $hasta ?>" class="btn btn-outline-danger w-100">PDF</a>
                </div>
            </form>
        </div>
    </div>

    <div class="card bg-dark border-secondary text-white">
        <div class="card-body text-center py-5">
            <h6 class="text-muted">Ingresos Totales del Rango Seleccionado</h6>
            <h1 class="fw-bold display-3 mt-2" style="color: #a855f7;">S/ <?= number_format($total, 2) ?></h1>
            <p class="text-muted small"><?= $desde ?> al <?= $hasta ?></p>
        </div>
    </div>
</main>
<?php require_once __DIR__ . '/partials/footer.php'; ?>