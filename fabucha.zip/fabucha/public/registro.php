<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/helpers.php';
$titulo = 'Crear Cuenta - Fabucha';
require_once __DIR__ . '/partials/header.php';
?>

<div class="container d-flex justify-content-center align-items-center min-vh-100 py-5">
    <div class="card border-0 shadow-lg" style="max-width: 520px; width: 100%; background-color: var(--fb-card); border: 1px solid var(--fb-border) !important; border-radius: 16px;">
        <div class="card-body p-4 p-md-5">
            
            <div class="text-center mb-5">
                <a href="index.php" class="text-decoration-none">
                    <h2 class="fw-bold mb-1" style="color: var(--fb-text); letter-spacing: -0.5px;">
                        <i class="bi bi-circle-fill" style="font-size: 0.8rem; color: var(--fb-green);"></i> 
                        Fabucha<span style="color: var(--fb-green);">.</span>
                    </h2>
                </a>
                <p class="small mt-2" style="color: var(--fb-text-muted);">Crea tu cuenta para empezar a reservar</p>
            </div>

            <?php if (isset($_SESSION['error_registro'])): ?>
                <div class="alert alert-danger py-2 small border-0" style="background-color: rgba(220, 38, 38, 0.1); color: #fca5a5;">
                    <i class="bi bi-exclamation-triangle me-1"></i> <?= htmlspecialchars($_SESSION['error_registro']) ?>
                </div>
                <?php unset($_SESSION['error_registro']); ?>
            <?php endif; ?>

            <form id="formRegistro" action="../src/procesar_registro.php" method="POST" novalidate>
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">

                <div class="mb-3">
                    <label for="nombre" class="form-label small fw-bold" style="color: var(--fb-text-muted);">Nombre completo</label>
                    <input type="text" class="form-control form-control-lg bg-dark text-white border-secondary" id="nombre" name="nombre"
                           placeholder="Ej. Juan Pérez" required minlength="3" maxlength="100" style="font-size: 0.95rem;">
                    <div class="invalid-feedback">Ingresa tu nombre completo.</div>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label small fw-bold" style="color: var(--fb-text-muted);">Correo electrónico</label>
                    <input type="email" class="form-control form-control-lg bg-dark text-white border-secondary" id="email" name="email"
                           placeholder="tu@correo.com" required autocomplete="email" style="font-size: 0.95rem;">
                    <div class="invalid-feedback">Ingresa un correo válido.</div>
                </div>

                <div class="mb-3">
                    <label for="telefono" class="form-label small fw-bold" style="color: var(--fb-text-muted);">Teléfono (opcional)</label>
                    <input type="tel" class="form-control form-control-lg bg-dark text-white border-secondary" id="telefono" name="telefono"
                           placeholder="Ej. 987654321" pattern="[0-9]{9}" maxlength="9" style="font-size: 0.95rem;">
                    <div class="invalid-feedback">Ingresa 9 dígitos.</div>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label small fw-bold" style="color: var(--fb-text-muted);">Contraseña</label>
                    <div class="input-group input-group-lg">
                        <input type="password" class="form-control bg-dark text-white border-secondary" id="password" name="password"
                               placeholder="Mínimo 8 caracteres" required minlength="8"
                               pattern="(?=.*[A-Z])(?=.*[0-9]).{8,}" autocomplete="new-password" style="font-size: 0.95rem; border-right: none;">
                        <button class="btn btn-outline-secondary border-secondary" type="button" id="togglePassword" style="border-left: none;">
                            <i class="bi bi-eye text-white-50"></i>
                        </button>
                    </div>
                    <div class="invalid-feedback">
                        Mínimo 8 caracteres, al menos una mayúscula y un número.
                    </div>
                    <div class="form-text small mt-1" style="color: var(--fb-text-muted);">
                        <i class="bi bi-info-circle"></i> Debe tener al menos 8 caracteres, una mayúscula y un número.
                    </div>
                </div>

                <div class="mb-4">
                    <label for="password_confirm" class="form-label small fw-bold" style="color: var(--fb-text-muted);">Confirmar contraseña</label>
                    <input type="password" class="form-control form-control-lg bg-dark text-white border-secondary" id="password_confirm" name="password_confirm"
                           placeholder="Repite tu contraseña" required autocomplete="new-password" style="font-size: 0.95rem;">
                    <div class="invalid-feedback">Las contraseñas no coinciden.</div>
                </div>

                <div class="form-check mb-4">
                    <input class="form-check-input bg-dark border-secondary" type="checkbox" id="terminos" name="terminos" required>
                    <label class="form-check-label small" for="terminos" style="color: var(--fb-text-muted);">
                        Acepto los <a href="#" data-bs-toggle="modal" data-bs-target="#modalTerminos" style="color: var(--fb-green);">términos y condiciones</a>
                    </label>
                    <div class="invalid-feedback">Debes aceptar los términos.</div>
                </div>

                <button type="submit" class="btn btn-fb-primary w-100 py-3 fw-bold fs-6">
                    Crear cuenta
                </button>
            </form>

            <div class="text-center mt-4 pt-3 border-top border-secondary border-opacity-25">
                <p class="small mb-0" style="color: var(--fb-text-muted);">
                    ¿Ya tienes cuenta?
                    <a href="login.php" class="text-decoration-none fw-bold" style="color: var(--fb-green);">Inicia sesión</a>
                </p>
            </div>
        </div>
    </div>
</div>

<!-- Modal de términos -->
<div class="modal fade" id="modalTerminos" tabindex="-1">
    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered">
        <div class="modal-content bg-dark border-secondary" style="border-color: var(--fb-border) !important;">
            <div class="modal-header border-secondary">
                <h5 class="modal-title text-white">Términos y condiciones</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body small" style="color: var(--fb-text-muted);">
                <p>Al registrarte en el sistema de reservas del Local Fabucha aceptas:</p>
                <ul>
                    <li>Proporcionar información veraz y actualizada.</li>
                    <li>Respetar los horarios reservados y las normas del local.</li>
                    <li>Pagar el monto total de la reserva según las reglas establecidas.</li>
                    <li>Aceptar la política de cancelación y devolución vigente.</li>
                    <li>Cuidar las instalaciones y responder por daños ocasionados.</li>
                </ul>
                <p class="mb-0">El Local Fabucha se reserva el derecho de admisión y permanencia.</p>
            </div>
            <div class="modal-footer border-secondary">
                <button type="button" class="btn btn-fb-primary" data-bs-dismiss="modal">Entendido</button>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/partials/footer.php'; ?>