<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/repositories/ReservaRepository.php';
require_once __DIR__ . '/../src/services/ReservaService.php';
require_once __DIR__ . '/../src/repositories/HorarioRepository.php';

protegerPagina(['cliente', 'admin']);
$reservaRepo = new ReservaRepository();
$reservaService = new ReservaService();
$horarioRepo = new HorarioRepository();

$reservaId = (int)($_GET['id'] ?? 0);
$reserva = $reservaRepo->buscarPorId($reservaId);

if (!$reserva || $reserva['usuario_id'] != $_SESSION['usuario_id']) {
    $_SESSION['error'] = 'Reserva no encontrada o no te pertenece.';
    header('Location: mis_reservas.php');
    exit;
}

// Calcular horas de anticipación para mostrar el cálculo
$horaInicio = $horarioRepo->obtenerHoraInicio($reserva['horario_id']);
$fechaHoraInicio = strtotime($reserva['fecha'] . ' ' . $horaInicio);
$horasAnticipacion = ($fechaHoraInicio - time()) / 3600;

$pdo = Conexion::obtener();
$stmt = $pdo->query("SELECT * FROM politicas_cancelacion ORDER BY horas_anticipacion_min DESC");
$politica = null;
foreach ($stmt->fetchAll() as $p) {
    if ($horasAnticipacion >= $p['horas_anticipacion_min']) {
        $politica = $p;
        break;
    }
}
$porcentaje = $politica ? $politica['porcentaje_reembolso_cancha'] : 0;
$reembolsoCancha = ($reserva['monto_cancha'] * $porcentaje) / 100;
$reembolsoDeposito = ($politica && $politica['reembolso_deposito']) ? $reserva['monto_deposito'] : 0;
$reembolsoTotal = $reembolsoCancha + $reembolsoDeposito;
$multa = $reserva['monto_pagado'] - $reembolsoTotal;

// PROCESAR CANCELACIÓN
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirmar_cancelacion'])) {
    $resultado = $reservaService->cancelarReserva($reservaId, 'cliente');
    if ($resultado['exito']) {
        $_SESSION['mensaje_exito'] = "Reserva cancelada. Reembolso: S/ " . number_format($resultado['reembolso'], 2) . " (Multa: S/ " . number_format($resultado['multa'], 2) . ")";
        header('Location: mis_reservas.php');
    } else {
        $_SESSION['error'] = $resultado['mensaje'];
        header('Location: mis_reservas.php');
    }
    exit;
}

$titulo = 'Cancelar Reserva - Fabucha';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar_cliente.php';
?>

<main class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card bg-dark border-warning text-white">
                <div class="card-header border-warning bg-warning bg-opacity-10">
                    <h5 class="mb-0 text-warning"><i class="bi bi-exclamation-triangle me-2"></i> Cancelar Reserva</h5>
                </div>
                <div class="card-body">
                    <p class="text-muted small">Estás cancelando la reserva <strong><?= e($reserva['codigo']) ?></strong> de la cancha <strong><?= e($reserva['cancha_id']) ?></strong>.</p>
                    
                    <ul class="list-group list-group-flush mb-4">
                        <li class="list-group-item bg-transparent text-white border-secondary d-flex justify-content-between">
                            <span>Monto pagado:</span>
                            <span>S/ <?= number_format($reserva['monto_pagado'], 2) ?></span>
                        </li>
                        <li class="list-group-item bg-transparent text-white border-secondary d-flex justify-content-between">
                            <span>Reembolso de cancha (<?= $porcentaje ?>%):</span>
                            <span>S/ <?= number_format($reembolsoCancha, 2) ?></span>
                        </li>
                        <li class="list-group-item bg-transparent text-white border-secondary d-flex justify-content-between">
                            <span>Reembolso de depósito:</span>
                            <span>S/ <?= number_format($reembolsoDeposito, 2) ?></span>
                        </li>
                        <li class="list-group-item bg-transparent text-white border-secondary d-flex justify-content-between fw-bold">
                            <span>Multa aplicada:</span>
                            <span class="text-danger">- S/ <?= number_format($multa, 2) ?></span>
                        </li>
                        <li class="list-group-item bg-transparent text-white border-secondary d-flex justify-content-between fw-bold fs-5">
                            <span>Total a reembolsar:</span>
                            <span class="text-success">S/ <?= number_format($reembolsoTotal, 2) ?></span>
                        </li>
                    </ul>

                    <div class="alert alert-info bg-info bg-opacity-10 text-info border-0 small">
                        <i class="bi bi-info-circle me-1"></i>
                        El reembolso será procesado por el administrador en un plazo de 24 horas.
                    </div>

                    <form method="POST">
                        <input type="hidden" name="confirmar_cancelacion" value="1">
                        <div class="d-flex gap-2">
                            <a href="mis_reservas.php" class="btn btn-outline-secondary w-50">Mantener reserva</a>
                            <button type="submit" class="btn btn-warning w-50">Sí, cancelar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<?php require_once __DIR__ . '/partials/footer.php'; ?>