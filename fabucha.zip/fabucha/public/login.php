<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/services/AuthService.php';
require_once __DIR__ . '/../src/helpers.php';

// Si ya está logueado, redirigir al index
if (estaLogueado()) {
    header('Location: index.php');
    exit;
}

// ==========================================
// PROCESAMIENTO DEL FORMULARIO (POST)
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Validar Token CSRF
    if (!validarCsrf($_POST['csrf_token'] ?? '')) {
        $_SESSION['error_login'] = 'Token de seguridad inválido. Recarga la página.';
        header('Location: login.php');
        exit;
    }

    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $_SESSION['error_login'] = 'Por favor, completa todos los campos.';
        header('Location: login.php');
        exit;
    }

    // 2. Llamar al servicio
    $auth = new AuthService();
    $resultado = $auth->login($email, $password);

    // 3. Manejar resultado
    if ($resultado['exito']) {
        // Redirigir según el rol
        $rol = $_SESSION['rol'] ?? 'cliente';
        switch ($rol) {
            case 'admin':
                header('Location: panel_admin.php');
                break;
            case 'trabajador':
                header('Location: panel_trabajador.php');
                break;
            case 'limpieza':
                header('Location: panel_limpieza.php');
                break;
            default:
                header('Location: index.php');
                break;
        }
        exit;
    } else {
        $_SESSION['error_login'] = $resultado['mensaje'];
        header('Location: login.php');
        exit;
    }
}

// ==========================================
// RENDERIZADO DEL FORMULARIO (GET)
// ==========================================
$titulo = 'Iniciar Sesión - Fabucha';
require_once __DIR__ . '/partials/header.php';
?>

<!-- El HTML del login que ya te di anteriormente (con el diseño oscuro) -->
<div class="container d-flex justify-content-center align-items-center min-vh-100 py-5">
    <div class="card border-0 shadow-lg" style="max-width: 440px; width: 100%; background-color: var(--fb-card); border: 1px solid var(--fb-border) !important; border-radius: 16px;">
        <div class="card-body p-4 p-md-5">
            
            <div class="text-center mb-5">
                <a href="index.php" class="text-decoration-none">
                    <h2 class="fw-bold mb-1" style="color: var(--fb-text); letter-spacing: -0.5px;">
                        <i class="bi bi-circle-fill" style="font-size: 0.8rem; color: var(--fb-green);"></i> 
                        Fabucha<span style="color: var(--fb-green);">.</span>
                    </h2>
                </a>
                <p class="small mt-2" style="color: var(--fb-text-muted);">Ingresa para reservar tu cancha</p>
            </div>

            <?php if (isset($_SESSION['error_login'])): ?>
                <div class="alert alert-danger py-2 small border-0" style="background-color: rgba(220, 38, 38, 0.1); color: #fca5a5;">
                    <i class="bi bi-exclamation-triangle me-1"></i> <?= htmlspecialchars($_SESSION['error_login']) ?>
                </div>
                <?php unset($_SESSION['error_login']); ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['mensaje_exito'])): ?>
                <div class="alert alert-success py-2 small border-0" style="background-color: rgba(34, 197, 94, 0.1); color: #86efac;">
                    <i class="bi bi-check-circle me-1"></i> <?= htmlspecialchars($_SESSION['mensaje_exito']) ?>
                </div>
                <?php unset($_SESSION['mensaje_exito']); ?>
            <?php endif; ?>

            <!-- IMPORTANTE: action apunta al mismo login.php -->
            <form id="formLogin" action="login.php" method="POST" novalidate>
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">

                <div class="mb-3">
                    <label for="email" class="form-label small fw-bold" style="color: var(--fb-text-muted);">Correo electrónico</label>
                    <input type="email" class="form-control form-control-lg bg-dark text-white border-secondary" id="email" name="email"
                           placeholder="tu@correo.com" required autocomplete="email" style="font-size: 0.95rem;">
                    <div class="invalid-feedback">Ingresa un correo válido.</div>
                </div>

                <div class="mb-4">
                    <label for="password" class="form-label small fw-bold" style="color: var(--fb-text-muted);">Contraseña</label>
                    <div class="input-group input-group-lg">
                        <input type="password" class="form-control bg-dark text-white border-secondary" id="password" name="password"
                               placeholder="Tu contraseña" required autocomplete="current-password" style="font-size: 0.95rem; border-right: none;">
                        <button class="btn btn-outline-secondary border-secondary" type="button" id="togglePassword" style="border-left: none;">
                            <i class="bi bi-eye text-white-50"></i>
                        </button>
                    </div>
                    <div class="invalid-feedback">Ingresa tu contraseña.</div>
                </div>

                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div class="form-check">
                        <input class="form-check-input bg-dark border-secondary" type="checkbox" id="recordarme" name="recordarme">
                        <label class="form-check-label small" for="recordarme" style="color: var(--fb-text-muted);">Recordarme</label>
                    </div>
                    <a href="recuperar_password.php" class="small text-decoration-none" style="color: var(--fb-green);">¿Olvidaste tu contraseña?</a>
                </div>

                <button type="submit" class="btn btn-fb-primary w-100 py-3 fw-bold fs-6">
                    Ingresar
                </button>
            </form>

            <div class="text-center mt-4 pt-3 border-top border-secondary border-opacity-25">
                <p class="small mb-0" style="color: var(--fb-text-muted);">
                    ¿No tienes cuenta?
                    <a href="registro.php" class="text-decoration-none fw-bold" style="color: var(--fb-green);">Regístrate aquí</a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/partials/footer.php'; ?>