<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';

cerrarSesion();
header('Location: login.php');
exit;