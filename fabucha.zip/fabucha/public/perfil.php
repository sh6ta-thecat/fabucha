<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/repositories/UsuarioRepository.php';
require_once __DIR__ . '/../src/models/Usuario.php';

protegerPagina(['cliente', 'admin']);
$usuarioRepo = new UsuarioRepository();
$datos = $usuarioRepo->buscarPorId($_SESSION['usuario_id']);
$usuario = new Usuario($datos);

$titulo = 'Mi Perfil - Fabucha';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar_cliente.php';
?>

<main class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h2 class="fw-bold text-white mb-4"><i class="bi bi-person-circle me-2"></i> Mi Perfil</h2>

            <?php if ($usuario->tieneDeuda()): ?>
                <div class="alert alert-danger bg-danger bg-opacity-25 text-danger border-0 mb-4">
                    <h5 class="alert-heading"><i class="bi bi-exclamation-octagon me-2"></i> Tienes una deuda pendiente</h5>
                    <p class="mb-0">Monto: <strong>S/ <?= number_format($usuario->getDeudaPendiente(), 2) ?></strong>. Regulariza tu deuda para poder realizar nuevas reservas.</p>
                </div>
            <?php endif; ?>

            <div class="card bg-dark border-secondary text-white">
                <div class="card-body p-4">
                    <div class="row g-4">
                        <div class="col-md-6">
                            <p class="text small mb-1">Nombre completo</p>
                            <p class="fw-bold mb-0"><?= e($usuario->getNombre()) ?></p>
                        </div>
                        <div class="col-md-6">
                            <p class="text small mb-1">Correo electrónico</p>
                            <p class="fw-bold mb-0"><?= e($usuario->getEmail()) ?></p>
                        </div>
                        <div class="col-md-6">
                            <p class="text small mb-1">Teléfono</p>
                            <p class="fw-bold mb-0"><?= e($usuario->getTelefono() ?? 'No registrado') ?></p>
                        </div>
                        <div class="col-md-6">
                            <p class="text small mb-1">Rol</p>
                            <p class="fw-bold mb-0"><span class="badge bg-secondary"><?= strtoupper($usuario->getRol()) ?></span></p>
                        </div>
                        <div class="col-md-6">
                            <p class="text small mb-1">Deuda pendiente</p>
                            <p class="fw-bold mb-0 <?= $usuario->tieneDeuda() ? 'text-danger' : 'text-success' ?>">
                                S/ <?= number_format($usuario->getDeudaPendiente(), 2) ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <p class="text small mb-1">Miembro desde</p>
                            <p class="fw-bold mb-0"><?= date('d/m/Y', strtotime($usuario->getCreadoEn())) ?></p> <!-- Corregido -->
                        </div>
                    </div>
                </div>
            </div>

            <div class="mt-4 d-flex gap-2">
                <a href="mis_reservas.php" class="btn btn-fb-primary">Mis Reservas</a>
                <a href="logout.php" class="btn btn-outline-danger">Cerrar Sesión</a>
            </div>
        </div>
    </div>
</main>

<?php require_once __DIR__ . '/partials/footer.php'; ?>