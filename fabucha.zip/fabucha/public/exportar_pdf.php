<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/repositories/PagoRepository.php';
require_once __DIR__ . '/../vendor/autoload.php';

protegerPagina(['admin']);
$pagoRepo = new PagoRepository();
$desde = $_GET['desde'] ?? date('Y-m-01');
$hasta = $_GET['hasta'] ?? date('Y-m-d');
$total = $pagoRepo->obtenerIngresosPorRango($desde, $hasta);

$html = "
<h1>Reporte de Ingresos - Local Fabucha</h1>
<p><strong>Rango:</strong> {$desde} al {$hasta}</p>
<p><strong>Total:</strong> S/ " . number_format($total, 2) . "</p>
<p>Generado el " . date('d/m/Y H:i') . "</p>
";

$dompdf = new \Dompdf\Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4');
$dompdf->render();
$dompdf->stream("reporte_fabucha_{$desde}_{$hasta}.pdf", ['Attachment' => true]);
exit;