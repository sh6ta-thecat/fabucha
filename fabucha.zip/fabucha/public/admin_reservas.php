<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';

protegerPagina(['admin']);
$pdo = Conexion::obtener();

$filtroEstado = $_GET['estado'] ?? '';
$sql = "SELECT r.*, u.nombre as cliente, c.nombre as cancha, h.hora_inicio, h.hora_fin 
        FROM reservas r
        JOIN usuarios u ON r.usuario_id = u.id
        JOIN canchas c ON r.cancha_id = c.id
        JOIN horarios h ON r.horario_id = h.id";
$params = [];
if ($filtroEstado) {
    $sql .= " WHERE r.estado = ?";
    $params[] = $filtroEstado;
}
$sql .= " ORDER BY r.fecha DESC, h.hora_inicio DESC LIMIT 100";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$reservas = $stmt->fetchAll();

$titulo = 'Reservas - Admin';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar_admin.php';
?>
<main class="container py-4">
    <h2 class="fw-bold text-white mb-4">Todas las Reservas</h2>
    
    <form method="GET" class="row g-2 mb-4">
        <div class="col-auto">
            <select name="estado" class="form-select bg-dark text-white border-secondary">
                <option value="">Todos los estados</option>
                <option value="pendiente_pago" <?= $filtroEstado === 'pendiente_pago' ? 'selected' : '' ?>>Pendiente Pago</option>
                <option value="pagada_total" <?= $filtroEstado === 'pagada_total' ? 'selected' : '' ?>>Pagada Total</option>
                <option value="finalizada" <?= $filtroEstado === 'finalizada' ? 'selected' : '' ?>>Finalizada</option>
                <option value="cancelada_cliente" <?= $filtroEstado === 'cancelada_cliente' ? 'selected' : '' ?>>Cancelada</option>
            </select>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-light">Filtrar</button>
        </div>
    </form>

    <div class="card bg-dark border-secondary text-white">
        <div class="table-responsive">
            <table class="table table-dark table-hover mb-0">
                <thead><tr><th>Código</th><th>Fecha</th><th>Hora</th><th>Cancha</th><th>Cliente</th><th>Total</th><th>Estado</th></tr></thead>
                <tbody>
                    <?php foreach ($reservas as $r): ?>
                        <tr>
                            <td><?= e($r['codigo']) ?></td>
                            <td><?= $r['fecha'] ?></td>
                            <td><?= substr($r['hora_inicio'], 0, 5) ?> - <?= substr($r['hora_fin'], 0, 5) ?></td>
                            <td><?= e($r['cancha']) ?></td>
                            <td><?= e($r['cliente']) ?></td>
                            <td>S/ <?= number_format($r['monto_total'], 2) ?></td>
                            <td><span class="badge bg-secondary"><?= strtoupper($r['estado']) ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
<?php require_once __DIR__ . '/partials/footer.php'; ?>