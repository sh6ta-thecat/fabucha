<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/repositories/ReservaRepository.php';
require_once __DIR__ . '/../src/repositories/PagoRepository.php';
require_once __DIR__ . '/../src/repositories/FotoRepository.php';
require_once __DIR__ . '/../src/services/DisponibilidadService.php';

protegerPagina(['trabajador', 'admin']);
$reservaRepo = new ReservaRepository();
$pagoRepo = new PagoRepository();
$fotoRepo = new FotoRepository();
$dispService = new DisponibilidadService();

$reserva = null;
$pagos = [];
$fotos = [];
$mensaje = '';

// PROCESAR BÚSQUEDA
if (isset($_GET['codigo']) && !empty($_GET['codigo'])) {
    $codigo = strtoupper(trim($_GET['codigo']));
    $reserva = $reservaRepo->buscarPorCodigo($codigo);

    if ($reserva) {
        $pagos = $pagoRepo->obtenerPagosDeReserva($reserva['id']);
        $fotos = $fotoRepo->obtenerPorReserva($reserva['id']);
    }
}

// PROCESAR ACCIÓN (MARCAR EN USO)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion'])) {
    $reservaId = (int)$_POST['reserva_id'];
    $accion = $_POST['accion'];

    if ($accion === 'en_uso' && $reserva) {
        $pdo = Conexion::obtener();
        $pdo->prepare("UPDATE reservas SET estado = 'en_uso', hora_ingreso_real = NOW(), verificado_por = ? WHERE id = ?")
            ->execute([$_SESSION['usuario_id'], $reservaId]);
        $_SESSION['mensaje_exito'] = 'Reserva verificada. Cliente en cancha.';
        header('Location: verificar.php?codigo=' . urlencode($reserva['codigo']));
        exit;
    } elseif ($accion === 'finalizar' && $reserva) {
        // Calcular tope de sobretiempo antes de finalizar
        $tope = $dispService->calcularTopeSobretiempo(
            $reserva['cancha_id'], 
            $reserva['fecha'], 
            substr($reserva['hora_fin'], 0, 5) . ':00'
        );
        $pdo = Conexion::obtener();
        $pdo->prepare("UPDATE reservas SET estado = 'finalizada', hora_salida_real = NOW() WHERE id = ?")
            ->execute([$reservaId]);
        $_SESSION['mensaje_exito'] = "Reserva finalizada. Tope de sobretiempo: hasta las {$tope['tope']}.";
        header('Location: verificar.php?codigo=' . urlencode($reserva['codigo']));
        exit;
    } elseif ($accion === 'no_show' && $reserva) {
        $pdo = Conexion::obtener();
        $pdo->prepare("UPDATE reservas SET estado = 'no_show' WHERE id = ?")->execute([$reservaId]);
        $_SESSION['mensaje_exito'] = 'Reserva marcada como NO SHOW. Se retiene el depósito.';
        header('Location: verificar.php');
        exit;
    }
}

$titulo = 'Verificar Código - Fabucha';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar_trabajador.php';
?>

<main class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            
            <!-- Buscador -->
            <div class="card bg-dark border-secondary text-white mb-4">
                <div class="card-body p-4">
                    <h4 class="fw-bold mb-3"><i class="bi bi-upc-scan me-2"></i> Verificar Reserva</h4>
                    <p class="text-muted small mb-4">Ingresa el código de reserva que el cliente muestra al llegar.</p>
                    
                    <form method="GET" class="d-flex gap-2">
                        <input type="text" name="codigo" class="form-control form-control-lg bg-dark text-white border-secondary text-uppercase" 
                               placeholder="FAB-XXXXXX" value="<?= e($_GET['codigo'] ?? '') ?>" required style="font-family: monospace; letter-spacing: 2px;">
                        <button type="submit" class="btn btn-primary btn-lg" style="background-color: #3b82f6; border: none;">
                            Buscar
                        </button>
                    </form>
                </div>
            </div>

            <?php if (isset($_GET['codigo']) && !$reserva): ?>
                <div class="alert alert-danger bg-danger bg-opacity-25 text-danger border-0">
                    <i class="bi bi-exclamation-triangle me-2"></i> No se encontró ninguna reserva con ese código.
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['mensaje_exito'])): ?>
                <div class="alert alert-success bg-success bg-opacity-25 text-success border-0 small">
                    <i class="bi bi-check-circle me-1"></i> <?= e($_SESSION['mensaje_exito']) ?>
                </div>
                <?php unset($_SESSION['mensaje_exito']); ?>
            <?php endif; ?>

            <!-- Resultado de la reserva -->
            <?php if ($reserva): ?>
                <div class="card bg-dark border-secondary text-white mb-4">
                    <div class="card-header border-secondary d-flex justify-content-between align-items-center">
                        <span class="fw-bold fs-5" style="font-family: monospace;"><?= e($reserva['codigo']) ?></span>
                        <?php
                        $badge = 'secondary';
                        if ($reserva['estado'] === 'pagada_total') $badge = 'success';
                        if ($reserva['estado'] === 'pendiente_pago') $badge = 'warning';
                        if ($reserva['estado'] === 'en_uso') $badge = 'primary';
                        if ($reserva['estado'] === 'finalizada') $badge = 'info';
                        if ($reserva['estado'] === 'no_show') $badge = 'danger';
                        ?>
                        <span class="badge bg-<?= $badge ?> fs-6"><?= strtoupper($reserva['estado']) ?></span>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <p class="text-muted small mb-1">Cliente</p>
                                <p class="fw-bold mb-0"><?= e($reserva['cliente_nombre']) ?></p>
                            </div>
                            <div class="col-md-6">
                                <p class="text-muted small mb-1">Cancha</p>
                                <p class="fw-bold mb-0"><?= e($reserva['cancha_nombre']) ?></p>
                            </div>
                            <div class="col-md-6">
                                <p class="text-muted small mb-1">Fecha</p>
                                <p class="fw-bold mb-0"><?= fechaLegible($reserva['fecha']) ?></p>
                            </div>
                            <div class="col-md-6">
                                <p class="text-muted small mb-1">Horario</p>
                                <p class="fw-bold mb-0"><?= substr($reserva['hora_inicio'], 0, 5) ?> - <?= substr($reserva['hora_fin'], 0, 5) ?></p>
                            </div>
                            <div class="col-md-6">
                                <p class="text-muted small mb-1">Monto Total</p>
                                <p class="fw-bold mb-0">S/ <?= number_format($reserva['monto_total'], 2) ?></p>
                            </div>
                            <div class="col-md-6">
                                <p class="text-muted small mb-1">Pagado</p>
                                <p class="fw-bold mb-0 <?= $reserva['monto_pagado'] >= $reserva['monto_total'] ? 'text-success' : 'text-warning' ?>">
                                    S/ <?= number_format($reserva['monto_pagado'], 2) ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Acciones -->
                <div class="card bg-dark border-secondary text-white">
                    <div class="card-body">
                        <h6 class="fw-bold mb-3">Acciones</h6>
                        <div class="d-flex gap-2 flex-wrap">
                            <?php if ($reserva['estado'] === 'pagada_total' || $reserva['estado'] === 'pagada_parcial'): ?>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="reserva_id" value="<?= $reserva['id'] ?>">
                                    <input type="hidden" name="accion" value="en_uso">
                                    <button class="btn btn-primary" style="background-color: #3b82f6; border: none;">
                                        <i class="bi bi-play-circle me-1"></i> Marcar En Uso
                                    </button>
                                </form>
                            <?php endif; ?>

                            <?php if ($reserva['estado'] === 'en_uso'): ?>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="reserva_id" value="<?= $reserva['id'] ?>">
                                    <input type="hidden" name="accion" value="finalizar">
                                    <button class="btn btn-info text-white">
                                        <i class="bi bi-stop-circle me-1"></i> Finalizar Reserva
                                    </button>
                                </form>
                            <?php endif; ?>

                            <?php if (in_array($reserva['estado'], ['pagada_total', 'pendiente_pago'])): ?>
                                <form method="POST" class="d-inline" onsubmit="return confirm('¿Marcar como NO SHOW? Se retendrá el depósito.');">
                                    <input type="hidden" name="reserva_id" value="<?= $reserva['id'] ?>">
                                    <input type="hidden" name="accion" value="no_show">
                                    <button class="btn btn-outline-danger">
                                        <i class="bi bi-x-circle me-1"></i> No Show
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php require_once __DIR__ . '/partials/footer.php'; ?>