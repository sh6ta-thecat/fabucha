<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/repositories/ReservaRepository.php';
require_once __DIR__ . '/../src/repositories/FotoRepository.php';

protegerPagina(['limpieza', 'admin', 'trabajador']);
$reservaRepo = new ReservaRepository();
$fotoRepo = new FotoRepository();
$mensaje = '';

// PROCESAR SUBIDA DE FOTO
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['foto'])) {
    $reservaId = (int)$_POST['reserva_id'];
    $tipo = $_POST['tipo'] ?? 'despues'; // 'antes' o 'despues'
    
    $dir = __DIR__ . '/../uploads/limpieza/';
    if (!is_dir($dir)) mkdir($dir, 0777, true);
    
    $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
    $filename = 'reserva_' . $reservaId . '_' . $tipo . '_' . time() . '.' . $ext;
    $ruta = $dir . $filename;
    
    if (move_uploaded_file($_FILES['foto']['tmp_name'], $ruta)) {
        $fotoRepo->registrar([
            'reserva_id' => $reservaId,
            'ruta' => 'uploads/limpieza/' . $filename,
            'tipo' => $tipo,
            'subida_por' => $_SESSION['usuario_id']
        ]);
        $_SESSION['mensaje_exito'] = 'Foto subida correctamente.';
    } else {
        $_SESSION['error'] = 'Error al subir la foto.';
    }
    header('Location: panel_limpieza.php');
    exit;
}

// Reservas finalizadas hoy que necesitan revisión
$pdo = Conexion::obtener();
$stmt = $pdo->prepare("
    SELECT r.*, c.nombre as cancha_nombre, u.nombre as cliente_nombre
    FROM reservas r
    JOIN canchas c ON r.cancha_id = c.id
    JOIN usuarios u ON r.usuario_id = u.id
    WHERE r.fecha = ? AND r.estado = 'finalizada'
    ORDER BY r.hora_salida_real DESC
");
$stmt->execute([date('Y-m-d')]);
$reservas = $stmt->fetchAll();

$titulo = 'Panel de Limpieza - Fabucha';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar_trabajador.php'; // Reusamos el navbar de trabajador, o creamos uno específico
?>

<main class="container py-4">
    <h2 class="fw-bold text-white mb-4"><i class="bi bi-bucket me-2"></i> Control de Limpieza</h2>
    
    <?php if (isset($_SESSION['mensaje_exito'])): ?>
        <div class="alert alert-success bg-success bg-opacity-25 text-success border-0 small"><?= e($_SESSION['mensaje_exito']) ?></div>
        <?php unset($_SESSION['mensaje_exito']); ?>
    <?php endif; ?>

    <div class="row g-4">
        <?php if (empty($reservas)): ?>
            <div class="col-12 text-muted">No hay canchas pendientes de limpieza por ahora.</div>
        <?php else: ?>
            <?php foreach ($reservas as $r): ?>
                <div class="col-md-4">
                    <div class="card bg-dark border-secondary text-white h-100">
                        <div class="card-body">
                            <h5 class="card-title"><?= e($r['cancha_nombre']) ?></h5>
                            <p class="small text-muted mb-2">Cliente: <?= e($r['cliente_nombre']) ?></p>
                            <p class="small text-muted mb-3">Reserva: <?= e($r['codigo']) ?></p>
                            
                            <form method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="reserva_id" value="<?= $r['id'] ?>">
                                <input type="hidden" name="tipo" value="despues">
                                <div class="mb-3">
                                    <label class="form-label small">Subir foto del estado</label>
                                    <input type="file" name="foto" class="form-control form-control-sm bg-dark text-white border-secondary" accept="image/*" required>
                                </div>
                                <button type="submit" class="btn btn-success w-100 btn-sm"><i class="bi bi-camera"></i> Registrar Limpieza</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</main>
<?php require_once __DIR__ . '/partials/footer.php'; ?>