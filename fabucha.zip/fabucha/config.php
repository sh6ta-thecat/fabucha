<?php
/**
 * config.php
 * Configuración general del sistema Fabucha.
 * Se incluye desde cualquier archivo que necesite constantes o sesión.
 */

// ============================================================
// ZONA HORARIA
// ============================================================
date_default_timezone_set('America/Lima');

// ============================================================
// MODO DEBUG (cambiar a false en producción)
// ============================================================
define('DEBUG', true);
if (DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// ============================================================
// SESIÓN SEGURA
// ============================================================
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => false,   // true si usas HTTPS
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// Regenerar CSRF token si no existe
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ============================================================
// BASE DE DATOS
// ============================================================
define('DB_HOST', 'localhost');
define('DB_NAME', 'fabucha');
define('DB_USER', 'root');
define('DB_PASS', '');           // en XAMPP por defecto está vacío
define('DB_CHARSET', 'utf8mb4');

// ============================================================
// CORREO (PHPMailer + Gmail SMTP)
// ============================================================
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USER', 'tucorreo@gmail.com');      // CAMBIAR
define('MAIL_PASS', 'xxxx xxxx xxxx xxxx');     // App Password de 16 caracteres
define('MAIL_FROM', 'tucorreo@gmail.com');      // CAMBIAR
define('MAIL_FROM_NAME', 'Local Fabucha');

// ============================================================
// REGLAS DE NEGOCIO
// ============================================================
define('DEPOSITO_FIJO', 10.00);                  // S/ depósito de daños
define('HORAS_LIMITE_PAGO', 5);                  // horas antes del inicio para pagar
define('MIN_TOLERANCIA_NO_SHOW', 15);            // minutos de tolerancia
define('MINUTOS_LIMPIEZA_ENTRE_RESERVAS', 20);   // margen antes de la siguiente reserva
define('HORA_CIERRE_LOCAL', '23:00:00');         // hora de cierre
define('HORA_APERTURA_LOCAL', '08:00:00');       // hora de apertura
define('HOLD_MINUTOS', 5);                       // duración del hold
define('MAX_INTENTOS_LOGIN', 3);                 // intentos antes de bloquear
define('MINUTOS_BLOQUEO_CUENTA', 15);            // minutos de bloqueo temporal

// ============================================================
// POLÍTICA DE CANCELACIÓN (referencia; la fuente real es la BD)
// ============================================================
define('MULTA_CANCELACION_TEMPRANA', 4);         // % retenido si cancela > 24h

// ============================================================
// RUTAS
// ============================================================
define('BASE_PATH', dirname(__FILE__));
define('UPLOADS_PATH', BASE_PATH . '/uploads');
define('UPLOADS_URL', '/fabucha/uploads');

// ============================================================
// AUTOLOAD DE COMPOSER
// ============================================================
$autoload = BASE_PATH . '/vendor/autoload.php';
if (file_exists($autoload)) {
    require_once $autoload;
}