<?php

class Horario
{
    private int $id;
    private string $horaInicio;
    private string $horaFin;
    private bool $activo;

    public function __construct(array $datos = [])
    {
        if (!empty($datos)) {
            $this->hidratar($datos);
        }
    }

    public function hidratar(array $datos): void
    {
        $this->id = (int)($datos['id'] ?? 0);
        $this->horaInicio = $datos['hora_inicio'] ?? '00:00:00';
        $this->horaFin = $datos['hora_fin'] ?? '00:00:00';
        $this->activo = (bool)($datos['activo'] ?? true);
    }

    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'hora_inicio' => $this->horaInicio,
            'hora_fin' => $this->horaFin,
            'activo' => $this->activo ? 1 : 0,
        ];
    }

    // --- Getters ---
    public function getId(): int { return $this->id; }
    public function getHoraInicio(): string { return $this->horaInicio; }
    public function getHoraFin(): string { return $this->horaFin; }
    public function isActivo(): bool { return $this->activo; }

    // --- Métodos de negocio ---
    public function getRangoFormateado(): string
    {
        return substr($this->horaInicio, 0, 5) . ' - ' . substr($this->horaFin, 0, 5);
    }

    public function duracionMinutos(): int
    {
        $inicio = strtotime($this->horaInicio);
        $fin = strtotime($this->horaFin);
        return (int)(($fin - $inicio) / 60);
    }
}