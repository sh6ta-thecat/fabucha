<?php

class Reserva
{
    private int $id;
    private string $codigo;
    private int $usuarioId;
    private int $canchaId;
    private int $deporteId;
    private string $fecha;
    private int $horarioId;
    private int $cantidadPersonas;
    private ?string $nombreEquipo;
    private string $estado;
    private float $montoCancha;
    private float $montoDeposito;
    private float $montoTotal;
    private float $montoPagado;
    private float $montoReembolsado;
    private float $multaAplicada;
    private bool $depositoDevuelto;
    private int $minutosExtra;
    private float $montoExtra;
    private bool $sobretiempoPagado;
    private ?string $expiraEn;
    private ?string $limitePago;
    private ?string $horaIngresoReal;
    private ?string $horaSalidaReal;
    private ?string $horaFinExtendida;
    private ?int $verificadoPor;
    private ?int $registradoPor;
    private ?string $observaciones;
    private string $creadaEn;
    private string $actualizadaEn;

    public function __construct(array $datos = [])
    {
        if (!empty($datos)) {
            $this->hidratar($datos);
        }
    }

    public function hidratar(array $datos): void
    {
        $this->id = (int)($datos['id'] ?? 0);
        $this->codigo = $datos['codigo'] ?? '';
        $this->usuarioId = (int)($datos['usuario_id'] ?? 0);
        $this->canchaId = (int)($datos['cancha_id'] ?? 0);
        $this->deporteId = (int)($datos['deporte_id'] ?? 0);
        $this->fecha = $datos['fecha'] ?? '';
        $this->horarioId = (int)($datos['horario_id'] ?? 0);
        $this->cantidadPersonas = (int)($datos['cantidad_personas'] ?? 0);
        $this->nombreEquipo = $datos['nombre_equipo'] ?? null;
        $this->estado = $datos['estado'] ?? 'hold';
        $this->montoCancha = (float)($datos['monto_cancha'] ?? 0);
        $this->montoDeposito = (float)($datos['monto_deposito'] ?? 0);
        $this->montoTotal = (float)($datos['monto_total'] ?? 0);
        $this->montoPagado = (float)($datos['monto_pagado'] ?? 0);
        $this->montoReembolsado = (float)($datos['monto_reembolsado'] ?? 0);
        $this->multaAplicada = (float)($datos['multa_aplicada'] ?? 0);
        $this->depositoDevuelto = (bool)($datos['deposito_devuelto'] ?? false);
        $this->minutosExtra = (int)($datos['minutos_extra'] ?? 0);
        $this->montoExtra = (float)($datos['monto_extra'] ?? 0);
        $this->sobretiempoPagado = (bool)($datos['sobretiempo_pagado'] ?? false);
        $this->expiraEn = $datos['expira_en'] ?? null;
        $this->limitePago = $datos['limite_pago'] ?? null;
        $this->horaIngresoReal = $datos['hora_ingreso_real'] ?? null;
        $this->horaSalidaReal = $datos['hora_salida_real'] ?? null;
        $this->horaFinExtendida = $datos['hora_fin_extendida'] ?? null;
        $this->verificadoPor = isset($datos['verificado_por']) ? (int)$datos['verificado_por'] : null;
        $this->registradoPor = isset($datos['registrado_por']) ? (int)$datos['registrado_por'] : null;
        $this->observaciones = $datos['observaciones'] ?? null;
        $this->creadaEn = $datos['creada_en'] ?? '';
        $this->actualizadaEn = $datos['actualizada_en'] ?? '';
    }

    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'codigo' => $this->codigo,
            'usuario_id' => $this->usuarioId,
            'cancha_id' => $this->canchaId,
            'deporte_id' => $this->deporteId,
            'fecha' => $this->fecha,
            'horario_id' => $this->horarioId,
            'cantidad_personas' => $this->cantidadPersonas,
            'nombre_equipo' => $this->nombreEquipo,
            'estado' => $this->estado,
            'monto_cancha' => $this->montoCancha,
            'monto_deposito' => $this->montoDeposito,
            'monto_total' => $this->montoTotal,
            'monto_pagado' => $this->montoPagado,
            'monto_reembolsado' => $this->montoReembolsado,
            'multa_aplicada' => $this->multaAplicada,
            'deposito_devuelto' => $this->depositoDevuelto ? 1 : 0,
            'minutos_extra' => $this->minutosExtra,
            'monto_extra' => $this->montoExtra,
            'sobretiempo_pagado' => $this->sobretiempoPagado ? 1 : 0,
            'expira_en' => $this->expiraEn,
            'limite_pago' => $this->limitePago,
            'hora_ingreso_real' => $this->horaIngresoReal,
            'hora_salida_real' => $this->horaSalidaReal,
            'hora_fin_extendida' => $this->horaFinExtendida,
            'verificado_por' => $this->verificadoPor,
            'registrado_por' => $this->registradoPor,
            'observaciones' => $this->observaciones,
            'creada_en' => $this->creadaEn,
            'actualizada_en' => $this->actualizadaEn,
        ];
    }

    // --- Getters ---
    public function getId(): int { return $this->id; }
    public function getCodigo(): string { return $this->codigo; }
    public function getUsuarioId(): int { return $this->usuarioId; }
    public function getCanchaId(): int { return $this->canchaId; }
    public function getDeporteId(): int { return $this->deporteId; }
    public function getFecha(): string { return $this->fecha; }
    public function getHorarioId(): int { return $this->horarioId; }
    public function getCantidadPersonas(): int { return $this->cantidadPersonas; }
    public function getNombreEquipo(): ?string { return $this->nombreEquipo; }
    public function getEstado(): string { return $this->estado; }
    public function getMontoCancha(): float { return $this->montoCancha; }
    public function getMontoDeposito(): float { return $this->montoDeposito; }
    public function getMontoTotal(): float { return $this->montoTotal; }
    public function getMontoPagado(): float { return $this->montoPagado; }
    public function getMontoReembolsado(): float { return $this->montoReembolsado; }
    public function getMultaAplicada(): float { return $this->multaAplicada; }
    public function isDepositoDevuelto(): bool { return $this->depositoDevuelto; }
    public function getMinutosExtra(): int { return $this->minutosExtra; }
    public function getMontoExtra(): float { return $this->montoExtra; }
    public function isSobretiempoPagado(): bool { return $this->sobretiempoPagado; }
    public function getExpiraEn(): ?string { return $this->expiraEn; }
    public function getLimitePago(): ?string { return $this->limitePago; }
    public function getHoraIngresoReal(): ?string { return $this->horaIngresoReal; }
    public function getHoraSalidaReal(): ?string { return $this->horaSalidaReal; }
    public function getHoraFinExtendida(): ?string { return $this->horaFinExtendida; }
    public function getVerificadoPor(): ?int { return $this->verificadoPor; }
    public function getRegistradoPor(): ?int { return $this->registradoPor; }
    public function getObservaciones(): ?string { return $this->observaciones; }

    // --- Setters ---
    public function setEstado(string $estado): void { $this->estado = $estado; }
    public function setMontoPagado(float $monto): void { $this->montoPagado = $monto; }
    public function setVerificadoPor(?int $id): void { $this->verificadoPor = $id; }

    // --- Métodos de negocio ---
    public function estaActiva(): bool
    {
        return in_array($this->estado, ['hold', 'pendiente_pago', 'pagada_parcial', 'pagada_total', 'en_uso'], true);
    }

    public function estaPagadaCompleta(): bool
    {
        return $this->montoPagado >= $this->montoTotal;
    }

    public function saldoPendiente(): float
    {
        return max(0, $this->montoTotal - $this->montoPagado);
    }
}