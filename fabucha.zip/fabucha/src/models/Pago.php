<?php

class Pago
{
    private int $id;
    private int $reservaId;
    private string $tipo;
    private string $metodo;
    private float $monto;
    private string $estado;
    private ?int $pagadoPor;
    private int $registradoPor;
    private ?string $comprobante;
    private string $fechaPago;

    public function __construct(array $datos = [])
    {
        if (!empty($datos)) {
            $this->hidratar($datos);
        }
    }

    public function hidratar(array $datos): void
    {
        $this->id = (int)($datos['id'] ?? 0);
        $this->reservaId = (int)($datos['reserva_id'] ?? 0);
        $this->tipo = $datos['tipo'] ?? 'reserva';
        $this->metodo = $datos['metodo'] ?? 'efectivo';
        $this->monto = (float)($datos['monto'] ?? 0);
        $this->estado = $datos['estado'] ?? 'pagado';
        $this->pagadoPor = isset($datos['pagado_por']) ? (int)$datos['pagado_por'] : null;
        $this->registradoPor = (int)($datos['registrado_por'] ?? 0);
        $this->comprobante = $datos['comprobante'] ?? null;
        $this->fechaPago = $datos['fecha_pago'] ?? '';
    }

    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'reserva_id' => $this->reservaId,
            'tipo' => $this->tipo,
            'metodo' => $this->metodo,
            'monto' => $this->monto,
            'estado' => $this->estado,
            'pagado_por' => $this->pagadoPor,
            'registrado_por' => $this->registradoPor,
            'comprobante' => $this->comprobante,
            'fecha_pago' => $this->fechaPago,
        ];
    }

    // --- Getters ---
    public function getId(): int { return $this->id; }
    public function getReservaId(): int { return $this->reservaId; }
    public function getTipo(): string { return $this->tipo; }
    public function getMetodo(): string { return $this->metodo; }
    public function getMonto(): float { return $this->monto; }
    public function getEstado(): string { return $this->estado; }
    public function getPagadoPor(): ?int { return $this->pagadoPor; }
    public function getRegistradoPor(): int { return $this->registradoPor; }
    public function getComprobante(): ?string { return $this->comprobante; }
    public function getFechaPago(): string { return $this->fechaPago; }

    // --- Métodos de negocio ---
    public function esPagado(): bool { return $this->estado === 'pagado'; }
    public function esSobretiempo(): bool { return $this->tipo === 'sobretiempo'; }
    public function esReembolso(): bool { return $this->tipo === 'reembolso'; }
}