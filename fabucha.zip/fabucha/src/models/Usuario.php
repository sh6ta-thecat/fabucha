<?php

class Usuario
{
    private int $id;
    private string $nombre;
    private string $email;
    private string $password;
    private ?string $telefono;
    private string $rol;
    private ?string $tipoTrabajador;
    private int $intentosFallidos;
    private bool $cuentaBloqueada;
    private ?string $fechaBloqueo;
    private bool $activo;
    private float $deudaPendiente;
    private string $creadoEn;
    private string $actualizadoEn;

    public function __construct(array $datos = [])
    {
        if (!empty($datos)) {
            $this->hidratar($datos);
        }
    }

    public function hidratar(array $datos): void
    {
        $this->id = (int)($datos['id'] ?? 0);
        $this->nombre = $datos['nombre'] ?? '';
        $this->email = $datos['email'] ?? '';
        $this->password = $datos['password'] ?? '';
        $this->telefono = $datos['telefono'] ?? null;
        $this->rol = $datos['rol'] ?? 'cliente';
        $this->tipoTrabajador = $datos['tipo_trabajador'] ?? null;
        $this->intentosFallidos = (int)($datos['intentos_fallidos'] ?? 0);
        $this->cuentaBloqueada = (bool)($datos['cuenta_bloqueada'] ?? false);
        $this->fechaBloqueo = $datos['fecha_bloqueo'] ?? null;
        $this->activo = (bool)($datos['activo'] ?? true);
        $this->deudaPendiente = (float)($datos['deuda_pendiente'] ?? 0.00);
        $this->creadoEn = $datos['creado_en'] ?? '';
        $this->actualizadoEn = $datos['actualizado_en'] ?? '';
    }

    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'nombre' => $this->nombre,
            'email' => $this->email,
            'password' => $this->password,
            'telefono' => $this->telefono,
            'rol' => $this->rol,
            'tipo_trabajador' => $this->tipoTrabajador,
            'intentos_fallidos' => $this->intentosFallidos,
            'cuenta_bloqueada' => $this->cuentaBloqueada ? 1 : 0,
            'fecha_bloqueo' => $this->fechaBloqueo,
            'activo' => $this->activo ? 1 : 0,
            'deuda_pendiente' => $this->deudaPendiente,
            'creado_en' => $this->creadoEn,
            'actualizado_en' => $this->actualizadoEn,
        ];
    }

    // --- Getters ---
    public function getId(): int { return $this->id; }
    public function getNombre(): string { return $this->nombre; }
    public function getEmail(): string { return $this->email; }
    public function getPassword(): string { return $this->password; }
    public function getTelefono(): ?string { return $this->telefono; }
    public function getRol(): string { return $this->rol; }
    public function getTipoTrabajador(): ?string { return $this->tipoTrabajador; }
    public function getIntentosFallidos(): int { return $this->intentosFallidos; }
    public function isCuentaBloqueada(): bool { return $this->cuentaBloqueada; }
    public function getFechaBloqueo(): ?string { return $this->fechaBloqueo; }
    public function isActivo(): bool { return $this->activo; }
    public function getDeudaPendiente(): float { return $this->deudaPendiente; }
    public function getCreadoEn(): string { return $this->creadoEn; }         // <-- AGREGADO
    public function getActualizadoEn(): string { return $this->actualizadoEn; } // <-- AGREGADO

    // --- Setters ---
    public function setNombre(string $nombre): void { $this->nombre = $nombre; }
    public function setEmail(string $email): void { $this->email = $email; }
    public function setPassword(string $password): void { $this->password = $password; }
    public function setTelefono(?string $telefono): void { $this->telefono = $telefono; }
    public function setRol(string $rol): void { $this->rol = $rol; }
    public function setDeudaPendiente(float $deuda): void { $this->deudaPendiente = $deuda; }

    // --- Métodos de negocio ---
    public function esAdmin(): bool { return $this->rol === 'admin'; }
    public function esTrabajador(): bool { return $this->rol === 'trabajador'; }
    public function esCliente(): bool { return $this->rol === 'cliente'; }
    public function tieneDeuda(): bool { return $this->deudaPendiente > 0; }
}