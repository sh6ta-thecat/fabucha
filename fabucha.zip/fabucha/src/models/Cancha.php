<?php

class Cancha
{
    private int $id;
    private string $nombre;
    private int $capacidadTribuna;
    private int $capacidadJugadores;
    private int $aforoMaximo;
    private bool $activa;
    private string $creadaEn;
    
    // Propiedades adicionales que pueden venir de JOINs
    private ?string $deportes;
    private ?float $precioMinimo;
    private array $deportesDetalle;

    public function __construct(array $datos = [])
    {
        $this->deportesDetalle = [];
        if (!empty($datos)) {
            $this->hidratar($datos);
        }
    }

    public function hidratar(array $datos): void
    {
        $this->id = (int)($datos['id'] ?? 0);
        $this->nombre = $datos['nombre'] ?? '';
        $this->capacidadTribuna = (int)($datos['capacidad_tribuna'] ?? 40);
        $this->capacidadJugadores = (int)($datos['capacidad_jugadores'] ?? 10);
        $this->aforoMaximo = (int)($datos['aforo_maximo'] ?? 50);
        $this->activa = (bool)($datos['activa'] ?? true);
        $this->creadaEn = $datos['creada_en'] ?? '';
        $this->deportes = $datos['deportes'] ?? null;
        $this->precioMinimo = isset($datos['precio_minimo']) ? (float)$datos['precio_minimo'] : null;
    }

    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'nombre' => $this->nombre,
            'capacidad_tribuna' => $this->capacidadTribuna,
            'capacidad_jugadores' => $this->capacidadJugadores,
            'aforo_maximo' => $this->aforoMaximo,
            'activa' => $this->activa ? 1 : 0,
            'creada_en' => $this->creadaEn,
            'deportes' => $this->deportes,
            'precio_minimo' => $this->precioMinimo,
        ];
    }

    // --- Getters ---
    public function getId(): int { return $this->id; }
    public function getNombre(): string { return $this->nombre; }
    public function getCapacidadTribuna(): int { return $this->capacidadTribuna; }
    public function getCapacidadJugadores(): int { return $this->capacidadJugadores; }
    public function getAforoMaximo(): int { return $this->aforoMaximo; }
    public function isActiva(): bool { return $this->activa; }
    public function getDeportes(): ?string { return $this->deportes; }
    public function getPrecioMinimo(): ?float { return $this->precioMinimo; }
    public function getDeportesDetalle(): array { return $this->deportesDetalle; }

    // --- Setters ---
    public function setDeportesDetalle(array $detalle): void { $this->deportesDetalle = $detalle; }

    // --- Métodos de negocio ---
    public function validarAforo(int $cantidadPersonas): bool
    {
        return $cantidadPersonas > 0 && $cantidadPersonas <= $this->aforoMaximo;
    }
}