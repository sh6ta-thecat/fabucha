<?php

class Deporte
{
    private int $id;
    private string $nombre;
    private ?string $descripcion;
    private bool $activo;
    private ?float $precioHora; // Puede venir de un JOIN con cancha_deporte

    public function __construct(array $datos = [])
    {
        if (!empty($datos)) {
            $this->hidratar($datos);
        }
    }

    public function hidratar(array $datos): void
    {
        $this->id = (int)($datos['id'] ?? 0);
        $this->nombre = $datos['nombre'] ?? '';
        $this->descripcion = $datos['descripcion'] ?? null;
        $this->activo = (bool)($datos['activo'] ?? true);
        $this->precioHora = isset($datos['precio_hora']) ? (float)$datos['precio_hora'] : null;
    }

    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'nombre' => $this->nombre,
            'descripcion' => $this->descripcion,
            'activo' => $this->activo ? 1 : 0,
            'precio_hora' => $this->precioHora,
        ];
    }

    // --- Getters ---
    public function getId(): int { return $this->id; }
    public function getNombre(): string { return $this->nombre; }
    public function getDescripcion(): ?string { return $this->descripcion; }
    public function isActivo(): bool { return $this->activo; }
    public function getPrecioHora(): ?float { return $this->precioHora; }

    // --- Métodos de negocio ---
    public function esFutbol(): bool
    {
        return stripos($this->nombre, 'fútbol') !== false || stripos($this->nombre, 'futbol') !== false;
    }

    public function esVoley(): bool
    {
        return stripos($this->nombre, 'vóley') !== false || stripos($this->nombre, 'voley') !== false;
    }
}