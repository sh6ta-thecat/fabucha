<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/conexion.php';
require_once __DIR__ . '/helpers.php';

/**
 * Redirige al login si no hay sesión o si el rol no está permitido.
 */
function protegerPagina(array $rolesPermitidos = []): void
{
    if (!estaLogueado()) {
        $_SESSION['error_login'] = 'Debes iniciar sesión para acceder.';
        redirigir('/fabucha/public/login.php');
    }

    if (!empty($rolesPermitidos) && !in_array(rolActual(), $rolesPermitidos, true)) {
        redirigir('/fabucha/public/index.php');
    }

    // Verificar que el usuario siga activo y no bloqueado
    try {
        $pdo = Conexion::obtener();
        $stmt = $pdo->prepare('SELECT activo, cuenta_bloqueada, deuda_pendiente FROM usuarios WHERE id = ?');
        $stmt->execute([$_SESSION['usuario_id']]);
        $u = $stmt->fetch();
        
        if (!$u || (int)$u['activo'] !== 1) {
            cerrarSesion();
            redirigir('/fabucha/public/login.php');
        }
        if ((int)$u['cuenta_bloqueada'] === 1) {
            cerrarSesion();
            $_SESSION['error_login'] = 'Tu cuenta está bloqueada. Contacta al administrador.';
            redirigir('/fabucha/public/login.php');
        }
        
        // Actualizar deuda en sesión por si cambió
        $_SESSION['deuda_pendiente'] = (float)$u['deuda_pendiente'];

    } catch (Exception $e) {
        redirigir('/fabucha/public/login.php');
    }
}

/**
 * Guarda los datos del usuario en sesión tras login exitoso.
 */
function iniciarSesionUsuario(array $usuario): void
{
    session_regenerate_id(true);
    $_SESSION['usuario_id'] = (int)$usuario['id'];
    $_SESSION['nombre']     = $usuario['nombre'];
    $_SESSION['email']      = $usuario['email'];
    $_SESSION['rol']        = $usuario['rol'];
    $_SESSION['tipo_trabajador'] = $usuario['tipo_trabajador'] ?? null;
    $_SESSION['deuda_pendiente'] = (float)($usuario['deuda_pendiente'] ?? 0);
    $_SESSION['login_en']   = time();
}

/**
 * Cierra la sesión completamente.
 */
function cerrarSesion(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}