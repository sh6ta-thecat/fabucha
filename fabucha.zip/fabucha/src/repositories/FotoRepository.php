<?php
require_once __DIR__ . '/../conexion.php';

class FotoRepository
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = Conexion::obtener();
    }

    public function registrar(array $datos): int
    {
        $stmt = $this->pdo->prepare("
            INSERT INTO fotos_limpieza (reserva_id, ruta, tipo, subida_por)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $datos['reserva_id'],
            $datos['ruta'],
            $datos['tipo'] ?? 'despues',
            $datos['subida_por']
        ]);
        return (int)$this->pdo->lastInsertId();
    }

    public function obtenerPorReserva(int $reservaId): array
    {
        $stmt = $this->pdo->prepare("
            SELECT f.*, u.nombre as subida_por_nombre 
            FROM fotos_limpieza f
            JOIN usuarios u ON f.subida_por = u.id
            WHERE f.reserva_id = ? 
            ORDER BY f.fecha_subida DESC
        ");
        $stmt->execute([$reservaId]);
        return $stmt->fetchAll();
    }
}