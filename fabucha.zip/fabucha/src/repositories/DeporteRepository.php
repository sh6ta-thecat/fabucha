<?php
require_once __DIR__ . '/../conexion.php';

class DeporteRepository
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = Conexion::obtener();
    }

    public function obtenerTodos(): array
    {
        $stmt = $this->pdo->query("SELECT * FROM deportes WHERE activo = 1 ORDER BY nombre ASC");
        return $stmt->fetchAll();
    }

    public function buscarPorId(int $id): ?array
    {
        $stmt = $this->pdo->prepare("SELECT * FROM deportes WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }
}