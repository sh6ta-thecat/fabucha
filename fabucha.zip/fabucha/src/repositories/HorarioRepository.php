<?php
require_once __DIR__ . '/../conexion.php';

class HorarioRepository
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = Conexion::obtener();
    }

    public function obtenerTodos(): array
    {
        $stmt = $this->pdo->query("SELECT * FROM horarios WHERE activo = 1 ORDER BY hora_inicio ASC");
        return $stmt->fetchAll();
    }

    public function buscarPorId(int $id): ?array
    {
        $stmt = $this->pdo->prepare("SELECT * FROM horarios WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function obtenerHoraInicio(int $id): ?string
    {
        $stmt = $this->pdo->prepare("SELECT hora_inicio FROM horarios WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        $hora = $stmt->fetchColumn();
        return $hora !== false ? $hora : null;
    }

    public function obtenerHoraFin(int $id): ?string
    {
        $stmt = $this->pdo->prepare("SELECT hora_fin FROM horarios WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        $hora = $stmt->fetchColumn();
        return $hora !== false ? $hora : null;
    }
}