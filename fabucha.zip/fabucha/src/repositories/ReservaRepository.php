<?php
require_once __DIR__ . '/../conexion.php';

class ReservaRepository
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = Conexion::obtener();
    }

    public function crear(array $datos): int
    {
        $stmt = $this->pdo->prepare("
            INSERT INTO reservas (
                codigo, usuario_id, cancha_id, deporte_id, fecha, horario_id, 
                cantidad_personas, nombre_equipo, estado, monto_cancha, 
                monto_deposito, monto_total, expira_en, limite_pago, registrado_por
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $datos['codigo'],
            $datos['usuario_id'],
            $datos['cancha_id'],
            $datos['deporte_id'],
            $datos['fecha'],
            $datos['horario_id'],
            $datos['cantidad_personas'],
            $datos['nombre_equipo'] ?? null,
            $datos['estado'] ?? 'hold',
            $datos['monto_cancha'],
            $datos['monto_deposito'],
            $datos['monto_total'],
            $datos['expira_en'] ?? null,
            $datos['limite_pago'] ?? null,
            $datos['registrado_por']
        ]);
        
        return (int)$this->pdo->lastInsertId();
    }

    public function buscarPorId(int $id): ?array
    {
        $stmt = $this->pdo->prepare("SELECT * FROM reservas WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function buscarPorCodigo(string $codigo): ?array
    {
        $stmt = $this->pdo->prepare("
            SELECT r.*, u.nombre as cliente_nombre, c.nombre as cancha_nombre, h.hora_inicio, h.hora_fin
            FROM reservas r
            JOIN usuarios u ON r.usuario_id = u.id
            JOIN canchas c ON r.cancha_id = c.id
            JOIN horarios h ON r.horario_id = h.id
            WHERE r.codigo = ? LIMIT 1
        ");
        $stmt->execute([$codigo]);
        return $stmt->fetch() ?: null;
    }

    public function verificarDisponibilidad(int $canchaId, string $fecha, int $horarioId): bool
    {
        $stmt = $this->pdo->prepare("
            SELECT id FROM reservas 
            WHERE cancha_id = ? AND fecha = ? AND horario_id = ? 
            AND estado IN ('hold', 'pendiente_pago', 'pagada_parcial', 'pagada_total', 'en_uso')
            LIMIT 1
        ");
        $stmt->execute([$canchaId, $fecha, $horarioId]);
        return $stmt->fetch() === false;
    }

    public function actualizarEstado(int $id, string $nuevoEstado, ?string $motivo = null): bool
    {
        $stmt = $this->pdo->prepare("UPDATE reservas SET estado = ? WHERE id = ?");
        $resultado = $stmt->execute([$nuevoEstado, $id]);

        if ($resultado && $motivo !== null) {
            $stmtLog = $this->pdo->prepare("
                INSERT INTO logs_reservas (reserva_id, estado_nuevo, motivo) 
                VALUES (?, ?, ?)
            ");
            $stmtLog->execute([$id, $nuevoEstado, $motivo]);
        }
        
        return $resultado;
    }

    public function actualizarCancelacion(int $id, string $estado, float $reembolso, float $multa): bool
    {
        $stmt = $this->pdo->prepare("
            UPDATE reservas 
            SET estado = ?, monto_reembolsado = ?, multa_aplicada = ?, actualizada_en = NOW()
            WHERE id = ?
        ");
        return $stmt->execute([$estado, $reembolso, $multa, $id]);
    }

    public function obtenerReservasUsuario(int $usuarioId): array
    {
        $stmt = $this->pdo->prepare("
            SELECT r.*, c.nombre as cancha_nombre, h.hora_inicio, h.hora_fin, d.nombre as deporte_nombre
            FROM reservas r
            JOIN canchas c ON r.cancha_id = c.id
            JOIN horarios h ON r.horario_id = h.id
            JOIN deportes d ON r.deporte_id = d.id
            WHERE r.usuario_id = ?
            ORDER BY r.fecha DESC, h.hora_inicio DESC
        ");
        $stmt->execute([$usuarioId]);
        return $stmt->fetchAll();
    }

    public function obtenerReservasDelDia(string $fecha): array
    {
        $stmt = $this->pdo->prepare("
            SELECT r.*, u.nombre as cliente_nombre, c.nombre as cancha_nombre, h.hora_inicio, h.hora_fin
            FROM reservas r
            JOIN usuarios u ON r.usuario_id = u.id
            JOIN canchas c ON r.cancha_id = c.id
            JOIN horarios h ON r.horario_id = h.id
            WHERE r.fecha = ? AND r.estado NOT IN ('hold', 'cancelada_cliente', 'cancelada_local', 'cancelada_falta_pago')
            ORDER BY h.hora_inicio ASC
        ");
        $stmt->execute([$fecha]);
        return $stmt->fetchAll();
    }
}