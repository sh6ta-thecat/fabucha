<?php
require_once __DIR__ . '/../conexion.php';

class UsuarioRepository
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = Conexion::obtener();
    }

    public function buscarPorEmail(string $email): ?array
    {
        $stmt = $this->pdo->prepare("SELECT * FROM usuarios WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $usuario = $stmt->fetch();
        return $usuario ?: null;
    }

    public function buscarPorId(int $id): ?array
    {
        $stmt = $this->pdo->prepare("SELECT * FROM usuarios WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        $usuario = $stmt->fetch();
        return $usuario ?: null;
    }

    public function crear(array $datos): int
    {
        $stmt = $this->pdo->prepare("
            INSERT INTO usuarios (nombre, email, password, telefono, rol, tipo_trabajador, activo) 
            VALUES (?, ?, ?, ?, ?, ?, 1)
        ");
        $stmt->execute([
            $datos['nombre'],
            $datos['email'],
            $datos['password'],
            $datos['telefono'] ?? null,
            $datos['rol'] ?? 'cliente',
            $datos['tipo_trabajador'] ?? null
        ]);
        return (int)$this->pdo->lastInsertId();
    }

    public function incrementarIntentos(int $id): void
    {
        $stmt = $this->pdo->prepare("UPDATE usuarios SET intentos_fallidos = intentos_fallidos + 1 WHERE id = ?");
        $stmt->execute([$id]);
    }

    public function resetearIntentos(int $id): void
    {
        $stmt = $this->pdo->prepare("UPDATE usuarios SET intentos_fallidos = 0 WHERE id = ?");
        $stmt->execute([$id]);
    }

    public function bloquearCuenta(int $id): void
    {
        $stmt = $this->pdo->prepare("UPDATE usuarios SET cuenta_bloqueada = 1, fecha_bloqueo = NOW() WHERE id = ?");
        $stmt->execute([$id]);
    }

    public function desbloquearCuenta(int $id): void
    {
        $stmt = $this->pdo->prepare("UPDATE usuarios SET cuenta_bloqueada = 0, intentos_fallidos = 0, fecha_bloqueo = NULL WHERE id = ?");
        $stmt->execute([$id]);
    }

    public function agregarDeuda(int $id, float $monto): void
    {
        $stmt = $this->pdo->prepare("UPDATE usuarios SET deuda_pendiente = deuda_pendiente + ? WHERE id = ?");
        $stmt->execute([$monto, $id]);
    }

    public function saldarDeuda(int $id): void
    {
        $stmt = $this->pdo->prepare("UPDATE usuarios SET deuda_pendiente = 0 WHERE id = ?");
        $stmt->execute([$id]);
    }
}