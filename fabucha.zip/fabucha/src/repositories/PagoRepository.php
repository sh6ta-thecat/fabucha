<?php
require_once __DIR__ . '/../conexion.php';

class PagoRepository
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = Conexion::obtener();
    }

    public function registrar(array $datos): int
    {
        $stmt = $this->pdo->prepare("
            INSERT INTO pagos (reserva_id, tipo, metodo, monto, estado, pagado_por, registrado_por, comprobante)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $datos['reserva_id'],
            $datos['tipo'],
            $datos['metodo'],
            $datos['monto'],
            $datos['estado'] ?? 'pagado',
            $datos['pagado_por'] ?? null,
            $datos['registrado_por'],
            $datos['comprobante'] ?? null
        ]);
        return (int)$this->pdo->lastInsertId();
    }

    public function obtenerPagosDeReserva(int $reservaId): array
    {
        $stmt = $this->pdo->prepare("
            SELECT p.*, u.nombre as registrado_por_nombre 
            FROM pagos p
            LEFT JOIN usuarios u ON p.registrado_por = u.id
            WHERE p.reserva_id = ? 
            ORDER BY p.fecha_pago DESC
        ");
        $stmt->execute([$reservaId]);
        return $stmt->fetchAll();
    }

    public function obtenerIngresosPorRango(string $desde, string $hasta): float
    {
        $stmt = $this->pdo->prepare("
            SELECT COALESCE(SUM(monto), 0) FROM pagos 
            WHERE estado = 'pagado' AND DATE(fecha_pago) BETWEEN ? AND ?
        ");
        $stmt->execute([$desde, $hasta]);
        return (float)$stmt->fetchColumn();
    }
}