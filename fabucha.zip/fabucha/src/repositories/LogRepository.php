<?php
require_once __DIR__ . '/../conexion.php';

class LogRepository
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = Conexion::obtener();
    }

    public function registrarAcceso(?int $usuarioId, ?string $email, string $evento): void
    {
        $stmt = $this->pdo->prepare("
            INSERT INTO logs_acceso (usuario_id, email_intentado, evento, ip, user_agent)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $usuarioId,
            $email,
            $evento,
            $_SERVER['REMOTE_ADDR'] ?? 'desconocida',
            substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255)
        ]);
    }

    public function registrarCambioReserva(int $reservaId, ?string $estadoAnterior, string $estadoNuevo, ?string $motivo, ?int $usuarioId = null): void
    {
        $stmt = $this->pdo->prepare("
            INSERT INTO logs_reservas (reserva_id, estado_anterior, estado_nuevo, motivo, usuario_id)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$reservaId, $estadoAnterior, $estadoNuevo, $motivo, $usuarioId]);
    }

    public function obtenerAccesosRecientes(int $limite = 50): array
    {
        $stmt = $this->pdo->prepare("
            SELECT l.*, u.nombre as usuario_nombre 
            FROM logs_acceso l
            LEFT JOIN usuarios u ON l.usuario_id = u.id
            ORDER BY l.fecha DESC 
            LIMIT ?
        ");
        $stmt->bindValue(1, $limite, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}