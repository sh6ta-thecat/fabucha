<?php
require_once __DIR__ . '/../conexion.php';

class BloqueoRepository
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = Conexion::obtener();
    }

    public function crear(array $datos): int
    {
        $stmt = $this->pdo->prepare("
            INSERT INTO bloqueos_cancha (cancha_id, fecha_inicio, fecha_fin, motivo, creado_por)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $datos['cancha_id'],
            $datos['fecha_inicio'],
            $datos['fecha_fin'],
            $datos['motivo'],
            $datos['creado_por']
        ]);
        return (int)$this->pdo->lastInsertId();
    }

    public function estaBloqueada(int $canchaId, string $fecha): bool
    {
        $stmt = $this->pdo->prepare("
            SELECT id FROM bloqueos_cancha 
            WHERE cancha_id = ? 
            AND DATE(fecha_inicio) <= ? 
            AND DATE(fecha_fin) >= ?
            LIMIT 1
        ");
        $stmt->execute([$canchaId, $fecha, $fecha]);
        return $stmt->fetch() !== false;
    }

    public function obtenerPorCancha(int $canchaId): array
    {
        $stmt = $this->pdo->prepare("SELECT * FROM bloqueos_cancha WHERE cancha_id = ? ORDER BY fecha_inicio DESC");
        $stmt->execute([$canchaId]);
        return $stmt->fetchAll();
    }
}