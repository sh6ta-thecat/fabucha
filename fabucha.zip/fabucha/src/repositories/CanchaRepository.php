<?php
require_once __DIR__ . '/../conexion.php';

class CanchaRepository
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = Conexion::obtener();
    }

    public function obtenerTodasConDeportes(): array
    {
        $stmt = $this->pdo->query("
            SELECT c.*, 
                   GROUP_CONCAT(DISTINCT d.nombre SEPARATOR ', ') AS deportes,
                   MIN(cd.precio_hora) AS precio_minimo
            FROM canchas c
            LEFT JOIN cancha_deporte cd ON cd.cancha_id = c.id
            LEFT JOIN deportes d ON d.id = cd.deporte_id AND d.activo = 1
            WHERE c.activa = 1
            GROUP BY c.id
            ORDER BY c.nombre ASC
        ");
        return $stmt->fetchAll();
    }

    public function buscarPorId(int $id): ?array
    {
        $stmt = $this->pdo->prepare("SELECT * FROM canchas WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    public function obtenerDeportesDeCancha(int $canchaId): array
    {
        $stmt = $this->pdo->prepare("
            SELECT d.id, d.nombre, cd.precio_hora
            FROM cancha_deporte cd
            JOIN deportes d ON cd.deporte_id = d.id
            WHERE cd.cancha_id = ? AND d.activo = 1
        ");
        $stmt->execute([$canchaId]);
        return $stmt->fetchAll();
    }

    public function obtenerPrecio(int $canchaId, int $deporteId): ?float
    {
        $stmt = $this->pdo->prepare("SELECT precio_hora FROM cancha_deporte WHERE cancha_id = ? AND deporte_id = ?");
        $stmt->execute([$canchaId, $deporteId]);
        $precio = $stmt->fetchColumn();
        return $precio !== false ? (float)$precio : null;
    }

    public function crear(array $datos): int
    {
        $stmt = $this->pdo->prepare("
            INSERT INTO canchas (nombre, capacidad_tribuna, capacidad_jugadores, aforo_maximo, activa)
            VALUES (?, ?, ?, ?, 1)
        ");
        $stmt->execute([
            $datos['nombre'],
            $datos['capacidad_tribuna'] ?? 40,
            $datos['capacidad_jugadores'] ?? 10,
            $datos['aforo_maximo'] ?? 50
        ]);
        return (int)$this->pdo->lastInsertId();
    }
}