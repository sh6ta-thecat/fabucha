<?php
require_once __DIR__ . '/../conexion.php';

class ReporteService
{
    /**
     * Devuelve métricas generales para el dashboard.
     */
    public function obtenerMetricasDashboard(): array
    {
        $pdo = Conexion::obtener();
        
        $hoy = date('Y-m-d');
        $inicioMes = date('Y-m-01');
        $finMes = date('Y-m-t');

        // Reservas de hoy
        $reservasHoy = $pdo->query("
            SELECT COUNT(*) FROM reservas 
            WHERE fecha = '$hoy' AND estado IN ('pagada_total', 'en_uso', 'finalizada')
        ")->fetchColumn();

        // Ingresos del mes
        $ingresosMes = $pdo->query("
            SELECT COALESCE(SUM(monto), 0) FROM pagos 
            WHERE DATE(fecha_pago) BETWEEN '$inicioMes' AND '$finMes' 
            AND estado = 'pagado'
        ")->fetchColumn();

        // Cancha más usada (top 1)
        $canchaTop = $pdo->query("
            SELECT c.nombre, COUNT(r.id) as total
            FROM reservas r
            JOIN canchas c ON r.cancha_id = c.id
            WHERE r.estado IN ('pagada_total', 'en_uso', 'finalizada')
            GROUP BY r.cancha_id
            ORDER BY total DESC LIMIT 1
        ")->fetch();

        // Horario más demandado (top 1)
        $horarioTop = $pdo->query("
            SELECT h.hora_inicio, COUNT(r.id) as total
            FROM reservas r
            JOIN horarios h ON r.horario_id = h.id
            WHERE r.estado IN ('pagada_total', 'en_uso', 'finalizada')
            GROUP BY r.horario_id
            ORDER BY total DESC LIMIT 1
        ")->fetch();

        return [
            'reservas_hoy' => $reservasHoy,
            'ingresos_mes' => $ingresosMes,
            'cancha_top' => $canchaTop ? $canchaTop['nombre'] : 'N/A',
            'cancha_top_count' => $canchaTop ? $canchaTop['total'] : 0,
            'horario_top' => $horarioTop ? $horarioTop['hora_inicio'] : 'N/A',
            'horario_top_count' => $horarioTop ? $horarioTop['total'] : 0
        ];
    }

    /**
     * Obtiene datos para gráficos de reservas por mes.
     */
    public function obtenerIngresosUltimosMeses(int $cantidadMeses = 6): array
    {
        $pdo = Conexion::obtener();
        $stmt = $pdo->query("
            SELECT DATE_FORMAT(fecha_pago, '%Y-%m') as mes, SUM(monto) as total
            FROM pagos
            WHERE estado = 'pagado' AND fecha_pago >= DATE_SUB(NOW(), INTERVAL $cantidadMeses MONTH)
            GROUP BY mes ORDER BY mes ASC
        ");
        return $stmt->fetchAll();
    }
}