<?php
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../helpers.php';

class PagoService
{
    /**
     * Registra un pago (parcial o total) para una reserva.
     */
    public function registrarPago(int $reservaId, string $tipo, string $metodo, float $monto, int $registradoPor, int $pagadoPor = null, string $comprobante = null): array
    {
        $pdo = Conexion::obtener();
        
        try {
            $pdo->beginTransaction();

            // 1. Registrar en tabla pagos
            $stmt = $pdo->prepare("
                INSERT INTO pagos (reserva_id, tipo, metodo, monto, estado, pagado_por, registrado_por, comprobante)
                VALUES (?, ?, ?, ?, 'pagado', ?, ?, ?)
            ");
            $stmt->execute([$reservaId, $tipo, $metodo, $monto, $pagadoPor, $registradoPor, $comprobante]);

            // 2. Actualizar monto pagado en la reserva
            $stmt = $pdo->prepare("UPDATE reservas SET monto_pagado = monto_pagado + ? WHERE id = ?");
            $stmt->execute([$monto, $reservaId]);

            // 3. Evaluar si la reserva pasa a pagada_parcial o pagada_total
            $stmt = $pdo->prepare("SELECT monto_total, monto_pagado FROM reservas WHERE id = ?");
            $stmt->execute([$reservaId]);
            $res = $stmt->fetch();

            $nuevoEstado = null;
            if ($res['monto_pagado'] >= $res['monto_total']) {
                $nuevoEstado = 'pagada_total';
            } elseif ($res['monto_pagado'] > 0) {
                $nuevoEstado = 'pagada_parcial';
            }

            if ($nuevoEstado) {
                $stmt = $pdo->prepare("UPDATE reservas SET estado = ? WHERE id = ? AND estado IN ('pendiente_pago', 'hold', 'pagada_parcial')");
                $stmt->execute([$nuevoEstado, $reservaId]);
            }

            $pdo->commit();
            return ['exito' => true, 'mensaje' => 'Pago registrado correctamente.'];

        } catch (Exception $e) {
            $pdo->rollBack();
            return ['exito' => false, 'mensaje' => 'Error al registrar el pago.'];
        }
    }

    /**
     * Registra el sobretiempo.
     */
    public function registrarSobretiempo(int $reservaId, int $minutosExtra, float $montoExtra, string $metodo, int $registradoPor): array
    {
        $pdo = Conexion::obtener();
        try {
            $pdo->beginTransaction();

            // Insertar el pago del sobretiempo
            $stmt = $pdo->prepare("
                INSERT INTO pagos (reserva_id, tipo, metodo, monto, estado, registrado_por)
                VALUES (?, 'sobretiempo', ?, ?, 'pagado', ?)
            ");
            $stmt->execute([$reservaId, $metodo, $montoExtra, $registradoPor]);

            // Actualizar reserva
            $stmt = $pdo->prepare("
                UPDATE reservas 
                SET minutos_extra = minutos_extra + ?, 
                    monto_extra = monto_extra + ?, 
                    sobretiempo_pagado = 1,
                    hora_fin_extendida = DATE_ADD(hora_fin_extendida, INTERVAL ? MINUTE)
                WHERE id = ?
            ");
            $stmt->execute([$minutosExtra, $montoExtra, $minutosExtra, $reservaId]);

            $pdo->commit();
            return ['exito' => true, 'mensaje' => 'Sobretiempo registrado.'];

        } catch (Exception $e) {
            $pdo->rollBack();
            return ['exito' => false, 'mensaje' => 'Error al registrar sobretiempo.'];
        }
    }
}