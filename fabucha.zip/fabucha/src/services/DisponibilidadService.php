<?php
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../helpers.php';

class DisponibilidadService
{
    /**
     * Devuelve los horarios disponibles para una cancha y fecha específica.
     */
    public function obtenerHorariosLibres(int $canchaId, string $fecha): array
    {
        $pdo = Conexion::obtener();

        // 1. Verificar si la cancha tiene un bloqueo general en esa fecha
        $stmt = $pdo->prepare("
            SELECT motivo FROM bloqueos_cancha 
            WHERE cancha_id = ? AND DATE(fecha_inicio) <= ? AND DATE(fecha_fin) >= ?
        ");
        $stmt->execute([$canchaId, $fecha, $fecha]);
        if ($stmt->fetch()) {
            return []; // Cancha bloqueada todo el día
        }

        // 2. Obtener todos los horarios activos
        $horarios = $pdo->query("SELECT id, hora_inicio, hora_fin FROM horarios WHERE activo = 1 ORDER BY hora_inicio")->fetchAll();

        // 3. Obtener reservas activas para esa cancha y fecha
        $stmt = $pdo->prepare("
            SELECT horario_id FROM reservas 
            WHERE cancha_id = ? AND fecha = ? 
            AND estado IN ('hold', 'pendiente_pago', 'pagada_parcial', 'pagada_total', 'en_uso')
        ");
        $stmt->execute([$canchaId, $fecha]);
        $ocupados = $stmt->fetchAll(PDO::FETCH_COLUMN);

        // 4. Filtrar los horarios
        $disponibles = [];
        $ahora = date('Y-m-d H:i:s');
        
        foreach ($horarios as $h) {
            if (in_array($h['id'], $ocupados)) continue;

            // Si es hoy, verificar que el horario no haya pasado y cumplir con las 5 horas de anticipación
            if ($fecha === date('Y-m-d')) {
                $hora_inicio_ts = strtotime($fecha . ' ' . $h['hora_inicio']);
                $limite_pago_ts = $hora_inicio_ts - (HORAS_LIMITE_PAGO * 3600);
                
                // Si ya pasó la hora límite, no se muestra
                if (time() > $limite_pago_ts) continue;
            }

            $disponibles[] = $h;
        }

        return $disponibles;
    }

    /**
     * Calcula el tope máximo de sobretiempo para una reserva.
     * Retorna un array con la hora límite y los minutos disponibles.
     */
    public function calcularTopeSobretiempo(int $canchaId, string $fecha, string $horaFinActual): array
    {
        $pdo = Conexion::obtener();
        
        // Buscar la siguiente reserva en esa cancha y fecha
        $stmt = $pdo->prepare("
            SELECT h.hora_inicio 
            FROM reservas r
            JOIN horarios h ON r.horario_id = h.id
            WHERE r.cancha_id = ? AND r.fecha = ? 
              AND h.hora_inicio > ? 
              AND r.estado IN ('pagada_total', 'en_uso', 'pagada_parcial')
            ORDER BY h.hora_inicio ASC LIMIT 1
        ");
        $stmt->execute([$canchaId, $fecha, $horaFinActual]);
        $siguiente = $stmt->fetch();

        $tope = HORA_CIERRE_LOCAL; // Por defecto, hasta el cierre
        $haySiguiente = false;

        if ($siguiente) {
            // Hay otra reserva: restar los 20 minutos de limpieza
            $topeTs = strtotime($fecha . ' ' . $siguiente['hora_inicio']) - (MINUTOS_LIMPIEZA_ENTRE_RESERVAS * 60);
            $tope = date('H:i:s', $topeTs);
            $haySiguiente = true;
        }

        // Calcular minutos disponibles desde la hora de fin actual hasta el tope
        $finTs = strtotime($fecha . ' ' . $horaFinActual);
        $topeTs = strtotime($fecha . ' ' . $tope);
        $minutosDisponibles = max(0, ($topeTs - $finTs) / 60);

        return [
            'tope' => $tope,
            'minutos_disponibles' => $minutosDisponibles,
            'hay_siguiente_reserva' => $haySiguiente
        ];
    }
}