<?php
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class CorreoService
{
    private function configurarSMTP(PHPMailer $mail): void
    {
        $mail->isSMTP();
        $mail->Host       = MAIL_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = MAIL_USER;
        $mail->Password   = MAIL_PASS;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = MAIL_PORT;
        $mail->CharSet    = 'UTF-8';
        $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);
    }

    /**
     * Envía el correo de notificación cuando la cuenta se bloquea.
     */
    public function enviarCorreoBloqueo(string $emailDestino, string $nombre): bool
    {
        $mail = new PHPMailer(true);
        try {
            $this->configurarSMTP($mail);
            $mail->addAddress($emailDestino, $nombre);
            $mail->isHTML(true);
            $mail->Subject = 'Cuenta bloqueada - Local Fabucha';
            $mail->Body    = "
                <h3>Hola {$nombre},</h3>
                <p>Tu cuenta ha sido <b>bloqueada temporalmente</b> tras 3 intentos fallidos de inicio de sesión.</p>
                <p>Para desbloquearla, contacta al administrador del Local Fabucha o espera 15 minutos.</p>
                <p>— Sistema de Reservas Fabucha</p>
            ";
            return $mail->send();
        } catch (Exception $e) {
            error_log("Error al enviar correo de bloqueo: " . $mail->ErrorInfo);
            return false;
        }
    }

    /**
     * Envía el enlace de recuperación de contraseña.
     */
    public function enviarCorreoRecuperacion(string $emailDestino, string $nombre, string $token): bool
    {
        $mail = new PHPMailer(true);
        try {
            $this->configurarSMTP($mail);
            $mail->addAddress($emailDestino, $nombre);
            $mail->isHTML(true);
            $mail->Subject = 'Recuperación de contraseña - Local Fabucha';
            
            $enlace = "http://localhost/fabucha/public/reset_password.php?token=" . $token;
            
            $mail->Body = "
                <h3>Hola {$nombre},</h3>
                <p>Hemos recibido una solicitud para restablecer tu contraseña.</p>
                <p>Haz clic en el siguiente enlace para crear una nueva contraseña:</p>
                <p><a href='{$enlace}' style='padding: 10px 20px; background-color: #22c55e; color: white; text-decoration: none; border-radius: 5px; display: inline-block;'>Restablecer contraseña</a></p>
                <p>Si no solicitaste este cambio, ignora este correo.</p>
                <p>— Sistema de Reservas Fabucha</p>
            ";
            return $mail->send();
        } catch (Exception $e) {
            error_log("Error al enviar correo de recuperación: " . $mail->ErrorInfo);
            return false;
        }
    }

    /**
     * Envía la confirmación de reserva con el código único.
     */
    public function enviarConfirmacionReserva(string $emailDestino, string $nombre, string $codigo, string $cancha, string $fecha, string $hora, float $monto): bool
    {
        $mail = new PHPMailer(true);
        try {
            $this->configurarSMTP($mail);
            $mail->addAddress($emailDestino, $nombre);
            $mail->isHTML(true);
            $mail->Subject = "Reserva Confirmada: {$codigo} - Local Fabucha";
            $mail->Body = "
                <h3>¡Hola {$nombre}!</h3>
                <p>Tu reserva ha sido registrada exitosamente.</p>
                <ul>
                    <li><b>Código de reserva:</b> <span style='font-size: 1.2em; color: #22c55e;'>{$codigo}</span></li>
                    <li><b>Cancha:</b> {$cancha}</li>
                    <li><b>Fecha:</b> {$fecha}</li>
                    <li><b>Hora:</b> {$hora}</li>
                    <li><b>Monto Total:</b> S/ " . number_format($monto, 2) . "</li>
                </ul>
                <p>Presenta este código al llegar al local.</p>
                <p>— Sistema de Reservas Fabucha</p>
            ";
            return $mail->send();
        } catch (Exception $e) {
            error_log("Error al enviar correo de reserva: " . $mail->ErrorInfo);
            return false;
        }
    }
}