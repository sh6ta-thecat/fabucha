<?php
require_once __DIR__ . '/../repositories/UsuarioRepository.php';
require_once __DIR__ . '/../models/Usuario.php';
require_once __DIR__ . '/CorreoService.php';
require_once __DIR__ . '/../auth.php'; // Necesario para iniciarSesionUsuario()

class AuthService
{
    private UsuarioRepository $usuarios;
    private CorreoService $correo;

    public function __construct()
    {
        $this->usuarios = new UsuarioRepository();
        $this->correo = new CorreoService();
    }

    /**
     * Procesa el inicio de sesión.
     * Retorna un array: ['exito' => bool, 'mensaje' => string]
     */
    public function login(string $email, string $password): array
    {
        $datos = $this->usuarios->buscarPorEmail($email);
        
        if (!$datos) {
            return ['exito' => false, 'mensaje' => 'Correo o contraseña incorrectos.'];
        }

        $usuario = new Usuario($datos);

        if ($usuario->isCuentaBloqueada()) {
            return ['exito' => false, 'mensaje' => 'Tu cuenta está bloqueada. Revisa tu correo o contacta al administrador.'];
        }

        if (!password_verify($password, $usuario->getPassword())) {
            // Contraseña incorrecta
            $this->usuarios->incrementarIntentos($usuario->getId());
            $intentosRestantes = MAX_INTENTOS_LOGIN - ($usuario->getIntentosFallidos() + 1);

            if ($intentosRestantes <= 0) {
                $this->usuarios->bloquearCuenta($usuario->getId());
                $this->correo->enviarCorreoBloqueo($usuario->getEmail(), $usuario->getNombre());
                return ['exito' => false, 'mensaje' => 'Cuenta bloqueada por seguridad tras 3 intentos fallidos. Revisa tu correo.'];
            }

            return ['exito' => false, 'mensaje' => "Contraseña incorrecta. Te quedan {$intentosRestantes} intentos."];
        }

        // Login exitoso
        $this->usuarios->resetearIntentos($usuario->getId());
        
        // Iniciar sesión usando el helper que acabamos de arreglar
        iniciarSesionUsuario($datos); 
        
        return ['exito' => true, 'mensaje' => 'Bienvenido'];
    }

    /**
     * Registra un nuevo usuario cliente.
     */
    public function registrar(string $nombre, string $email, string $password, ?string $telefono): array
    {
        // Validar que el correo no exista
        if ($this->usuarios->buscarPorEmail($email)) {
            return ['exito' => false, 'mensaje' => 'El correo electrónico ya está registrado.'];
        }

        // Hashear contraseña
        $hash = password_hash($password, PASSWORD_BCRYPT);

        // Crear usuario
        $id = $this->usuarios->crear([
            'nombre' => $nombre,
            'email' => $email,
            'password' => $hash,
            'telefono' => $telefono,
            'rol' => 'cliente'
        ]);

        return ['exito' => true, 'mensaje' => 'Registro exitoso. Ya puedes iniciar sesión.', 'id' => $id];
    }
}