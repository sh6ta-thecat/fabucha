<?php
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../helpers.php';
require_once __DIR__ . '/CodigoService.php';
require_once __DIR__ . '/CorreoService.php';
require_once __DIR__ . '/DisponibilidadService.php';

class ReservaService
{
    private CodigoService $codigos;
    private CorreoService $correo;
    private DisponibilidadService $disponibilidad;

    public function __construct()
    {
        $this->codigos = new CodigoService();
        $this->correo = new CorreoService();
        $this->disponibilidad = new DisponibilidadService();
    }

    /**
     * Crea una reserva en estado HOLD.
     */
    public function crearHold(int $usuarioId, int $canchaId, int $deporteId, string $fecha, int $horarioId, int $cantidadPersonas, string $nombreEquipo = null): array
    {
        $pdo = Conexion::obtener();
        
        try {
            $pdo->beginTransaction();

            // 1. Bloqueo de fila para evitar concurrencia
            // (Verificamos si el horario ya está tomado por una reserva activa)
            $stmt = $pdo->prepare("
                SELECT id FROM reservas 
                WHERE cancha_id = ? AND fecha = ? AND horario_id = ? 
                AND estado IN ('hold', 'pendiente_pago', 'pagada_parcial', 'pagada_total', 'en_uso')
                FOR UPDATE
            ");
            $stmt->execute([$canchaId, $fecha, $horarioId]);
            if ($stmt->fetch()) {
                $pdo->rollBack();
                return ['exito' => false, 'mensaje' => 'El horario acaba de ser ocupado por otro usuario.'];
            }

            // 2. Obtener precio de la combinación cancha-deporte
            $stmt = $pdo->prepare("SELECT precio_hora FROM cancha_deporte WHERE cancha_id = ? AND deporte_id = ?");
            $stmt->execute([$canchaId, $deporteId]);
            $precio = $stmt->fetchColumn();
            if (!$precio) {
                $pdo->rollBack();
                return ['exito' => false, 'mensaje' => 'La cancha no está habilitada para este deporte.'];
            }

            // 3. Calcular expiración del hold y montos
            $codigo = $this->codigos->generarCodigoReserva();
            $montoCancha = (float)$precio;
            $montoTotal = $montoCancha + DEPOSITO_FIJO;
            $expiraEn = date('Y-m-d H:i:s', strtotime('+' . HOLD_MINUTOS . ' minutes'));
            
            // Límite de pago: 5 horas antes del inicio de la reserva
            $horaInicio = $pdo->query("SELECT hora_inicio FROM horarios WHERE id = $horarioId")->fetchColumn();
            $limitePago = date('Y-m-d H:i:s', strtotime($fecha . ' ' . $horaInicio) - (HORAS_LIMITE_PAGO * 3600));

            // 4. Insertar el HOLD
            $stmt = $pdo->prepare("
                INSERT INTO reservas (codigo, usuario_id, cancha_id, deporte_id, fecha, horario_id, cantidad_personas, nombre_equipo, estado, monto_cancha, monto_deposito, monto_total, expira_en, limite_pago, registrado_por)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'hold', ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $codigo, $usuarioId, $canchaId, $deporteId, $fecha, $horarioId, $cantidadPersonas, $nombreEquipo,
                $montoCancha, DEPOSITO_FIJO, $montoTotal, $expiraEn, $limitePago, $usuarioId
            ]);

            $reservaId = $pdo->lastInsertId();
            $pdo->commit();

            return [
                'exito' => true, 
                'reserva_id' => $reservaId, 
                'codigo' => $codigo, 
                'monto_total' => $montoTotal,
                'expira_en' => $expiraEn
            ];

        } catch (Exception $e) {
            $pdo->rollBack();
            error_log("Error en crearHold: " . $e->getMessage());
            return ['exito' => false, 'mensaje' => 'Error interno al procesar la reserva.'];
        }
    }

    /**
     * Cancela una reserva y calcula la multa según el tiempo de anticipación.
     */
    public function cancelarReserva(int $reservaId, string $motivo = 'cliente'): array
    {
        $pdo = Conexion::obtener();
        
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("SELECT * FROM reservas WHERE id = ? FOR UPDATE");
            $stmt->execute([$reservaId]);
            $reserva = $stmt->fetch();

            if (!$reserva) {
                $pdo->rollBack();
                return ['exito' => false, 'mensaje' => 'Reserva no encontrada.'];
            }

            if (in_array($reserva['estado'], ['cancelada_cliente', 'cancelada_local', 'finalizada', 'no_show'])) {
                $pdo->rollBack();
                return ['exito' => false, 'mensaje' => 'Esta reserva ya no se puede cancelar.'];
            }

            // Calcular horas de anticipación
            $horaInicio = $pdo->query("SELECT hora_inicio FROM horarios WHERE id = {$reserva['horario_id']}")->fetchColumn();
            $fechaHoraInicio = strtotime($reserva['fecha'] . ' ' . $horaInicio);
            $horasAnticipacion = ($fechaHoraInicio - time()) / 3600;

            // Buscar política aplicable
            $stmt = $pdo->query("SELECT * FROM politicas_cancelacion ORDER BY horas_anticipacion_min DESC");
            $politica = null;
            foreach ($stmt->fetchAll() as $p) {
                if ($horasAnticipacion >= $p['horas_anticipacion_min']) {
                    $politica = $p;
                    break;
                }
            }

            // Si el local cancela, siempre es 100%
            if ($motivo === 'local') {
                $reembolso = $reserva['monto_pagado'];
                $multa = 0;
            } else {
                $porcentaje = $politica ? $politica['porcentaje_reembolso_cancha'] : 0;
                $reembolsoCancha = ($reserva['monto_cancha'] * $porcentaje) / 100;
                $reembolsoDeposito = ($politica && $politica['reembolso_deposito']) ? $reserva['monto_deposito'] : 0;
                $reembolso = $reembolsoCancha + $reembolsoDeposito;
                $multa = $reserva['monto_pagado'] - $reembolso;
            }

            $nuevoEstado = ($motivo === 'local') ? 'cancelada_local' : 'cancelada_cliente';

            $stmt = $pdo->prepare("
                UPDATE reservas 
                SET estado = ?, monto_reembolsado = ?, multa_aplicada = ?, actualizada_en = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$nuevoEstado, $reembolso, $multa, $reservaId]);

            // Registrar log
            $stmt = $pdo->prepare("INSERT INTO logs_reservas (reserva_id, estado_anterior, estado_nuevo, motivo) VALUES (?, ?, ?, ?)");
            $stmt->execute([$reservaId, $reserva['estado'], $nuevoEstado, $motivo]);

            $pdo->commit();

            return [
                'exito' => true, 
                'mensaje' => 'Reserva cancelada.', 
                'reembolso' => $reembolso,
                'multa' => $multa
            ];

        } catch (Exception $e) {
            $pdo->rollBack();
            return ['exito' => false, 'mensaje' => 'Error al cancelar la reserva.'];
        }
    }

    /**
     * Libera los holds vencidos.
     */
    public function limpiarHoldsVencidos(): int
    {
        $pdo = Conexion::obtener();
        $stmt = $pdo->prepare("
            UPDATE reservas 
            SET estado = 'cancelada_falta_pago' 
            WHERE estado = 'hold' AND expira_en < NOW()
        ");
        $stmt->execute();
        return $stmt->rowCount();
    }
}