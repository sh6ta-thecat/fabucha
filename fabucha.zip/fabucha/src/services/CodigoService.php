<?php
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../helpers.php';

class CodigoService
{
    /**
     * Genera un código de reserva único (FAB-XXXXXX) verificando que no exista en la BD.
     */
    public function generarCodigoReserva(): string
    {
        $pdo = Conexion::obtener();
        $caracteres = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Sin O, 0, I, 1

        do {
            $codigo = 'FAB-';
            for ($i = 0; $i < 6; $i++) {
                $codigo .= $caracteres[random_int(0, strlen($caracteres) - 1)];
            }
            
            // Verificar si ya existe
            $stmt = $pdo->prepare("SELECT id FROM reservas WHERE codigo = ?");
            $stmt->execute([$codigo]);
            $existe = $stmt->fetch();

        } while ($existe);

        return $codigo;
    }

    /**
     * Genera un token seguro para recuperación de contraseña.
     */
    public function generarTokenRecuperacion(): string
    {
        return bin2hex(random_bytes(32));
    }
}