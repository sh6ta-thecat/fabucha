<?php
/**
 * helpers.php
 * Funciones utilitarias reutilizables.
 */

require_once __DIR__ . '/../config.php';

/**
 * Sanitiza una cadena para mostrarla en HTML.
 */
function e(?string $texto): string
{
    return htmlspecialchars($texto ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Redirige a una URL y termina.
 */
function redirigir(string $url): void
{
    header('Location: ' . $url);
    exit;
}

/**
 * Devuelve una respuesta JSON y termina.
 */
function jsonResponse(array $data, int $codigo = 200): void
{
    http_response_code($codigo);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Genera un código de reserva único: FAB-XXXXXX
 * Sin caracteres confundibles (O, 0, I, 1).
 */
function generarCodigoReserva(): string
{
    $caracteres = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $codigo = 'FAB-';
    for ($i = 0; $i < 6; $i++) {
        $codigo .= $caracteres[random_int(0, strlen($caracteres) - 1)];
    }
    return $codigo;
}

/**
 * Valida el token CSRF.
 */
function validarCsrf(?string $token): bool
{
    return !empty($token) && !empty($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Verifica si hay sesión activa.
 */
function estaLogueado(): bool
{
    return !empty($_SESSION['usuario_id']);
}

/**
 * Devuelve el rol del usuario logueado.
 */
function rolActual(): ?string
{
    return $_SESSION['rol'] ?? null;
}

/**
 * Requiere un rol específico o redirige.
 */
function requireRol(string ...$roles): void
{
    if (!estaLogueado()) {
        redirigir('/fabucha/public/login.php');
    }
    if (!in_array(rolActual(), $roles, true)) {
        redirigir('/fabucha/public/index.php');
    }
}

/**
 * Formatea un monto en soles.
 */
function soles(float $monto): string
{
    return 'S/ ' . number_format($monto, 2);
}

/**
 * Formatea una fecha legible.
 */
function fechaLegible(string $fecha): string
{
    $dias = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
    $meses = ['','Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio',
              'Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
    $ts = strtotime($fecha);
    return $dias[date('w', $ts)] . ', ' . date('d', $ts) . ' de ' .
           $meses[(int)date('n', $ts)] . ' de ' . date('Y', $ts);
}

/**
 * Calcula la diferencia en horas entre dos fechas.
 */
function horasEntre(string $desde, string $hasta): float
{
    return (strtotime($hasta) - strtotime($desde)) / 3600;
}

/**
 * Obtiene la IP del cliente.
 */
function ipCliente(): string
{
    return $_SERVER['REMOTE_ADDR'] ?? 'desconocida';
}

/**
 * Obtiene el User-Agent del cliente.
 */
function userAgent(): string
{
    return substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);
}

/**
 * Registra un log de acceso en la BD.
 */
function logAcceso(?int $usuarioId, ?string $email, string $evento): void
{
    try {
        $pdo = Conexion::obtener();
        $stmt = $pdo->prepare(
            'INSERT INTO logs_acceso (usuario_id, email_intentado, evento, ip, user_agent)
             VALUES (?, ?, ?, ?, ?)'
        );
        $stmt->execute([$usuarioId, $email, $evento, ipCliente(), userAgent()]);
    } catch (Exception $e) {
        // No interrumpir el flujo por un fallo de log
    }
}