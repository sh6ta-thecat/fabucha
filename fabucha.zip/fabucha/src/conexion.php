<?php
/**
 * conexion.php
 * Devuelve una instancia única de PDO.
 */

require_once __DIR__ . '/../config.php';

class Conexion
{
    private static ?PDO $pdo = null;

    public static function obtener(): PDO
    {
        if (self::$pdo === null) {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
            $opciones = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::ATTR_PERSISTENT         => false,
            ];
            try {
                self::$pdo = new PDO($dsn, DB_USER, DB_PASS, $opciones);
            } catch (PDOException $e) {
                if (DEBUG) {
                    die('Error de conexión a la base de datos: ' . $e->getMessage());
                }
                die('Error de conexión a la base de datos. Contacta al administrador.');
            }
        }
        return self::$pdo;
    }

    public static function cerrar(): void
    {
        self::$pdo = null;
    }
}